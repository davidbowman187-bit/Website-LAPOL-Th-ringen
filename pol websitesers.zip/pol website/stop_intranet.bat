@echo off
title Landespolizei Thüringen - Intranet stoppen

echo ============================================
echo   Stoppe Backend auf Port 3000...
echo ============================================
echo.

powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"

echo Backend wurde gestoppt, sofern es auf Port 3000 lief.
echo.
pause
