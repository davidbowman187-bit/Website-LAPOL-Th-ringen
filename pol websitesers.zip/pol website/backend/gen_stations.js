const fs = require('fs');
const code = fs.readFileSync('../assets/js/data.js', 'utf8');
const window = {};
eval(code);
const stations = window.LPT.stations;
let sql = `CREATE TABLE IF NOT EXISTS stations (
  id VARCHAR(80) PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  city VARCHAR(120) NOT NULL,
  region VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  hours VARCHAR(120) NOT NULL,
  services LONGTEXT NOT NULL,
  x INT NOT NULL,
  y INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

`;
stations.forEach((s) => {
  sql += "INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES (" +
    [JSON.stringify(s.id), JSON.stringify(s.name), JSON.stringify(s.city), JSON.stringify(s.region), JSON.stringify(s.address), JSON.stringify(s.phone), JSON.stringify(s.email), JSON.stringify(s.hours), JSON.stringify(JSON.stringify(s.services)), s.x, s.y].join(',') +
    ");\n";
});
fs.writeFileSync('stations_seed.sql', sql);
console.log('stations:', stations.length);