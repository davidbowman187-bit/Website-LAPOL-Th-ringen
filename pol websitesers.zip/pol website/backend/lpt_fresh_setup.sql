-- ============================================================================
--  Landespolizei Thüringen · Roleplay Erfurt – Frische Datenbank-Setup
-- ============================================================================
--  Website-Datenbank : lpt_website   (öffentliche Website + Intranet Backend)
--  FiveM-Server-DB   : brightnight   (Server-Aktensystem: Polizei-Fälle)
--
--  Ausführung (MySQL / MariaDB):
--    mysql -u website -p lpt_website < backend/lpt_fresh_setup.sql
--    mysql -u website -p brightnight < backend/lpt_fresh_setup.sql
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================================
--   1) WEBSITE-DB : lpt_website
-- ============================================================================

CREATE DATABASE IF NOT EXISTS lpt_website CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lpt_website;

DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS news;
DROP TABLE IF EXISTS wanted_persons;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS rank_permissions;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS ranks;
DROP TABLE IF EXISTS evidence;
DROP TABLE IF EXISTS stations;

CREATE TABLE IF NOT EXISTS ranks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  level INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS permissions (
  `key` VARCHAR(100) PRIMARY KEY,
  description VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rank_permissions (
  rank_id INT NOT NULL,
  permission_key VARCHAR(100) NOT NULL,
  PRIMARY KEY (rank_id, permission_key),
  FOREIGN KEY (rank_id) REFERENCES ranks(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_key) REFERENCES permissions(`key`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(120) NOT NULL,
  rank_id INT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  last_login TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rank_id) REFERENCES ranks(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref VARCHAR(40) NOT NULL UNIQUE,
  type VARCHAR(40) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'eingegangen',
  payload LONGTEXT NOT NULL,
  applicant_name VARCHAR(120) NULL,
  applicant_email VARCHAR(190) NULL,
  applicant_birth DATE NULL,
  station_id VARCHAR(80) NULL,
  assigned_to INT NULL,
  internal_note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_applications_type (type),
  INDEX idx_applications_status (status),
  INDEX idx_applications_ref (ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS wanted_persons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_no VARCHAR(40) NOT NULL UNIQUE,
  category VARCHAR(40) NOT NULL DEFAULT 'person',
  title VARCHAR(190) NOT NULL,
  location VARCHAR(190) NULL,
  teaser VARCHAR(255) NULL,
  description TEXT NULL,
  facts LONGTEXT NULL,
  hint VARCHAR(255) NULL,
  icon VARCHAR(40) NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'aktiv',
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS news (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(120) NOT NULL UNIQUE,
  category VARCHAR(40) NOT NULL,
  label VARCHAR(80) NOT NULL,
  title VARCHAR(190) NOT NULL,
  teaser VARCHAR(255) NULL,
  location VARCHAR(120) NULL,
  reading INT NOT NULL DEFAULT 1,
  featured TINYINT(1) NOT NULL DEFAULT 0,
  icon VARCHAR(40) NULL,
  body LONGTEXT NULL,
  published TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id VARCHAR(40) NULL,
  details LONGTEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stations (
  id VARCHAR(80) PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  city VARCHAR(120) NOT NULL,
  region VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  hours VARCHAR(120) NOT NULL,
  services LONGTEXT NOT NULL,
  x INT NOT NULL,
  y INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS evidence (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_no VARCHAR(40) NOT NULL UNIQUE,
  title VARCHAR(190) NOT NULL,
  category VARCHAR(80) NULL,
  location VARCHAR(120) NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'eingelagert',
  description TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Berechtigungen
INSERT IGNORE INTO permissions (`key`, description) VALUES
('dashboard.view', 'Dashboard und Übersicht einsehen'),
('applications.view', 'Anträge und Vorgänge einsehen'),
('applications.manage', 'Anträge bearbeiten und Status setzen'),
('wanted.view', 'Fahndungen einsehen'),
('wanted.manage', 'Fahndungen erstellen und bearbeiten'),
('news.view', 'Meldungen einsehen'),
('news.manage', 'Meldungen erstellen und bearbeiten'),
('users.view', 'Benutzer einsehen'),
('users.manage', 'Benutzer und Ränge zuweisen'),
('ranks.view', 'Ränge einsehen'),
('ranks.manage', 'Ränge und Berechtigungen verwalten'),
('stations.manage', 'Dienststellen verwalten'),
('evidence.view', 'Asservaten einsehen'),
('evidence.manage', 'Asservaten verwalten');

-- Ränge
INSERT IGNORE INTO ranks (id, name, description, level) VALUES
(1, 'Administrator', 'Vollzugriff auf alle Funktionen', 100),
(2, 'Leitung', 'Leitung der Dienststelle', 80),
(3, 'Sachbearbeiter', 'Bearbeitung von Anträgen und Meldungen', 50),
(4, 'Streifendienst', 'Einsatz und Grundfunktionen', 20);

INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(1,'dashboard.view'),(1,'applications.view'),(1,'applications.manage'),(1,'wanted.view'),(1,'wanted.manage'),(1,'news.view'),(1,'news.manage'),(1,'users.view'),(1,'users.manage'),(1,'ranks.view'),(1,'ranks.manage'),(1,'stations.manage');
INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(2,'dashboard.view'),(2,'applications.view'),(2,'applications.manage'),(2,'wanted.view'),(2,'wanted.manage'),(2,'news.view'),(2,'news.manage'),(2,'users.view'),(2,'users.manage'),(2,'ranks.view'),(2,'ranks.manage');
INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(3,'dashboard.view'),(3,'applications.view'),(3,'applications.manage'),(3,'wanted.view'),(3,'wanted.manage'),(3,'news.view'),(3,'news.manage');
INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(4,'dashboard.view'),(4,'applications.view'),(4,'wanted.view'),(4,'news.view');
INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(1,'evidence.view'),(1,'evidence.manage'),(2,'evidence.view'),(2,'evidence.manage'),(3,'evidence.view');

-- Benutzer
INSERT IGNORE INTO users (id, username, password_hash, display_name, rank_id, active) VALUES
(1, 'admin', '$2b$10$unhRwp.XRELvxn8zt0LF6etjcztCm3fWLJxjN2K8Ezv4ujuAbLTmy', 'Administrator', 1, 1);
INSERT IGNORE INTO users (id, username, password_hash, display_name, rank_id, active) VALUES
(2, 'demo', '$2b$10$Bsbyws/h87qP5MTFP4bgCujl3Ih64mHMlhBGAkgrkop1A6LRjEHNi', 'K. Weber', 3, 1);

-- Dienststellen
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("erfurt-zentrum","Polizeiinspektion Erfurt-Zentrum","Erfurt","Mitte","Andreasstraße 36, 99084 Erfurt","0361 123450","pi-erfurt-zentrum@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",47,49);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("erfurt-nord","Polizeiinspektion Erfurt-Nord","Erfurt","Mitte","Stotternheimer Straße 18, 99086 Erfurt","0361 123456","pi-erfurt-nord@polizei-rp-erfurt.de","Mo–Fr 07:00–19:00 Uhr","[\"Anzeige\",\"Beratung\",\"Termine\"]",50,41);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("weimar","Polizeiinspektion Weimar","Weimar","Mitte","Erfurter Straße 12, 99423 Weimar","03643 123400","pi-weimar@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",60,47);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("jena","Polizeiinspektion Jena","Jena","Ost","Lutherstraße 24, 07743 Jena","03641 123500","pi-jena@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",72,54);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("gera","Polizeiinspektion Gera","Gera","Ost","Wiesestraße 8, 07548 Gera","0365 123600","pi-gera@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",80,66);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("altenburg","Polizeiinspektion Altenburg","Altenburg","Ost","Schloßgasse 5, 04600 Altenburg","03447 123700","pi-altenburg@polizei-rp-erfurt.de","Mo–Fr 08:00–18:00 Uhr","[\"Anzeige\",\"Beratung\",\"Termine\"]",90,70);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("nordhausen","Polizeiinspektion Nordhausen","Nordhausen","Nord","Bahnhofstraße 17, 99734 Nordhausen","03631 123800","pi-nordhausen@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",34,16);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("muehlhausen","Polizeiinspektion Mühlhausen","Mühlhausen","Nord","Unstrutstraße 9, 99974 Mühlhausen","03601 123900","pi-muehlhausen@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",20,30);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("eisenach","Polizeiinspektion Eisenach","Eisenach","West","Karlstraße 14, 99817 Eisenach","03691 124000","pi-eisenach@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",10,43);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("gotha","Polizeiinspektion Gotha","Gotha","West","Hauptmarkt 3, 99867 Gotha","03621 124100","pi-gotha@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",32,47);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("suhl","Polizeiinspektion Suhl","Suhl","Süd","Rathausstraße 6, 98527 Suhl","03681 124200","pi-suhl@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",40,76);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("meiningen","Polizeiinspektion Meiningen","Meiningen","Süd","Markt 10, 98617 Meiningen","03693 124300","pi-meiningen@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",27,82);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("sonneberg","Polizeiinspektion Sonneberg","Sonneberg","Süd","Bahnhofstraße 21, 96515 Sonneberg","03675 124400","pi-sonneberg@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",54,88);

-- ============================================================================
--  2) FIVEM-SERVER-DB : brightnight
-- ============================================================================

CREATE DATABASE IF NOT EXISTS brightnight CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brightnight;

DROP TABLE IF EXISTS police_characters;
DROP TABLE IF EXISTS police_cases;

CREATE TABLE IF NOT EXISTS police_cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_number VARCHAR(40) NOT NULL UNIQUE,
  title VARCHAR(190) NOT NULL,
  description TEXT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'offen',
  character_identifier VARCHAR(120) NULL,
  created_by VARCHAR(120) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS police_characters (
  id INT AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(120) NOT NULL UNIQUE,
  firstname VARCHAR(80) NULL,
  lastname VARCHAR(80) NULL,
  dateofbirth DATE NULL,
  phone VARCHAR(40) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Beispieldaten für das Akten-/Charakter-System (FiveM)
INSERT INTO police_cases (case_number, title, description, status, character_identifier, created_by) VALUES
('LPT/2026/001', 'Unfall mit verletzten Personen', 'Fahrer und Verletzter werden eingehender Ermittlung zugewiesen. Unfallstelle gesichert.', 'offen', 'POL-E-001', 'K. Weber');
INSERT INTO police_cases (case_number, title, description, status, character_identifier, created_by) VALUES
('LPT/2026/002', 'Diebstahl aus Fahrzeug', 'Tatort: Wohngebiet Erfurt. Mittäterkreis wird gesucht.', 'offen', 'POL-E-002', 'K. Weber');

INSERT INTO police_characters (identifier, firstname, lastname, dateofbirth, phone, created_at) VALUES
('POL-E-001', 'Erika', 'Muster', '1990-04-12', '0176 123456', CURRENT_TIMESTAMP);
INSERT INTO police_characters (identifier, firstname, lastname, dateofbirth, phone, created_at) VALUES
('POL-E-002', 'Jonas', 'Berg', '1988-11-30', '0176 654321', CURRENT_TIMESTAMP);

SET FOREIGN_KEY_CHECKS = 1;
