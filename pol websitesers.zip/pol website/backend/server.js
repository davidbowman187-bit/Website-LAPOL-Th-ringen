require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('node:path');

const authRoutes = require('./routes/auth');
const ranksRoutes = require('./routes/ranks');
const applicationsRoutes = require('./routes/applications');
const wantedRoutes = require('./routes/wanted');
const newsRoutes = require('./routes/news');
const stationsRoutes = require('./routes/stations');
const evidenceRoutes = require('./routes/evidence');
const documentsRoutes = require('./routes/documents');
const statsRoutes = require('./routes/stats');
const aktensystemRoutes = require('./routes/aktensystem');
const weaponsRoutes = require('./routes/weapons');
const activityRoutes = require('./routes/activity');
const lawsRoutes = require('./routes/laws');
const ticketsRoutes = require('./routes/tickets');
const newsletterRoutes = require('./routes/newsletter');
const citizenRoutes = require('./routes/citizen');
const recruitmentRoutes = require('./routes/recruitment');
const trainingRoutes = require('./routes/training');
const hrRoutes = require('./routes/hr');
const leadershipRoutes = require('./routes/leadership');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const { query } = require('./src/db');

// Hinter cloudflared/ngrok kommt die Verbindung aus dem Loopback; dadurch werden
// X-Forwarded-Proto/-For korrekt ausgewertet und req.secure ist auch im Tunnel true.
app.set('trust proxy', process.env.TRUST_PROXY || 'loopback');

// www auf die kanonische öffentliche Adresse umleiten, damit OAuth-Cookies und
// die bei Discord hinterlegte Redirect-URI immer zum selben Host gehören.
const publicBaseUrl = String(process.env.PUBLIC_BASE_URL || '').trim().replace(/\/$/, '');
if (publicBaseUrl) {
  try {
    const canonical = new URL(publicBaseUrl);
    app.use((req, res, next) => {
      if (req.hostname === 'www.' + canonical.hostname) {
        return res.redirect(301, canonical.origin + req.originalUrl);
      }
      next();
    });
  } catch (e) {
    console.warn('PUBLIC_BASE_URL ist ungültig:', publicBaseUrl);
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
const corsOrigins = String(process.env.CORS_ORIGIN || '')
  .split(',')
  .map((value) => value.trim())
  .filter(Boolean);
app.use(cors({ origin: corsOrigins.length ? corsOrigins : true, credentials: true }));
app.use(morgan('dev'));
app.use(express.json({ limit: '12mb' }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 600 }));
// Öffentlich erreichbares Intranet: Login-Brute-Force begrenzen.
app.use('/api/auth/login', rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Zu viele Anmeldeversuche. Bitte später erneut versuchen.' }
}));

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'lpt-backend' }));

app.get('/api/health/db', async (req, res) => {
  const { websitePool, serverPool, query } = require('./src/db');
  const result = { website: false, server: false };
  try { await websitePool.query('SELECT 1'); result.website = true; } catch (e) { result.websiteError = e.message; }
  try { await serverPool.query('SELECT 1'); result.server = true; } catch (e) { result.serverError = e.message; }
  res.json(result);
});

app.use('/api/auth', authRoutes);
app.use('/api', ranksRoutes);
app.use('/api/applications', applicationsRoutes);
app.use('/api/wanted', wantedRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/stations', stationsRoutes);
app.use('/api/evidence', evidenceRoutes);
app.use('/api/documents', documentsRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/aktensystem', aktensystemRoutes);
app.use('/api/weapons', weaponsRoutes);
app.use('/api/activity-reports', activityRoutes);
app.use('/api/laws', lawsRoutes);
app.use('/api/tickets', ticketsRoutes);
app.use('/api/newsletter', newsletterRoutes);
app.use('/api/citizen', citizenRoutes);
app.use('/api/recruitment', recruitmentRoutes);
app.use('/api/training', trainingRoutes);
app.use('/api/hr', hrRoutes);
app.use('/api/leadership', leadershipRoutes);

// Central JSON error handler
app.use((err, req, res, next) => {
  console.error(err);
  const status = err.status || 500;
  res.status(status).json({ error: err.message || 'Serverfehler.' });
});

// Serve frontend (parent directory)
const frontendRoot = path.resolve(__dirname, '..');
app.use(express.static(frontendRoot, { extensions: ['html'] }));

app.use((req, res) => {
  res.status(404).sendFile(path.join(frontendRoot, '404.html'));
});

async function migrate() {
  await query(`CREATE TABLE IF NOT EXISTS evidence (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_no VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    category VARCHAR(80) NULL,
    location VARCHAR(120) NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'eingelagert',
    description TEXT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await query(`CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NULL,
    ref VARCHAR(40) NOT NULL,
    filename VARCHAR(190) NOT NULL,
    mime VARCHAR(80) NOT NULL DEFAULT 'application/pdf',
    size INT NOT NULL DEFAULT 0,
    data LONGBLOB NOT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_documents_ref (ref),
    INDEX idx_documents_application (application_id),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await query(`INSERT IGNORE INTO permissions (\`key\`, description) VALUES ('evidence.view','Asservaten einsehen'),('evidence.manage','Asservaten verwalten')`);
  await query(`INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES (1,'evidence.view'),(1,'evidence.manage'),(2,'evidence.view'),(2,'evidence.manage'),(3,'evidence.view')`);
  await query(`CREATE TABLE IF NOT EXISTS ticket_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    sender VARCHAR(20) NOT NULL DEFAULT 'citizen',
    author_name VARCHAR(120) NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ticket_messages_application (application_id),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await query(`CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  const { migrateAktensystem } = require('./src/migrate_aktensystem');
  await migrateAktensystem(query);
  const { migrateCitizen } = require('./src/migrate_citizen');
  await migrateCitizen(query);
  const { migrateAdmin } = require('./src/migrate_admin');
  await migrateAdmin(query);
  const { migratePersonal } = require('./src/migrate_personal');
  await migratePersonal(query);
}

migrate().then(() => {
  app.listen(PORT, () => {
    console.log(`LPT backend listening on http://127.0.0.1:${PORT}`);
  });
}).catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});