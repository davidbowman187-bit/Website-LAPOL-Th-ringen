const express = require('express');
const { query } = require('../src/db');
const { authMiddleware } = require('../src/auth');

const router = express.Router();

router.get('/', authMiddleware, async (req, res) => {
  const count = async (sql, params = []) => {
    const rows = await query(sql, params);
    return rows[0] ? Number(rows[0].c || rows[0].count || 0) : 0;
  };
  const stats = {
    reports: await count("SELECT COUNT(*) AS c FROM applications WHERE type IN ('einsatzbericht', 'report')"),
    strafanzeigen: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'strafanzeige'"),
    leading: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'leading_certificate'"),
    career: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'career'"),
    contact: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'contact'"),
    appointments: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'appointment'"),
    hints: await count("SELECT COUNT(*) AS c FROM applications WHERE type = 'hint'"),
    wanted: await count("SELECT COUNT(*) AS c FROM wanted_persons WHERE status = 'aktiv'"),
    news: await count("SELECT COUNT(*) AS c FROM news WHERE published = 1"),
    users: await count("SELECT COUNT(*) AS c FROM users"),
    stations: await count("SELECT COUNT(*) AS c FROM stations")
  };
  res.json({ stats });
});

module.exports = router;