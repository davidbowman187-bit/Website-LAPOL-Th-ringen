const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { audit } = require('../src/utils');

const router = express.Router();

const ALLOWED_STATUS = ['eingegangen', 'in_pruefung', 'in_bearbeitung', 'abgeschlossen', 'abgelehnt'];

// Ticketliste (Onlinewache)
router.get('/', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const status = String(req.query.status || '').trim();
  const q = String(req.query.q || '').trim();
  let sql = `SELECT a.*,
                    c.id AS citizen_account_id, c.discord_id AS citizen_discord_id,
                    c.username AS citizen_username, c.global_name AS citizen_global_name,
                    c.avatar AS citizen_avatar,
                    u.display_name AS assigned_name,
                    (SELECT COUNT(*) FROM ticket_messages m WHERE m.application_id = a.id) AS message_count,
                    (SELECT m.message FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_message,
                    (SELECT m.sender FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_sender,
                    (SELECT m.created_at FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_message_at
             FROM applications a
             LEFT JOIN citizen_accounts c ON c.id = a.citizen_id
             LEFT JOIN users u ON u.id = a.assigned_to
             WHERE a.type IN ('report','hint','strafanzeige','contact')`;
  sql += req.query.archived === '1' ? ' AND a.archived_at IS NOT NULL' : ' AND a.archived_at IS NULL';
  const params = [];
  if (status) { sql += ' AND a.status = ?'; params.push(status); }
  if (q) {
    sql += ' AND (a.ref LIKE ? OR a.applicant_name LIKE ? OR a.applicant_email LIKE ? OR a.payload LIKE ? OR c.username LIKE ? OR c.global_name LIKE ? OR c.discord_id LIKE ? OR u.display_name LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like, like, like);
  }
  sql += ' ORDER BY a.updated_at DESC, a.id DESC LIMIT 300';
  const rows = await query(sql, params);
  res.json({ tickets: rows });
});

// Ticketdetail inkl. Nachrichten
router.get('/:id', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query(
    `SELECT a.*,
            c.id AS citizen_account_id, c.discord_id AS citizen_discord_id,
            c.username AS citizen_username, c.global_name AS citizen_global_name,
            c.avatar AS citizen_avatar, c.last_login_at AS citizen_last_login,
            u.display_name AS assigned_name
     FROM applications a
     LEFT JOIN citizen_accounts c ON c.id = a.citizen_id
     LEFT JOIN users u ON u.id = a.assigned_to
     WHERE a.id = ? LIMIT 1`,
    [id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  const messages = await query(
    'SELECT id, sender, author_name, message, citizen_id, created_at FROM ticket_messages WHERE application_id = ? ORDER BY created_at ASC, id ASC',
    [id]
  );
  res.json({ ticket: rows[0], messages });
});

// Antwort der Polizei
router.post('/:id/messages', authMiddleware, requirePermission('applications.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const message = String(req.body && req.body.message ? req.body.message : '').trim();
  const status = req.body && req.body.status ? String(req.body.status) : '';
  if (!message) return res.status(400).json({ error: 'Nachricht ist erforderlich.' });
  if (message.length > 4000) return res.status(400).json({ error: 'Die Nachricht darf höchstens 4000 Zeichen lang sein.' });
  if (status && !ALLOWED_STATUS.includes(status)) return res.status(400).json({ error: 'Ungültiger Status.' });

  const rows = await query('SELECT id, ref, assigned_to FROM applications WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });

  const wasUnassigned = !rows[0].assigned_to;
  const assignedTo = rows[0].assigned_to || req.user.id;
  const assignedName = wasUnassigned ? (req.user.displayName || req.user.username) : null;

  const result = await query(
    'INSERT INTO ticket_messages (application_id, sender, author_name, message) VALUES (?,?,?,?)',
    [id, 'police', req.user.displayName || req.user.username, message]
  );
  if (status) {
    await query('UPDATE applications SET status = ?, assigned_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [status, assignedTo, id]);
  } else {
    await query('UPDATE applications SET assigned_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [assignedTo, id]);
  }
  await audit(null, req.user.id, 'ticket.reply', 'application', id, {
    ref: rows[0].ref,
    status: status || undefined,
    autoAssigned: wasUnassigned || undefined
  });
  res.status(201).json({
    ok: true,
    assigned_to: assignedTo,
    assigned_name: assignedName || undefined,
    message: {
      id: result.insertId,
      sender: 'police',
      author_name: req.user.displayName || req.user.username,
      message,
      created_at: new Date().toISOString()
    }
  });
});

// Ticket übernehmen / Bearbeitung abgeben
router.post('/:id/take', authMiddleware, requirePermission('applications.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT id, ref, assigned_to FROM applications WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  await query('UPDATE applications SET assigned_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [req.user.id, id]);
  await audit(null, req.user.id, 'ticket.take', 'application', id, { ref: rows[0].ref, previous: rows[0].assigned_to });
  res.json({
    ok: true,
    assigned_to: req.user.id,
    assigned_name: req.user.displayName || req.user.username
  });
});

router.post('/:id/release', authMiddleware, requirePermission('applications.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT id, ref, assigned_to FROM applications WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  await query('UPDATE applications SET assigned_to = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [id]);
  await audit(null, req.user.id, 'ticket.release', 'application', id, { ref: rows[0].ref, previous: rows[0].assigned_to });
  res.json({ ok: true, assigned_to: null, assigned_name: null });
});

router.post('/:id/archive', authMiddleware, requirePermission('archive.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT id, ref, status, archived_at FROM applications WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  if (rows[0].status !== 'abgeschlossen') {
    return res.status(409).json({ error: 'Nur abgeschlossene Tickets können archiviert werden.' });
  }
  await query('UPDATE applications SET archived_at = NOW(), archived_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [req.user.id, id]);
  await audit(null, req.user.id, 'ticket.archive', 'application', id, { ref: rows[0].ref });
  res.json({ ok: true, archived_at: new Date().toISOString() });
});

router.post('/:id/unarchive', authMiddleware, requirePermission('archive.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT id, ref FROM applications WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  await query('UPDATE applications SET archived_at = NULL, archived_by = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [id]);
  await audit(null, req.user.id, 'ticket.unarchive', 'application', id, { ref: rows[0].ref });
  res.json({ ok: true, archived_at: null });
});

module.exports = router;
