const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { audit } = require('../src/utils');

const router = express.Router();

function normalize(row) {
  return {
    id: row.id,
    key: row.phase_key,
    label: row.label,
    isOpen: Boolean(row.is_open),
    note: row.note || '',
    sortOrder: row.sort_order,
    updatedAt: row.updated_at
  };
}

router.get('/', async (req, res) => {
  const rows = await query('SELECT * FROM recruitment_phases ORDER BY sort_order ASC, id ASC');
  res.json({ phases: rows.map(normalize) });
});

router.patch('/:key', authMiddleware, requirePermission('recruitment.manage'), async (req, res) => {
  const key = String(req.params.key || '').trim();
  const rows = await query('SELECT * FROM recruitment_phases WHERE phase_key = ? LIMIT 1', [key]);
  if (!rows.length) return res.status(404).json({ error: 'Bewerbungsbereich nicht gefunden.' });
  const body = req.body || {};
  const isOpen = typeof body.isOpen === 'boolean' ? body.isOpen : Boolean(rows[0].is_open);
  const note = body.note !== undefined ? String(body.note || '').slice(0, 255) : rows[0].note;
  await query(
    'UPDATE recruitment_phases SET is_open = ?, note = ?, updated_by = ?, updated_at = NOW() WHERE phase_key = ?',
    [isOpen ? 1 : 0, note, req.user.id, key]
  );
  await audit(null, req.user.id, 'recruitment.update', 'recruitment_phase', rows[0].id, { isOpen, note });
  const updated = await query('SELECT * FROM recruitment_phases WHERE phase_key = ? LIMIT 1', [key]);
  res.json({ phase: normalize(updated[0]) });
});

module.exports = router;
