const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, toJson, slugify, audit } = require('../src/utils');

const router = express.Router();

// Public list
router.get('/', async (req, res) => {
  const rows = await query('SELECT * FROM wanted_persons WHERE status = ? ORDER BY created_at DESC', ['aktiv']);
  res.json({ wanted: rows.map((r) => ({ ...r, facts: safeJson(r.facts, []) })) });
});

// Public single
router.get('/:caseNo', async (req, res) => {
  const rows = await query('SELECT * FROM wanted_persons WHERE case_no = ? LIMIT 1', [req.params.caseNo]);
  if (!rows.length) return res.status(404).json({ error: 'Fahndung nicht gefunden.' });
  const r = rows[0];
  res.json({ wanted: { ...r, facts: safeJson(r.facts, []) } });
});

// Create (authorized)
router.post('/', authMiddleware, requirePermission('wanted.manage'), async (req, res) => {
  const { caseNo, category, title, location, teaser, description, facts, hint, icon, status } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const cn = caseNo || `F-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
  const result = await query(
    `INSERT INTO wanted_persons (case_no, category, title, location, teaser, description, facts, hint, icon, status, created_by)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [cn, category || 'person', title, location || null, teaser || null, description || null, toJson(facts || []), hint || null, icon || null, status || 'aktiv', req.user.id]
  );
  await audit(null, req.user.id, 'wanted.create', 'wanted', result.insertId, { caseNo: cn, title });
  res.status(201).json({ id: result.insertId, caseNo: cn });
});

router.patch('/:id', authMiddleware, requirePermission('wanted.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const fields = ['category', 'title', 'location', 'teaser', 'description', 'hint', 'icon', 'status'];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      await query(`UPDATE wanted_persons SET ${f} = ? WHERE id = ?`, [req.body[f], id]);
    }
  }
  if (req.body.facts !== undefined) {
    await query('UPDATE wanted_persons SET facts = ? WHERE id = ?', [toJson(req.body.facts), id]);
  }
  await audit(null, req.user.id, 'wanted.update', 'wanted', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('wanted.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM wanted_persons WHERE id = ?', [id]);
  await audit(null, req.user.id, 'wanted.delete', 'wanted', id, null);
  res.json({ ok: true });
});

// Admin list all (including inactive)
router.get('/admin/all', authMiddleware, requirePermission('wanted.view'), async (req, res) => {
  const rows = await query('SELECT * FROM wanted_persons ORDER BY created_at DESC');
  res.json({ wanted: rows.map((r) => ({ ...r, facts: safeJson(r.facts, []) })) });
});

module.exports = router;