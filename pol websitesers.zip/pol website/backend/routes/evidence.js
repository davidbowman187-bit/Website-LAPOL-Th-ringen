const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, toJson, audit } = require('../src/utils');

const router = express.Router();

router.get('/', authMiddleware, requirePermission('evidence.view'), async (req, res) => {
  const rows = await query('SELECT * FROM evidence ORDER BY created_at DESC');
  res.json({ evidence: rows });
});

router.post('/', authMiddleware, requirePermission('evidence.manage'), async (req, res) => {
  const { itemNo, title, category, location, status, description } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const no = itemNo || `ASV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const result = await query(
    `INSERT INTO evidence (item_no, title, category, location, status, description, created_by)
     VALUES (?,?,?,?,?,?,?)`,
    [no, title, category || null, location || null, status || 'eingelagert', description || null, req.user.id]
  );
  await audit(null, req.user.id, 'evidence.create', 'evidence', result.insertId, { itemNo: no, title });
  res.status(201).json({ id: result.insertId, itemNo: no });
});

router.patch('/:id', authMiddleware, requirePermission('evidence.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const fields = ['title', 'category', 'location', 'status', 'description'];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      await query(`UPDATE evidence SET ${f} = ? WHERE id = ?`, [req.body[f], id]);
    }
  }
  await audit(null, req.user.id, 'evidence.update', 'evidence', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('evidence.manage'), async (req, res) => {
  await query('DELETE FROM evidence WHERE id = ?', [Number(req.params.id)]);
  await audit(null, req.user.id, 'evidence.delete', 'evidence', req.params.id, null);
  res.json({ ok: true });
});

module.exports = router;