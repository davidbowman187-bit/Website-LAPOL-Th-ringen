const express = require('express');
const bcrypt = require('bcryptjs');
const { query } = require('../src/db');
const { signToken, loadUser } = require('../src/auth');

const router = express.Router();

router.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Benutzername und Passwort sind erforderlich.' });
  const rows = await query('SELECT * FROM users WHERE username = ? LIMIT 1', [username]);
  if (!rows.length) return res.status(401).json({ error: 'Ungültige Anmeldedaten.' });
  const user = rows[0];
  if (!user.active) return res.status(403).json({ error: 'Benutzer ist deaktiviert.' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Ungültige Anmeldedaten.' });
  await query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);
  const full = await loadUser(user.id);
  const token = signToken(full);
  res.json({
    token,
    user: {
      id: full.id,
      username: full.username,
      displayName: full.display_name,
      rankId: full.rank_id,
      rankName: full.rank_name,
      permissions: full.permissions
    }
  });
});

router.get('/me', require('../src/auth').authMiddleware, async (req, res) => {
  const full = await loadUser(req.user.id);
  res.json({
    user: {
      id: full.id,
      username: full.username,
      displayName: full.display_name,
      rankId: full.rank_id,
      rankName: full.rank_name,
      permissions: full.permissions
    }
  });
});

module.exports = router;