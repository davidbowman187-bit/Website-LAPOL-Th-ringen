const express = require('express');
const crypto = require('node:crypto');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, toJson, audit } = require('../src/utils');

const router = express.Router();

const MAX_DOC_BYTES = 8 * 1024 * 1024;
const ALLOWED_DOC_TYPES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
]);

function parseDocument(body) {
  const title = String(body && body.title ? body.title : '').trim().slice(0, 190);
  const filename = String(body && body.filename ? body.filename : '').trim().slice(0, 190);
  const mime = String(body && body.mime ? body.mime : '').trim().toLowerCase();
  const raw = String(body && body.data ? body.data : '');
  if (!title || !filename) return { error: 'Titel und Datei sind erforderlich.' };
  if (!ALLOWED_DOC_TYPES.has(mime)) return { error: 'Erlaubt sind PDF, JPG, PNG, DOC und DOCX.' };
  const base64 = raw.includes(',') ? raw.split(',').pop() : raw;
  const buffer = Buffer.from(base64, 'base64');
  if (!buffer.length) return { error: 'Die Datei ist leer.' };
  if (buffer.length > MAX_DOC_BYTES) return { error: 'Die Datei darf höchstens 8 MB groß sein.' };
  return { title, filename, mime, buffer, size: buffer.length };
}

function parseQuestions(input) {
  if (!Array.isArray(input)) return [];
  return input.map((q, index) => {
    const question = String(q && q.question ? q.question : '').trim();
    const options = Array.isArray(q && q.options) ? q.options.map((v) => String(v).trim()).filter(Boolean) : [];
    const correctIndex = Number(q && q.correctIndex != null ? q.correctIndex : 0);
    if (!question || options.length < 2) return null;
    return {
      question,
      options,
      correctIndex: Math.max(0, Math.min(correctIndex, options.length - 1)),
      sortOrder: index + 1
    };
  }).filter(Boolean);
}

async function insertQuestions(testId, questions) {
  for (const q of questions) {
    await query(
      'INSERT INTO training_test_questions (test_id, question, options, correct_index, sort_order) VALUES (?,?,?,?,?)',
      [testId, q.question, toJson(q.options), q.correctIndex, q.sortOrder]
    );
  }
}

/* ---------- Ausbildungen ---------- */

router.get('/trainings', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const rows = await query(
    `SELECT t.*,
       (SELECT COUNT(*) FROM training_documents d WHERE d.training_id = t.id) AS document_count,
       (SELECT COUNT(*) FROM training_tests x WHERE x.training_id = t.id) AS test_count
     FROM trainings t ORDER BY t.created_at DESC, t.id DESC`
  );
  res.json({ trainings: rows });
});

router.post('/trainings', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const body = req.body || {};
  const title = String(body.title || '').trim();
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const result = await query(
    'INSERT INTO trainings (title, description, start_date, end_date, status, created_by) VALUES (?,?,?,?,?,?)',
    [title, String(body.description || '').trim(), body.startDate || null, body.endDate || null, String(body.status || 'geplant'), req.user.id]
  );
  await audit(null, req.user.id, 'training.create', 'training', result.insertId, { title });
  res.status(201).json({ id: result.insertId });
});

router.get('/trainings/:id', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT * FROM trainings WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ausbildung nicht gefunden.' });
  const documents = await query(
    'SELECT id, title, filename, mime, size, created_at FROM training_documents WHERE training_id = ? ORDER BY id ASC',
    [id]
  );
  const tests = await query(
    `SELECT t.id, t.title, t.public_code, t.pass_score, t.is_active,
       (SELECT COUNT(*) FROM training_test_questions q WHERE q.test_id = t.id) AS question_count,
       (SELECT COUNT(*) FROM training_test_results r WHERE r.test_id = t.id) AS result_count
     FROM training_tests t WHERE t.training_id = ? ORDER BY t.created_at DESC`,
    [id]
  );
  res.json({ training: rows[0], documents, tests });
});

router.patch('/trainings/:id', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT * FROM trainings WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Ausbildung nicht gefunden.' });
  const body = req.body || {};
  const current = rows[0];
  await query(
    'UPDATE trainings SET title = ?, description = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?',
    [
      body.title !== undefined ? String(body.title).trim() : current.title,
      body.description !== undefined ? String(body.description || '').trim() : current.description,
      body.startDate !== undefined ? (body.startDate || null) : current.start_date,
      body.endDate !== undefined ? (body.endDate || null) : current.end_date,
      body.status !== undefined ? String(body.status) : current.status,
      id
    ]
  );
  await audit(null, req.user.id, 'training.update', 'training', id, { title: body.title });
  res.json({ ok: true });
});

router.delete('/trainings/:id', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM trainings WHERE id = ?', [id]);
  await audit(null, req.user.id, 'training.delete', 'training', id, null);
  res.json({ ok: true });
});

router.post('/trainings/:id/documents', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const training = await query('SELECT id FROM trainings WHERE id = ? LIMIT 1', [id]);
  if (!training.length) return res.status(404).json({ error: 'Ausbildung nicht gefunden.' });
  const doc = parseDocument(req.body || {});
  if (doc.error) return res.status(400).json({ error: doc.error });
  const result = await query(
    'INSERT INTO training_documents (training_id, title, filename, mime, size, data, created_by) VALUES (?,?,?,?,?,?,?)',
    [id, doc.title, doc.filename, doc.mime, doc.size, doc.buffer, req.user.id]
  );
  await audit(null, req.user.id, 'training.document.create', 'training', id, { documentId: result.insertId, title: doc.title });
  res.status(201).json({ id: result.insertId });
});

router.get('/trainings/:id/documents/:docId/download', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const rows = await query(
    'SELECT filename, mime, data FROM training_documents WHERE id = ? AND training_id = ? LIMIT 1',
    [Number(req.params.docId), Number(req.params.id)]
  );
  if (!rows.length) return res.status(404).json({ error: 'Dokument nicht gefunden.' });
  const file = rows[0];
  res.setHeader('Content-Type', file.mime || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${String(file.filename || 'dokument').replace(/["\\]/g, '_')}"`);
  res.send(file.data);
});

router.delete('/trainings/:id/documents/:docId', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  await query('DELETE FROM training_documents WHERE id = ? AND training_id = ?', [Number(req.params.docId), Number(req.params.id)]);
  await audit(null, req.user.id, 'training.document.delete', 'training', Number(req.params.id), { documentId: Number(req.params.docId) });
  res.json({ ok: true });
});

/* ---------- Tests ---------- */

router.get('/tests', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const rows = await query(
    `SELECT t.*, tr.title AS training_title,
       (SELECT COUNT(*) FROM training_test_questions q WHERE q.test_id = t.id) AS question_count,
       (SELECT COUNT(*) FROM training_test_results r WHERE r.test_id = t.id) AS result_count,
       (SELECT COUNT(*) FROM training_test_results r WHERE r.test_id = t.id AND r.passed = 1) AS passed_count
     FROM training_tests t LEFT JOIN trainings tr ON tr.id = t.training_id
     ORDER BY t.created_at DESC, t.id DESC`
  );
  res.json({ tests: rows });
});

router.get('/results', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const rows = await query(
    `SELECT r.*, t.title AS test_title, t.public_code, a.ref AS application_ref
     FROM training_test_results r
     JOIN training_tests t ON t.id = r.test_id
     LEFT JOIN applications a ON a.id = r.application_id
     ORDER BY r.taken_at DESC, r.id DESC LIMIT 500`
  );
  res.json({ results: rows });
});

router.get('/tests/:id', authMiddleware, requirePermission('training.view'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query(
    `SELECT t.*, tr.title AS training_title FROM training_tests t
     LEFT JOIN trainings tr ON tr.id = t.training_id WHERE t.id = ? LIMIT 1`,
    [id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Test nicht gefunden.' });
  const questions = await query(
    'SELECT * FROM training_test_questions WHERE test_id = ? ORDER BY sort_order ASC, id ASC',
    [id]
  );
  const results = await query(
    `SELECT r.*, a.ref AS application_ref FROM training_test_results r
     LEFT JOIN applications a ON a.id = r.application_id
     WHERE r.test_id = ? ORDER BY r.taken_at DESC, r.id DESC`,
    [id]
  );
  res.json({
    test: rows[0],
    questions: questions.map((q) => ({ ...q, options: safeJson(q.options, []) })),
    results
  });
});

router.post('/tests', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const body = req.body || {};
  const title = String(body.title || '').trim();
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const questions = parseQuestions(body.questions);
  if (!questions.length) return res.status(400).json({ error: 'Mindestens eine vollständige Frage ist erforderlich.' });
  const passScore = Math.max(0, Math.min(100, Number(body.passScore || 70)));
  const publicCode = 'T-' + crypto.randomBytes(3).toString('hex').toUpperCase();
  const result = await query(
    `INSERT INTO training_tests (training_id, title, description, pass_score, public_code, is_active, created_by)
     VALUES (?,?,?,?,?,?,?)`,
    [body.trainingId ? Number(body.trainingId) : null, title, String(body.description || '').trim(), passScore, publicCode, body.isActive === false ? 0 : 1, req.user.id]
  );
  await insertQuestions(result.insertId, questions);
  await audit(null, req.user.id, 'training.test.create', 'training_test', result.insertId, { title, publicCode });
  res.status(201).json({ id: result.insertId, publicCode });
});

router.patch('/tests/:id', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT * FROM training_tests WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Test nicht gefunden.' });
  const body = req.body || {};
  const current = rows[0];
  await query(
    'UPDATE training_tests SET training_id = ?, title = ?, description = ?, pass_score = ?, is_active = ? WHERE id = ?',
    [
      body.trainingId !== undefined ? (body.trainingId ? Number(body.trainingId) : null) : current.training_id,
      body.title !== undefined ? String(body.title).trim() : current.title,
      body.description !== undefined ? String(body.description || '').trim() : current.description,
      body.passScore !== undefined ? Math.max(0, Math.min(100, Number(body.passScore))) : current.pass_score,
      body.isActive !== undefined ? (body.isActive ? 1 : 0) : current.is_active,
      id
    ]
  );
  if (Array.isArray(body.questions)) {
    const questions = parseQuestions(body.questions);
    if (!questions.length) return res.status(400).json({ error: 'Mindestens eine vollständige Frage ist erforderlich.' });
    await query('DELETE FROM training_test_questions WHERE test_id = ?', [id]);
    await insertQuestions(id, questions);
  }
  await audit(null, req.user.id, 'training.test.update', 'training_test', id, { title: body.title });
  res.json({ ok: true });
});

router.delete('/tests/:id', authMiddleware, requirePermission('training.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM training_tests WHERE id = ?', [id]);
  await audit(null, req.user.id, 'training.test.delete', 'training_test', id, null);
  res.json({ ok: true });
});

/* ---------- Öffentlicher Bewerber-Test ---------- */

router.get('/public/:code', async (req, res) => {
  const code = String(req.params.code || '').trim().toUpperCase();
  const rows = await query(
    `SELECT t.*, tr.title AS training_title FROM training_tests t
     LEFT JOIN trainings tr ON tr.id = t.training_id
     WHERE t.public_code = ? AND t.is_active = 1 LIMIT 1`,
    [code]
  );
  if (!rows.length) return res.status(404).json({ error: 'Test nicht gefunden oder nicht aktiv.' });
  const test = rows[0];
  const questions = await query(
    'SELECT id, question, options, sort_order FROM training_test_questions WHERE test_id = ? ORDER BY sort_order ASC, id ASC',
    [test.id]
  );
  res.json({
    test: {
      id: test.id,
      title: test.title,
      description: test.description,
      passScore: test.pass_score,
      code: test.public_code,
      trainingTitle: test.training_title
    },
    questions: questions.map((q) => ({
      id: q.id,
      question: q.question,
      options: safeJson(q.options, []),
      sortOrder: q.sort_order
    }))
  });
});

router.post('/public/:code/submit', async (req, res) => {
  const code = String(req.params.code || '').trim().toUpperCase();
  const body = req.body || {};
  const applicantName = String(body.applicantName || '').trim();
  const applicationRef = String(body.applicationRef || '').trim();
  if (!applicantName) return res.status(400).json({ error: 'Bitte geben Sie Ihren Namen an.' });
  if (!applicationRef) return res.status(400).json({ error: 'Bitte geben Sie Ihr Bewerbungs-Aktenzeichen an.' });

  const tests = await query(
    'SELECT * FROM training_tests WHERE public_code = ? AND is_active = 1 LIMIT 1',
    [code]
  );
  if (!tests.length) return res.status(404).json({ error: 'Test nicht gefunden oder nicht aktiv.' });
  const test = tests[0];

  const apps = await query(
    "SELECT id, applicant_name FROM applications WHERE ref = ? AND type = 'career' LIMIT 1",
    [applicationRef]
  );
  if (!apps.length) return res.status(404).json({ error: 'Bewerbung nicht gefunden. Bitte prüfen Sie das Aktenzeichen.' });

  const questions = await query(
    'SELECT id, question, options, correct_index FROM training_test_questions WHERE test_id = ? ORDER BY sort_order ASC, id ASC',
    [test.id]
  );
  if (!questions.length) return res.status(409).json({ error: 'Dieser Test hat noch keine Fragen.' });

  const answers = body.answers && typeof body.answers === 'object' ? body.answers : {};
  let correct = 0;
  questions.forEach((q) => {
    const answer = Number(answers[String(q.id)]);
    if (answer === Number(q.correct_index)) correct += 1;
  });
  const score = Math.round((correct / questions.length) * 100);
  const passed = score >= Number(test.pass_score || 70);
  await query(
    'INSERT INTO training_test_results (test_id, application_id, applicant_name, score, passed, answers) VALUES (?,?,?,?,?,?)',
    [test.id, apps[0].id, applicantName, score, passed ? 1 : 0, toJson(answers)]
  );
  res.status(201).json({
    score,
    passed,
    correct,
    total: questions.length,
    passScore: Number(test.pass_score || 70),
    testTitle: test.title
  });
});

module.exports = router;
