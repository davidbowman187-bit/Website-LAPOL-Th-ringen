const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { audit } = require('../src/utils');

const router = express.Router();

router.get('/summary', authMiddleware, requirePermission('leadership.view'), async (req, res) => {
  const applications = await query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status NOT IN ('abgeschlossen','abgelehnt') THEN 1 ELSE 0 END) AS open,
            SUM(CASE WHEN type = 'career' THEN 1 ELSE 0 END) AS career
     FROM applications WHERE archived_at IS NULL`
  );
  const tickets = await query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status NOT IN ('abgeschlossen','abgelehnt') THEN 1 ELSE 0 END) AS open
     FROM applications WHERE type IN ('report','hint','strafanzeige','contact') AND archived_at IS NULL`
  );
  const trainings = await query('SELECT COUNT(*) AS total, SUM(CASE WHEN status = \'laufend\' THEN 1 ELSE 0 END) AS active FROM trainings');
  const tests = await query(
    `SELECT (SELECT COUNT(*) FROM training_tests) AS total,
            (SELECT COUNT(*) FROM training_test_results) AS attempts,
            (SELECT COUNT(*) FROM training_test_results WHERE passed = 1) AS passed`
  );
  const users = await query('SELECT COUNT(*) AS total, SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END) AS active FROM users');
  const phases = await query('SELECT phase_key, label, is_open FROM recruitment_phases ORDER BY sort_order ASC');
  res.json({
    applications: {
      total: Number(applications[0]?.total || 0),
      open: Number(applications[0]?.open || 0),
      career: Number(applications[0]?.career || 0)
    },
    tickets: {
      total: Number(tickets[0]?.total || 0),
      open: Number(tickets[0]?.open || 0)
    },
    trainings: {
      total: Number(trainings[0]?.total || 0),
      active: Number(trainings[0]?.active || 0)
    },
    tests: {
      total: Number(tests[0]?.total || 0),
      attempts: Number(tests[0]?.attempts || 0),
      passed: Number(tests[0]?.passed || 0)
    },
    users: {
      total: Number(users[0]?.total || 0),
      active: Number(users[0]?.active || 0)
    },
    phases
  });
});

router.get('/notes', authMiddleware, requirePermission('leadership.view'), async (req, res) => {
  const rows = await query('SELECT * FROM leadership_notes ORDER BY CASE status WHEN \'offen\' THEN 0 ELSE 1 END, created_at DESC');
  res.json({ notes: rows });
});

router.post('/notes', authMiddleware, requirePermission('leadership.manage'), async (req, res) => {
  const body = req.body || {};
  const title = String(body.title || '').trim();
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const result = await query(
    'INSERT INTO leadership_notes (title, body, priority, status, created_by) VALUES (?,?,?,?,?)',
    [title, String(body.body || '').trim(), String(body.priority || 'normal'), String(body.status || 'offen'), req.user.id]
  );
  await audit(null, req.user.id, 'leadership.note.create', 'leadership_note', result.insertId, { title });
  res.status(201).json({ id: result.insertId });
});

router.patch('/notes/:id', authMiddleware, requirePermission('leadership.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query('SELECT * FROM leadership_notes WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Notiz nicht gefunden.' });
  const body = req.body || {};
  const current = rows[0];
  await query(
    'UPDATE leadership_notes SET title = ?, body = ?, priority = ?, status = ? WHERE id = ?',
    [
      body.title !== undefined ? String(body.title).trim() : current.title,
      body.body !== undefined ? String(body.body || '').trim() : current.body,
      body.priority !== undefined ? String(body.priority) : current.priority,
      body.status !== undefined ? String(body.status) : current.status,
      id
    ]
  );
  await audit(null, req.user.id, 'leadership.note.update', 'leadership_note', id, { title: body.title });
  res.json({ ok: true });
});

router.delete('/notes/:id', authMiddleware, requirePermission('leadership.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM leadership_notes WHERE id = ?', [id]);
  await audit(null, req.user.id, 'leadership.note.delete', 'leadership_note', id, null);
  res.json({ ok: true });
});

module.exports = router;
