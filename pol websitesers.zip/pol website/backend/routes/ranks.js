const express = require('express');
const bcrypt = require('bcryptjs');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { toJson } = require('../src/utils');

const router = express.Router();

// Permissions list
router.get('/permissions', authMiddleware, requirePermission('ranks.view'), async (req, res) => {
  const rows = await query('SELECT * FROM permissions ORDER BY `key`');
  res.json({ permissions: rows });
});

// Ranks
router.get('/ranks', authMiddleware, requirePermission('ranks.view'), async (req, res) => {
  const ranks = await query('SELECT * FROM ranks ORDER BY id ASC, name');
  const perms = await query('SELECT * FROM rank_permissions');
  const map = new Map();
  ranks.forEach((r) => { map.set(r.id, { ...r, permissions: [] }); });
  perms.forEach((p) => {
    if (map.has(p.rank_id)) map.get(p.rank_id).permissions.push(p.permission_key);
  });
  res.json({ ranks: Array.from(map.values()) });
});

router.post('/ranks', authMiddleware, requirePermission('ranks.manage'), async (req, res) => {
  const { name, description, permissions } = req.body || {};
  if (!name) return res.status(400).json({ error: 'Name ist erforderlich.' });
  const result = await query('INSERT INTO ranks (name, description) VALUES (?,?)',
    [name, description || null]);
  const rankId = result.insertId;
  if (Array.isArray(permissions)) {
    for (const key of permissions) {
      await query('INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES (?,?)', [rankId, key]);
    }
  }
  res.status(201).json({ id: rankId });
});

router.patch('/ranks/:id', authMiddleware, requirePermission('ranks.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const { name, description, permissions } = req.body || {};
  await query('UPDATE ranks SET name = COALESCE(?, name), description = COALESCE(?, description) WHERE id = ?',
    [name || null, description !== undefined ? description : null, id]);
  if (Array.isArray(permissions)) {
    await query('DELETE FROM rank_permissions WHERE rank_id = ?', [id]);
    for (const key of permissions) {
      await query('INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES (?,?)', [id, key]);
    }
  }
  res.json({ ok: true });
});

router.delete('/ranks/:id', authMiddleware, requirePermission('ranks.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const users = await query('SELECT COUNT(*) AS c FROM users WHERE rank_id = ?', [id]);
  if (users[0].c > 0) return res.status(400).json({ error: 'Rang wird noch von Benutzern verwendet.' });
  await query('DELETE FROM ranks WHERE id = ?', [id]);
  res.json({ ok: true });
});

// Users
router.get('/users', authMiddleware, requirePermission('users.view'), async (req, res) => {
  const rows = await query(
    `SELECT u.id, u.username, u.display_name, u.rank_id, u.active, u.last_login, u.created_at, r.name AS rank_name
     FROM users u JOIN ranks r ON r.id = u.rank_id ORDER BY r.id ASC, u.username`
  );
  res.json({ users: rows });
});

router.post('/users', authMiddleware, requirePermission('users.manage'), async (req, res) => {
  const { username, password, displayName, rankId } = req.body || {};
  if (!username || !password || !displayName || !rankId) return res.status(400).json({ error: 'Alle Felder sind erforderlich.' });
  const hash = await bcrypt.hash(password, 10);
  const result = await query(
    'INSERT INTO users (username, password_hash, display_name, rank_id) VALUES (?,?,?,?)',
    [username, hash, displayName, Number(rankId)]
  );
  res.status(201).json({ id: result.insertId });
});

router.patch('/users/:id', authMiddleware, requirePermission('users.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const { displayName, rankId, active, password } = req.body || {};
  if (displayName !== undefined) await query('UPDATE users SET display_name = ? WHERE id = ?', [displayName, id]);
  if (rankId !== undefined) await query('UPDATE users SET rank_id = ? WHERE id = ?', [Number(rankId), id]);
  if (active !== undefined) await query('UPDATE users SET active = ? WHERE id = ?', [active ? 1 : 0, id]);
  if (password) {
    const hash = await bcrypt.hash(password, 10);
    await query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, id]);
  }
  res.json({ ok: true });
});

router.delete('/users/:id', authMiddleware, requirePermission('users.manage'), async (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'Eigenes Konto kann nicht gelöscht werden.' });
  await query('DELETE FROM users WHERE id = ?', [id]);
  res.json({ ok: true });
});

module.exports = router;