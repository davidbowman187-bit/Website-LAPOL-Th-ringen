const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, toJson, slugify, audit } = require('../src/utils');

const router = express.Router();

router.get('/', async (req, res) => {
  const rows = await query('SELECT * FROM news WHERE published = 1 ORDER BY featured DESC, created_at DESC');
  res.json({ news: rows.map((r) => ({ ...r, body: safeJson(r.body, []) })) });
});

router.get('/:slug', async (req, res) => {
  const rows = await query('SELECT * FROM news WHERE slug = ? LIMIT 1', [req.params.slug]);
  if (!rows.length) return res.status(404).json({ error: 'Meldung nicht gefunden.' });
  const r = rows[0];
  res.json({ news: { ...r, body: safeJson(r.body, []) } });
});

router.post('/', authMiddleware, requirePermission('news.manage'), async (req, res) => {
  const { slug, category, label, title, teaser, location, reading, featured, icon, body, published } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const s = slug || slugify(title);
  const result = await query(
    `INSERT INTO news (slug, category, label, title, teaser, location, reading, featured, icon, body, published, created_by)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [s, category || 'presse', label || 'Presse', title, teaser || null, location || null, Number(reading || 1), featured ? 1 : 0, icon || null, toJson(body || []), published === false ? 0 : 1, req.user.id]
  );
  await audit(null, req.user.id, 'news.create', 'news', result.insertId, { title });
  res.status(201).json({ id: result.insertId, slug: s });
});

router.patch('/:id', authMiddleware, requirePermission('news.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const fields = ['category', 'label', 'title', 'teaser', 'location', 'reading', 'featured', 'icon', 'published'];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      const val = f === 'featured' || f === 'published' ? (req.body[f] ? 1 : 0) : req.body[f];
      await query(`UPDATE news SET ${f} = ? WHERE id = ?`, [val, id]);
    }
  }
  if (req.body.body !== undefined) {
    await query('UPDATE news SET body = ? WHERE id = ?', [toJson(req.body.body), id]);
  }
  if (req.body.slug !== undefined) {
    await query('UPDATE news SET slug = ? WHERE id = ?', [req.body.slug, id]);
  }
  await audit(null, req.user.id, 'news.update', 'news', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('news.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM news WHERE id = ?', [id]);
  await audit(null, req.user.id, 'news.delete', 'news', id, null);
  res.json({ ok: true });
});

router.get('/admin/all', authMiddleware, requirePermission('news.view'), async (req, res) => {
  const rows = await query('SELECT * FROM news ORDER BY created_at DESC');
  res.json({ news: rows.map((r) => ({ ...r, body: safeJson(r.body, []) })) });
});

module.exports = router;