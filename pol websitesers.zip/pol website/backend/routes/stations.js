const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, toJson, audit } = require('../src/utils');

const router = express.Router();

router.get('/', async (req, res) => {
  const rows = await query('SELECT * FROM stations ORDER BY city');
  res.json({ stations: rows.map((r) => ({ ...r, services: safeJson(r.services, []) })) });
});

router.get('/:id', async (req, res) => {
  const rows = await query('SELECT * FROM stations WHERE id = ? LIMIT 1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Dienststelle nicht gefunden.' });
  const r = rows[0];
  res.json({ station: { ...r, services: safeJson(r.services, []) } });
});

router.post('/', authMiddleware, requirePermission('stations.manage'), async (req, res) => {
  const { id, name, city, region, address, phone, email, hours, services, x, y } = req.body || {};
  if (!id || !name || !city) return res.status(400).json({ error: 'ID, Name und Stadt sind erforderlich.' });
  await query(
    `INSERT INTO stations (id,name,city,region,address,phone,email,hours,services,x,y)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [id, name, city, region || '', address || '', phone || '', email || '', hours || '', toJson(services || []), Number(x || 50), Number(y || 50)]
  );
  await audit(null, req.user.id, 'station.create', 'station', id, { name, city });
  res.status(201).json({ id });
});

router.patch('/:id', authMiddleware, requirePermission('stations.manage'), async (req, res) => {
  const id = req.params.id;
  const fields = ['name', 'city', 'region', 'address', 'phone', 'email', 'hours', 'x', 'y'];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      const val = (f === 'x' || f === 'y') ? Number(req.body[f]) : req.body[f];
      await query(`UPDATE stations SET ${f} = ? WHERE id = ?`, [val, id]);
    }
  }
  if (req.body.services !== undefined) {
    await query('UPDATE stations SET services = ? WHERE id = ?', [toJson(req.body.services), id]);
  }
  await audit(null, req.user.id, 'station.update', 'station', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('stations.manage'), async (req, res) => {
  await query('DELETE FROM stations WHERE id = ?', [req.params.id]);
  await audit(null, req.user.id, 'station.delete', 'station', req.params.id, null);
  res.json({ ok: true });
});

module.exports = router;