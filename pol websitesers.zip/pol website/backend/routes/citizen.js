const express = require('express');
const crypto = require('node:crypto');
const { query } = require('../src/db');
const { safeJson } = require('../src/utils');
const {
  STATE_COOKIE,
  NEXT_COOKIE,
  parseCookies,
  hashToken,
  safeNextPath,
  discordConfigured,
  requestIsSecure,
  discordRedirectUri,
  mapCitizen,
  recordCitizenEvent,
  optionalCitizen,
  requireCitizen,
  createCitizenSession
} = require('../src/citizenAuth');

const router = express.Router();

const TICKET_TYPES = ['report', 'hint', 'strafanzeige', 'contact'];
const DISCORD_API_BASE = (process.env.DISCORD_API_BASE || 'https://discord.com/api').replace(/\/$/, '');
const DISCORD_AUTHORIZE_URL = process.env.DISCORD_AUTHORIZE_URL || 'https://discord.com/oauth2/authorize';
const STATUS_TEXT = {
  eingegangen: 'Ihr Anliegen ist bei der Landespolizei eingegangen und wird geprüft.',
  in_pruefung: 'Ihr Anliegen wird derzeit geprüft.',
  in_bearbeitung: 'Ihr Vorgang wird derzeit bearbeitet.',
  abgeschlossen: 'Ihr Vorgang wurde abgeschlossen.',
  abgelehnt: 'Ihr Vorgang konnte nicht weiterbearbeitet werden.'
};

router.use(optionalCitizen);

router.get('/config', (req, res) => {
  res.json({
    discordConfigured: discordConfigured(),
    loginUrl: '/api/citizen/auth/discord'
  });
});

router.get('/auth/discord', (req, res) => {
  if (!discordConfigured()) {
    return res.redirect('/meine-tickets.html?login=konfiguration');
  }
  const next = safeNextPath(req.query.next, '/meine-tickets.html');
  const state = crypto.randomBytes(24).toString('hex');
  const secure = requestIsSecure(req);
  res.cookie(STATE_COOKIE, state, {
    httpOnly: true,
    sameSite: 'lax',
    secure,
    path: '/',
    maxAge: 10 * 60 * 1000
  });
  res.cookie(NEXT_COOKIE, next, {
    httpOnly: true,
    sameSite: 'lax',
    secure,
    path: '/',
    maxAge: 10 * 60 * 1000
  });

  const target = new URL(DISCORD_AUTHORIZE_URL);
  target.searchParams.set('client_id', process.env.DISCORD_CLIENT_ID);
  target.searchParams.set('response_type', 'code');
  target.searchParams.set('redirect_uri', discordRedirectUri(req));
  target.searchParams.set('scope', 'identify');
  target.searchParams.set('state', state);
  res.redirect(target.toString());
});

router.get('/auth/discord/callback', async (req, res) => {
  const cookies = parseCookies(req);
  const next = safeNextPath(cookies[NEXT_COOKIE], '/meine-tickets.html');
  const clearOauthCookies = () => {
    res.clearCookie(STATE_COOKIE, { path: '/' });
    res.clearCookie(NEXT_COOKIE, { path: '/' });
  };

  if (!discordConfigured()) {
    clearOauthCookies();
    return res.redirect('/meine-tickets.html?login=konfiguration');
  }
  if (req.query.error) {
    clearOauthCookies();
    return res.redirect('/meine-tickets.html?login=abgebrochen');
  }
  const state = String(req.query.state || '');
  if (!state || !cookies[STATE_COOKIE] || state !== cookies[STATE_COOKIE]) {
    clearOauthCookies();
    return res.redirect('/meine-tickets.html?login=state');
  }
  const code = String(req.query.code || '');
  if (!code) {
    clearOauthCookies();
    return res.redirect('/meine-tickets.html?login=fehler');
  }

  try {
    const redirectUri = discordRedirectUri(req);
    const tokenResponse = await fetch(`${DISCORD_API_BASE}/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri
      })
    });
    if (!tokenResponse.ok) {
      const detail = await tokenResponse.text().catch(() => '');
      console.error('Discord token exchange failed:', tokenResponse.status, detail.slice(0, 300));
      clearOauthCookies();
      return res.redirect('/meine-tickets.html?login=fehler');
    }
    const tokenData = await tokenResponse.json();
    const userResponse = await fetch(`${DISCORD_API_BASE}/users/@me`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    if (!userResponse.ok) {
      clearOauthCookies();
      return res.redirect('/meine-tickets.html?login=fehler');
    }
    const user = await userResponse.json();
    if (!user || !user.id || !user.username) {
      clearOauthCookies();
      return res.redirect('/meine-tickets.html?login=fehler');
    }

    await query(
      `INSERT INTO citizen_accounts (discord_id, username, global_name, avatar, email, last_login_at)
       VALUES (?,?,?,?,?,NOW())
       ON DUPLICATE KEY UPDATE username = VALUES(username), global_name = VALUES(global_name),
         avatar = VALUES(avatar), email = VALUES(email), last_login_at = NOW()`,
      [String(user.id), String(user.username), user.global_name || null, user.avatar || null, user.email || null]
    );
    const rows = await query('SELECT * FROM citizen_accounts WHERE discord_id = ? LIMIT 1', [String(user.id)]);
    if (!rows.length) {
      clearOauthCookies();
      return res.redirect('/meine-tickets.html?login=fehler');
    }
    const citizen = rows[0];
    await createCitizenSession(citizen.id, req, res);
    await recordCitizenEvent(citizen.id, 'login', { username: citizen.username }, req);
    clearOauthCookies();
    res.redirect(next);
  } catch (err) {
    console.error('Discord login failed:', err.message);
    clearOauthCookies();
    res.redirect('/meine-tickets.html?login=fehler');
  }
});

router.post('/auth/logout', async (req, res) => {
  try {
    const cookies = parseCookies(req);
    if (cookies.lpt_citizen) {
      const rows = await query(
        'SELECT citizen_id FROM citizen_sessions WHERE token_hash = ? LIMIT 1',
        [hashToken(cookies.lpt_citizen)]
      );
      if (rows.length) await recordCitizenEvent(rows[0].citizen_id, 'logout', null, req);
      await query('DELETE FROM citizen_sessions WHERE token_hash = ?', [hashToken(cookies.lpt_citizen)]);
    }
  } catch (e) { /* Logout darf nicht fehlschlagen. */ }
  res.clearCookie('lpt_citizen', { path: '/' });
  res.json({ ok: true });
});

router.get('/session', async (req, res) => {
  if (!req.citizen) {
    return res.json({ authenticated: false, citizen: null, tickets: { total: 0, open: 0 } });
  }
  const counts = await query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status NOT IN ('abgeschlossen','abgelehnt') THEN 1 ELSE 0 END) AS open
     FROM applications WHERE citizen_id = ? AND type IN ('report','hint','strafanzeige','contact')`,
    [req.citizen.id]
  );
  return res.json({
    authenticated: true,
    citizen: req.citizen,
    tickets: {
      total: Number(counts[0]?.total || 0),
      open: Number(counts[0]?.open || 0)
    }
  });
});

router.get('/me', requireCitizen, async (req, res) => {
  const counts = await query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status NOT IN ('abgeschlossen','abgelehnt') THEN 1 ELSE 0 END) AS open
     FROM applications WHERE citizen_id = ? AND type IN ('report','hint','strafanzeige','contact')`,
    [req.citizen.id]
  );
  res.json({
    citizen: req.citizen,
    tickets: {
      total: Number(counts[0]?.total || 0),
      open: Number(counts[0]?.open || 0)
    }
  });
});

router.get('/tickets', requireCitizen, async (req, res) => {
  const rows = await query(
    `SELECT a.id, a.ref, a.type, a.status, a.payload, a.created_at, a.updated_at,
            (SELECT COUNT(*) FROM ticket_messages m WHERE m.application_id = a.id) AS message_count,
            (SELECT m.message FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_message,
            (SELECT m.sender FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_sender,
            (SELECT m.created_at FROM ticket_messages m WHERE m.application_id = a.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_message_at
     FROM applications a
     WHERE a.citizen_id = ? AND a.type IN (?,?,?,?)
     ORDER BY a.updated_at DESC, a.id DESC
     LIMIT 200`,
    [req.citizen.id, ...TICKET_TYPES]
  );
  res.json({
    tickets: rows.map((row) => ({ ...row, payload: safeJson(row.payload, {}) }))
  });
});

router.get('/tickets/:id', requireCitizen, async (req, res) => {
  const id = Number(req.params.id);
  const rows = await query(
    'SELECT * FROM applications WHERE id = ? AND citizen_id = ? AND type IN (?,?,?,?) LIMIT 1',
    [id, req.citizen.id, ...TICKET_TYPES]
  );
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  const ticket = rows[0];
  const messages = await query(
    'SELECT id, sender, author_name, message, created_at FROM ticket_messages WHERE application_id = ? ORDER BY created_at ASC, id ASC',
    [id]
  );
  res.json({
    ticket: {
      ...ticket,
      payload: safeJson(ticket.payload, {}),
      statusText: STATUS_TEXT[ticket.status] || STATUS_TEXT.eingegangen,
      canReply: !['abgeschlossen', 'abgelehnt'].includes(ticket.status)
    },
    messages
  });
});

router.post('/tickets/:id/messages', requireCitizen, async (req, res) => {
  const id = Number(req.params.id);
  const message = String(req.body && req.body.message ? req.body.message : '').trim();
  if (!message) return res.status(400).json({ error: 'Bitte geben Sie eine Nachricht ein.' });
  if (message.length > 4000) return res.status(400).json({ error: 'Die Nachricht darf höchstens 4000 Zeichen lang sein.' });

  const rows = await query(
    'SELECT id, ref, status, payload FROM applications WHERE id = ? AND citizen_id = ? AND type IN (?,?,?,?) LIMIT 1',
    [id, req.citizen.id, ...TICKET_TYPES]
  );
  if (!rows.length) return res.status(404).json({ error: 'Ticket nicht gefunden.' });
  if (['abgeschlossen', 'abgelehnt'].includes(rows[0].status)) {
    return res.status(409).json({ error: 'Dieses Ticket ist abgeschlossen. Bitte eröffnen Sie ein neues Ticket.' });
  }

  const payload = safeJson(rows[0].payload, {});
  const authorName = payload.anonymous ? null : req.citizen.displayName;
  const result = await query(
    'INSERT INTO ticket_messages (application_id, sender, author_name, message, citizen_id) VALUES (?,?,?,?,?)',
    [id, 'citizen', authorName, message, req.citizen.id]
  );
  await query('UPDATE applications SET updated_at = CURRENT_TIMESTAMP WHERE id = ?', [id]);
  await recordCitizenEvent(req.citizen.id, 'ticket.message', { ticketId: id, ref: rows[0].ref }, req);
  res.status(201).json({
    ok: true,
    message: {
      id: result.insertId,
      sender: 'citizen',
      author_name: req.citizen.displayName,
      message,
      created_at: new Date().toISOString()
    }
  });
});

module.exports = router;
