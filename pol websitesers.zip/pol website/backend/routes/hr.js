const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');

const router = express.Router();

router.get('/applications', authMiddleware, requirePermission('hr.view'), async (req, res) => {
  const q = String(req.query.q || '').trim();
  let sql = `SELECT a.*,
      (SELECT COUNT(*) FROM application_uploads u WHERE u.application_id = a.id) AS upload_count,
      (SELECT r.score FROM training_test_results r WHERE r.application_id = a.id ORDER BY r.taken_at DESC, r.id DESC LIMIT 1) AS test_score,
      (SELECT r.passed FROM training_test_results r WHERE r.application_id = a.id ORDER BY r.taken_at DESC, r.id DESC LIMIT 1) AS test_passed,
      (SELECT r.taken_at FROM training_test_results r WHERE r.application_id = a.id ORDER BY r.taken_at DESC, r.id DESC LIMIT 1) AS test_taken_at,
      (SELECT t.title FROM training_test_results r JOIN training_tests t ON t.id = r.test_id
        WHERE r.application_id = a.id ORDER BY r.taken_at DESC, r.id DESC LIMIT 1) AS test_title
    FROM applications a
    WHERE a.type = 'career' AND a.archived_at IS NULL`;
  const params = [];
  if (q) {
    sql += ' AND (a.ref LIKE ? OR a.applicant_name LIKE ? OR a.applicant_email LIKE ? OR a.payload LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  sql += ' ORDER BY a.created_at DESC LIMIT 300';
  const rows = await query(sql, params);
  const summary = await query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status NOT IN ('abgeschlossen','abgelehnt') THEN 1 ELSE 0 END) AS open
     FROM applications WHERE type = 'career' AND archived_at IS NULL`
  );
  const tested = await query(
    `SELECT COUNT(DISTINCT application_id) AS tested,
            SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) AS passed
     FROM training_test_results WHERE application_id IS NOT NULL`
  );
  res.json({
    applications: rows,
    summary: {
      total: Number(summary[0]?.total || 0),
      open: Number(summary[0]?.open || 0),
      tested: Number(tested[0]?.tested || 0),
      passed: Number(tested[0]?.passed || 0)
    }
  });
});

module.exports = router;
