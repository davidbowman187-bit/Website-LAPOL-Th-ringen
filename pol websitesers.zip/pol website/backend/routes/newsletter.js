const express = require('express');
const { query } = require('../src/db');

const router = express.Router();

router.post('/', async (req, res) => {
  const email = String(req.body && req.body.email ? req.body.email : '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return res.status(400).json({ error: 'Bitte geben Sie eine gültige E-Mail-Adresse an.' });
  }
  try {
    await query('INSERT IGNORE INTO newsletter_subscribers (email) VALUES (?)', [email]);
    res.status(201).json({ ok: true, message: 'E-Mail-Adresse wurde für den Meldungsverteiler gespeichert.' });
  } catch (err) {
    res.status(500).json({ error: 'Anmeldung konnte nicht gespeichert werden.' });
  }
});

module.exports = router;
