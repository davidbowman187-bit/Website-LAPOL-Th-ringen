const express = require('express');
const { serverQuery, query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');

const router = express.Router();

const CASE_TABLES = ['police_cases', 'cases', 'akten'];
const CHARACTER_TABLES = ['users', 'police_characters', 'characters', 'players'];
const VEHICLE_TABLES = ['owned_vehicles', 'vehicles'];

async function existingTable(candidates) {
  try {
    const rows = await serverQuery('SHOW TABLES');
    const names = rows.map((r) => Object.values(r)[0]);
    return candidates.find((t) => names.indexOf(t) !== -1) || null;
  } catch (e) {
    return null;
  }
}

async function columnsOf(table) {
  try {
    const rows = await serverQuery(`SHOW COLUMNS FROM \`${table}\``);
    return new Set(rows.map((r) => r.Field));
  } catch (e) {
    return new Set();
  }
}

/* ---------- Helpers ---------- */

// ESX speichert Geburtsdaten häufig als MM/DD/YYYY
function normalizeBirth(value) {
  const s = String(value || '').trim();
  if (!s) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const [y, m, d] = s.split('-');
    return `${m}/${d}/${y}`;
  }
  if (/^\d{2}\.\d{2}\.\d{4}$/.test(s)) {
    const [d, m, y] = s.split('.');
    return `${m}/${d}/${y}`;
  }
  return s;
}

function normalizeName(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

async function loadTicketIndex() {
  try {
    return await query(
      `SELECT ref, type, status, applicant_name, created_at, payload
       FROM applications
       WHERE type IN ('report','hint','strafanzeige','contact')
         AND archived_at IS NULL
         AND status NOT IN ('abgeschlossen','abgelehnt')
       ORDER BY created_at DESC
       LIMIT 1000`
    );
  } catch (e) {
    return [];
  }
}

async function loadWantedIndex() {
  try {
    return await query(
      `SELECT case_no, title, teaser, description, facts
       FROM wanted_persons WHERE status = 'aktiv' ORDER BY created_at DESC LIMIT 500`
    );
  } catch (e) {
    return [];
  }
}

function ticketMatches(citizenName, applicantName) {
  const citizen = normalizeName(citizenName);
  const applicant = normalizeName(applicantName);
  if (!citizen || !applicant) return false;
  return applicant === citizen || applicant.includes(citizen) || citizen.includes(applicant);
}

function wantedMatches(citizenName, wanted) {
  const citizen = normalizeName(citizenName);
  if (!citizen || citizen.length < 4) return false;
  const haystack = normalizeName(`${wanted.title || ''} ${wanted.teaser || ''} ${wanted.description || ''} ${wanted.facts || ''} ${wanted.case_no || ''}`);
  return haystack.includes(citizen);
}

function citizenFlags(citizen, tickets, wanted) {
  const fullName = [citizen.firstname, citizen.lastname].filter(Boolean).join(' ').trim();
  const openTickets = tickets.filter((t) => ticketMatches(fullName, t.applicant_name));
  const wantedCases = wanted.filter((w) => wantedMatches(fullName, w));
  return {
    open_tickets: openTickets.length,
    open_ticket_refs: openTickets.map((t) => t.ref),
    wanted: wantedCases.length > 0,
    wanted_cases: wantedCases.map((w) => ({ caseNo: w.case_no, title: w.title }))
  };
}

function parseVehicle(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (e) {
    return {};
  }
}

function vehicleModel(parsed, fallbackLabel) {
  if (parsed && typeof parsed.model === 'string' && parsed.model.trim()) return parsed.model.trim();
  if (parsed && typeof parsed.model === 'number') return 'Modell #' + parsed.model;
  return fallbackLabel || 'unbekannt';
}

function normalizeVehicle(row) {
  const parsed = parseVehicle(row.vehicle);
  const ownerName = [row.firstname, row.lastname].filter(Boolean).join(' ').trim();
  return {
    plate: row.plate || '',
    ownerIdentifier: row.owner || '',
    ownerName: ownerName || 'Unbekannt',
    model: vehicleModel(parsed, row.label),
    label: row.label || '',
    type: row.type || 'car',
    job: row.job || null,
    stored: Number(row.stored) === 1,
    mileage: Number(row.mileage || 0),
    star: row.star || '0',
    favourite: row.favourite || '0',
    raw: parsed
  };
}

/* ---------- Health / Diagnose ---------- */

router.get('/health', authMiddleware, async (req, res) => {
  try {
    await serverQuery('SELECT 1');
    res.json({ ok: true, message: 'ESX-Server-Datenbank erreichbar.' });
  } catch (err) {
    res.status(503).json({ ok: false, error: err.message });
  }
});

router.get('/tables', authMiddleware, async (req, res) => {
  try {
    const rows = await serverQuery('SHOW TABLES');
    res.json({ tables: rows.map((r) => Object.values(r)[0]) });
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});

/* ---------- Fälle ---------- */

router.get('/cases', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(CASE_TABLES);
  if (!table) return res.json({ cases: [], table: null, message: 'Keine Falltabelle in der Server-Datenbank gefunden.' });
  try {
    const limit = Math.min(Number(req.query.limit || 100), 500);
    const rows = await serverQuery(`SELECT * FROM \`${table}\` ORDER BY id DESC LIMIT ?`, [limit]);
    res.json({ table, cases: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/cases/:id', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(CASE_TABLES);
  if (!table) return res.status(404).json({ error: 'Keine Falltabelle gefunden.' });
  try {
    const rows = await serverQuery(`SELECT * FROM \`${table}\` WHERE id = ? OR case_number = ? LIMIT 1`, [req.params.id, req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Fall nicht gefunden.' });
    res.json({ table, case: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ---------- Bürgerregister (ESX users) ---------- */

router.get('/characters/search', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(CHARACTER_TABLES);
  if (!table) return res.json({ citizens: [], characters: [], table: null, message: 'Keine Bürgertabelle gefunden.' });
  const q = String(req.query.q || '').trim();
  const birth = String(req.query.birth || '').trim();
  try {
    const cols = await columnsOf(table);
    const hasJobs = await existingTable(['jobs']);
    const jobJoin = hasJobs && cols.has('job') ? ' LEFT JOIN `jobs` j ON j.name = u.job ' : ' ';
    const jobSelect = hasJobs && cols.has('job') ? ', j.label AS job_label' : '';

    let sql = `SELECT u.identifier, u.firstname, u.lastname, u.dateofbirth, u.sex, u.height,
                      u.job, u.job_grade, u.phone_number, u.nationality, u.disabled, u.last_seen, u.playtime${jobSelect}
               FROM \`${table}\` u ${jobJoin} WHERE 1=1`;
    const params = [];

    if (q) {
      sql += ` AND (u.firstname LIKE ? OR u.lastname LIKE ? OR u.identifier LIKE ?
               ${cols.has('phone_number') ? ' OR u.phone_number LIKE ?' : ''}
               ${cols.has('dateofbirth') ? ' OR u.dateofbirth LIKE ?' : ''}
               OR CONCAT(u.firstname, ' ', u.lastname) LIKE ?)`;
      const like = `%${q}%`;
      params.push(like, like, like);
      if (cols.has('phone_number')) params.push(like);
      if (cols.has('dateofbirth')) params.push(like);
      params.push(like);
    }

    if (birth && cols.has('dateofbirth')) {
      const normalized = normalizeBirth(birth);
      sql += ' AND (u.dateofbirth = ? OR u.dateofbirth LIKE ?)';
      params.push(normalized, `%${normalized}%`);
    }

    sql += ' ORDER BY u.last_seen DESC, u.id ASC LIMIT 60';
    const rows = await serverQuery(sql, params);
    const tickets = await loadTicketIndex();
    const wanted = await loadWantedIndex();
    const citizens = rows.map((c) => ({ ...c, ...citizenFlags(c, tickets, wanted) }));
    res.json({ table, citizens, characters: citizens });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/characters/:identifier', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(CHARACTER_TABLES);
  if (!table) return res.status(404).json({ error: 'Keine Bürgertabelle gefunden.' });
  try {
    const cols = await columnsOf(table);
    const hasJobs = await existingTable(['jobs']);
    const jobJoin = hasJobs && cols.has('job') ? ' LEFT JOIN `jobs` j ON j.name = u.job ' : ' ';
    const jobSelect = hasJobs && cols.has('job') ? ', j.label AS job_label' : '';
    const rows = await serverQuery(
      `SELECT u.*${jobSelect} FROM \`${table}\` u ${jobJoin} WHERE u.identifier = ? LIMIT 1`,
      [req.params.identifier]
    );
    if (!rows.length) return res.status(404).json({ error: 'Person nicht gefunden.' });

    let licenses = [];
    try {
      licenses = await serverQuery(
        `SELECT ul.type, ul.status, l.label
         FROM user_licenses ul LEFT JOIN licenses l ON l.type = ul.type
         WHERE ul.owner = ? ORDER BY l.label`,
        [req.params.identifier]
      );
    } catch (e) { licenses = []; }

    let vehicles = [];
    try {
      const vRows = await serverQuery(
        `SELECT plate, vehicle, type, job, stored, mileage, label, star, favourite
         FROM owned_vehicles WHERE owner = ? ORDER BY plate LIMIT 50`,
        [req.params.identifier]
      );
      vehicles = vRows.map((v) => normalizeVehicle({ ...v, owner: req.params.identifier }));
    } catch (e) { vehicles = []; }

    const c = rows[0];
    const tickets = await loadTicketIndex();
    const wanted = await loadWantedIndex();
    const flags = citizenFlags(c, tickets, wanted);
    const fullName = [c.firstname, c.lastname].filter(Boolean).join(' ').trim();
    const openTickets = tickets
      .filter((t) => ticketMatches(fullName, t.applicant_name))
      .map((t) => ({ ref: t.ref, type: t.type, status: t.status, created_at: t.created_at }));
    const wantedCases = wanted
      .filter((w) => wantedMatches(fullName, w))
      .map((w) => ({ caseNo: w.case_no, title: w.title, teaser: w.teaser }));

    res.json({
      table,
      character: { ...c, ...flags },
      citizen: { ...c, ...flags },
      licenses,
      vehicles,
      openTickets,
      wantedCases
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ---------- Fahrzeugregister (ESX owned_vehicles) ---------- */

router.get('/vehicles/search', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(VEHICLE_TABLES);
  if (!table) return res.json({ vehicles: [], table: null, message: 'Keine Fahrzeugtabelle gefunden.' });
  const q = String(req.query.q || '').trim();
  try {
    let sql = `SELECT ov.*, u.firstname, u.lastname
               FROM \`${table}\` ov LEFT JOIN users u ON u.identifier = ov.owner WHERE 1=1`;
    const params = [];
    if (q) {
      sql += ` AND (ov.plate LIKE ? OR ov.owner LIKE ? OR ov.vehicle LIKE ? OR ov.label LIKE ?
               OR CONCAT(u.firstname, ' ', u.lastname) LIKE ?)`;
      const like = `%${q}%`;
      params.push(like, like, like, like, like);
    }
    sql += ' ORDER BY ov.plate LIMIT 60';
    const rows = await serverQuery(sql, params);
    res.json({ table, vehicles: rows.map(normalizeVehicle) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/vehicles/:plate', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const table = await existingTable(VEHICLE_TABLES);
  if (!table) return res.status(404).json({ error: 'Keine Fahrzeugtabelle gefunden.' });
  try {
    const rows = await serverQuery(
      `SELECT ov.*, u.firstname, u.lastname
       FROM \`${table}\` ov LEFT JOIN users u ON u.identifier = ov.owner
       WHERE ov.plate = ? LIMIT 1`,
      [req.params.plate]
    );
    if (!rows.length) return res.status(404).json({ error: 'Fahrzeug nicht gefunden.' });
    res.json({ table, vehicle: normalizeVehicle(rows[0]) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
