const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { safeJson, audit } = require('../src/utils');

const router = express.Router();

function normalizeLaw(row, sections) {
  return {
    code: row.code,
    title: row.title,
    subtitle: row.subtitle,
    description: row.description,
    icon: row.icon,
    tags: safeJson(row.tags, []),
    sortOrder: row.sort_order,
    sections: sections || [],
    sectionCount: Number(row.section_count || (sections ? sections.length : 0))
  };
}

function parseTags(value) {
  if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean);
  return String(value || '').split(',').map((v) => v.trim()).filter(Boolean);
}

async function loadLaw(code) {
  const rows = await query('SELECT * FROM laws WHERE code = ? LIMIT 1', [code]);
  if (!rows.length) return null;
  const sections = await query(
    'SELECT * FROM law_sections WHERE law_code = ? ORDER BY sort_order ASC, id ASC',
    [code]
  );
  return normalizeLaw(rows[0], sections);
}

router.get('/', authMiddleware, async (req, res) => {
  const q = String(req.query.q || '').trim();
  let sql = `SELECT l.*, (SELECT COUNT(*) FROM law_sections s WHERE s.law_code = l.code) AS section_count
             FROM laws l WHERE 1=1`;
  const params = [];
  if (q) {
    sql += ' AND (l.code LIKE ? OR l.title LIKE ? OR l.subtitle LIKE ? OR l.description LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  sql += ' ORDER BY l.sort_order ASC, l.code ASC';
  const rows = await query(sql, params);
  res.json({ laws: rows.map((r) => normalizeLaw(r)) });
});

router.get('/:code', authMiddleware, async (req, res) => {
  const law = await loadLaw(req.params.code);
  if (!law) return res.status(404).json({ error: 'Gesetz nicht gefunden.' });
  res.json({ law });
});

router.post('/', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const body = req.body || {};
  const code = String(body.code || '').trim().toUpperCase();
  const title = String(body.title || '').trim();
  if (!code || !title) return res.status(400).json({ error: 'Gesetzescode und Titel sind erforderlich.' });
  const exists = await query('SELECT code FROM laws WHERE code = ? LIMIT 1', [code]);
  if (exists.length) return res.status(409).json({ error: 'Dieses Gesetz existiert bereits.' });
  await query(
    `INSERT INTO laws (code, title, subtitle, description, icon, tags, sort_order)
     VALUES (?,?,?,?,?,?,?)`,
    [
      code,
      title,
      String(body.subtitle || '').trim(),
      String(body.description || '').trim(),
      String(body.icon || 'book').trim() || 'book',
      JSON.stringify(parseTags(body.tags)),
      Number(body.sortOrder || 999)
    ]
  );
  await audit(null, req.user.id, 'law.create', 'law', code, { title });
  res.status(201).json({ law: await loadLaw(code) });
});

router.patch('/:code', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const code = String(req.params.code || '').trim();
  const law = await loadLaw(code);
  if (!law) return res.status(404).json({ error: 'Gesetz nicht gefunden.' });
  const body = req.body || {};
  const title = body.title !== undefined ? String(body.title).trim() : law.title;
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  await query(
    `UPDATE laws SET title = ?, subtitle = ?, description = ?, icon = ?, tags = ?, sort_order = ? WHERE code = ?`,
    [
      title,
      body.subtitle !== undefined ? String(body.subtitle || '').trim() : law.subtitle,
      body.description !== undefined ? String(body.description || '').trim() : law.description,
      body.icon !== undefined ? (String(body.icon || 'book').trim() || 'book') : law.icon,
      body.tags !== undefined ? JSON.stringify(parseTags(body.tags)) : JSON.stringify(law.tags),
      body.sortOrder !== undefined ? Number(body.sortOrder || 999) : law.sortOrder,
      code
    ]
  );
  await audit(null, req.user.id, 'law.update', 'law', code, { title });
  res.json({ law: await loadLaw(code) });
});

router.delete('/:code', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const code = String(req.params.code || '').trim();
  const law = await loadLaw(code);
  if (!law) return res.status(404).json({ error: 'Gesetz nicht gefunden.' });
  await query('DELETE FROM laws WHERE code = ?', [code]);
  await audit(null, req.user.id, 'law.delete', 'law', code, { title: law.title });
  res.json({ ok: true });
});

router.post('/:code/sections', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const code = String(req.params.code || '').trim();
  const law = await loadLaw(code);
  if (!law) return res.status(404).json({ error: 'Gesetz nicht gefunden.' });
  const body = req.body || {};
  const number = String(body.number || '').trim();
  const title = String(body.title || '').trim();
  if (!number || !title) return res.status(400).json({ error: 'Paragraph und Titel sind erforderlich.' });
  const result = await query(
    'INSERT INTO law_sections (law_code, number, title, text, penalty, sort_order) VALUES (?,?,?,?,?,?)',
    [code, number, title, String(body.text || '').trim(), String(body.penalty || '').trim(), Number(body.sortOrder || 999)]
  );
  await audit(null, req.user.id, 'law.section.create', 'law_section', result.insertId, { code, number });
  res.status(201).json({ law: await loadLaw(code) });
});

router.patch('/:code/sections/:id', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const code = String(req.params.code || '').trim();
  const id = Number(req.params.id);
  const rows = await query('SELECT * FROM law_sections WHERE id = ? AND law_code = ? LIMIT 1', [id, code]);
  if (!rows.length) return res.status(404).json({ error: 'Paragraph nicht gefunden.' });
  const current = rows[0];
  const body = req.body || {};
  await query(
    'UPDATE law_sections SET number = ?, title = ?, text = ?, penalty = ?, sort_order = ? WHERE id = ?',
    [
      body.number !== undefined ? String(body.number).trim() : current.number,
      body.title !== undefined ? String(body.title).trim() : current.title,
      body.text !== undefined ? String(body.text || '').trim() : current.text,
      body.penalty !== undefined ? String(body.penalty || '').trim() : current.penalty,
      body.sortOrder !== undefined ? Number(body.sortOrder || 999) : current.sort_order,
      id
    ]
  );
  await audit(null, req.user.id, 'law.section.update', 'law_section', id, { code });
  res.json({ law: await loadLaw(code) });
});

router.delete('/:code/sections/:id', authMiddleware, requirePermission('laws.manage'), async (req, res) => {
  const code = String(req.params.code || '').trim();
  const id = Number(req.params.id);
  const rows = await query('SELECT id FROM law_sections WHERE id = ? AND law_code = ? LIMIT 1', [id, code]);
  if (!rows.length) return res.status(404).json({ error: 'Paragraph nicht gefunden.' });
  await query('DELETE FROM law_sections WHERE id = ?', [id]);
  await audit(null, req.user.id, 'law.section.delete', 'law_section', id, { code });
  res.json({ law: await loadLaw(code) });
});

module.exports = router;
