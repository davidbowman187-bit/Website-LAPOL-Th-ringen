const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { audit } = require('../src/utils');

const router = express.Router();

function canView(req) {
  return req.user.permissions.has('weapons.view') || req.user.permissions.has('applications.view');
}

router.get('/', authMiddleware, async (req, res) => {
  if (!canView(req)) return res.status(403).json({ error: 'Keine Berechtigung.' });
  const q = String(req.query.q || '').trim();
  const type = String(req.query.type || '').trim();
  let sql = 'SELECT * FROM weapons WHERE 1=1';
  const params = [];
  if (q) {
    sql += ' AND (owner_name LIKE ? OR owner_identifier LIKE ? OR weapon_type LIKE ? OR model LIKE ? OR serial_number LIKE ? OR license_number LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like);
  }
  if (type) {
    sql += ' AND weapon_type = ?';
    params.push(type);
  }
  sql += ' ORDER BY created_at DESC LIMIT 200';
  const rows = await query(sql, params);
  res.json({ weapons: rows });
});

router.post('/', authMiddleware, requirePermission('weapons.manage'), async (req, res) => {
  const { ownerName, ownerIdentifier, weaponType, model, serialNumber, licenseNumber, registeredAt, status, notes } = req.body || {};
  if (!ownerName || !weaponType) {
    return res.status(400).json({ error: 'Halter und Waffentyp sind erforderlich.' });
  }
  const result = await query(
    `INSERT INTO weapons (owner_name, owner_identifier, weapon_type, model, serial_number, license_number, registered_at, status, notes, created_by)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [ownerName, ownerIdentifier || null, weaponType, model || null, serialNumber || null, licenseNumber || null,
      registeredAt || null, status || 'gueltig', notes || null, req.user.id]
  );
  await audit(null, req.user.id, 'weapon.create', 'weapon', result.insertId, { ownerName, weaponType, serialNumber });
  res.status(201).json({ id: result.insertId });
});

router.patch('/:id', authMiddleware, requirePermission('weapons.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const fields = ['owner_name', 'owner_identifier', 'weapon_type', 'model', 'serial_number', 'license_number', 'registered_at', 'status', 'notes'];
  const map = {
    ownerName: 'owner_name', ownerIdentifier: 'owner_identifier', weaponType: 'weapon_type', model: 'model',
    serialNumber: 'serial_number', licenseNumber: 'license_number', registeredAt: 'registered_at', status: 'status', notes: 'notes'
  };
  for (const [key, column] of Object.entries(map)) {
    if (req.body[key] !== undefined) {
      await query(`UPDATE weapons SET ${column} = ? WHERE id = ?`, [req.body[key], id]);
    }
  }
  await audit(null, req.user.id, 'weapon.update', 'weapon', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('weapons.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM weapons WHERE id = ?', [id]);
  await audit(null, req.user.id, 'weapon.delete', 'weapon', id, null);
  res.json({ ok: true });
});

module.exports = router;
