const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { audit } = require('../src/utils');

const router = express.Router();

const TYPES = ['streife', 'verkehrskontrolle', 'durchsuchung', 'einsatz', 'vernehmung', 'sonstiges'];

function canView(req) {
  return req.user.permissions.has('activity.view') || req.user.permissions.has('applications.view');
}

router.get('/', authMiddleware, async (req, res) => {
  if (!canView(req)) return res.status(403).json({ error: 'Keine Berechtigung.' });
  const q = String(req.query.q || '').trim();
  const type = String(req.query.type || '').trim();
  let sql = 'SELECT * FROM activity_reports WHERE 1=1';
  const params = [];
  if (q) {
    sql += ' AND (ref LIKE ? OR title LIKE ? OR officer_name LIKE ? OR citizen_name LIKE ? OR citizen_identifier LIKE ? OR vehicle_plate LIKE ? OR location LIKE ? OR description LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like, like, like);
  }
  if (type) {
    sql += ' AND type = ?';
    params.push(type);
  }
  sql += ' ORDER BY occurred_at DESC, created_at DESC LIMIT 300';
  const rows = await query(sql, params);
  res.json({ reports: rows });
});

router.post('/', authMiddleware, requirePermission('activity.manage'), async (req, res) => {
  const { type, title, citizenName, citizenIdentifier, vehiclePlate, location, occurredAt, description, measures, outcome } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Titel ist erforderlich.' });
  const kind = TYPES.includes(type) ? type : 'sonstiges';
  const result = await query(
    `INSERT INTO activity_reports
      (ref, type, title, officer_id, officer_name, citizen_name, citizen_identifier, vehicle_plate, location, occurred_at, description, measures, outcome)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    ['PENDING', kind, title, req.user.id, req.user.displayName || req.user.username,
      citizenName || null, citizenIdentifier || null, vehiclePlate || null, location || null,
      occurredAt || new Date(), description || null, measures || null, outcome || null]
  );
  const id = result.insertId;
  const year = new Date().getFullYear();
  const ref = `TB/${year}/${String(id).padStart(5, '0')}`;
  await query('UPDATE activity_reports SET ref = ? WHERE id = ?', [ref, id]);
  await audit(null, req.user.id, 'activity.create', 'activity_report', id, { ref, title });
  res.status(201).json({ id, ref });
});

router.patch('/:id', authMiddleware, requirePermission('activity.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const map = {
    type: 'type', title: 'title', citizenName: 'citizen_name', citizenIdentifier: 'citizen_identifier',
    vehiclePlate: 'vehicle_plate', location: 'location', occurredAt: 'occurred_at',
    description: 'description', measures: 'measures', outcome: 'outcome'
  };
  for (const [key, column] of Object.entries(map)) {
    if (req.body[key] !== undefined) {
      let value = req.body[key];
      if (key === 'type' && !TYPES.includes(value)) value = 'sonstiges';
      await query(`UPDATE activity_reports SET ${column} = ? WHERE id = ?`, [value, id]);
    }
  }
  await audit(null, req.user.id, 'activity.update', 'activity_report', id, req.body);
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('activity.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM activity_reports WHERE id = ?', [id]);
  await audit(null, req.user.id, 'activity.delete', 'activity_report', id, null);
  res.json({ ok: true });
});

module.exports = router;
