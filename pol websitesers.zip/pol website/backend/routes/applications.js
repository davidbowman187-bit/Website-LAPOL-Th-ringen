const express = require('express');
const { query } = require('../src/db');
const { authMiddleware, requirePermission } = require('../src/auth');
const { optionalCitizen } = require('../src/citizenAuth');
const { safeJson, toJson, makeRef, audit } = require('../src/utils');

const router = express.Router();

const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;
const ALLOWED_UPLOAD_TYPES = new Set(['application/pdf', 'image/jpeg', 'image/png']);
const REQUIRED_CAREER_FILES = ['lebenslauf', 'anschreiben'];

function parseUploads(input) {
  if (input == null) return { files: [] };
  if (!Array.isArray(input)) return { error: 'Ungültige Dateianlage.' };
  if (input.length > 4) return { error: 'Zu viele Dateianlagen.' };
  const files = [];
  for (const item of input) {
    const kind = String(item && item.kind ? item.kind : '').trim().toLowerCase();
    const filename = String(item && item.filename ? item.filename : '').trim().slice(0, 180);
    const mime = String(item && item.mime ? item.mime : '').trim().toLowerCase();
    const raw = String(item && item.data ? item.data : '');
    if (!['lebenslauf', 'anschreiben'].includes(kind)) return { error: 'Ungültige Art der Dateianlage.' };
    if (!filename) return { error: 'Dateiname fehlt.' };
    if (!ALLOWED_UPLOAD_TYPES.has(mime)) return { error: 'Erlaubt sind PDF-, JPG- und PNG-Dateien.' };
    const base64 = raw.includes(',') ? raw.split(',').pop() : raw;
    const buffer = Buffer.from(base64, 'base64');
    if (!buffer.length) return { error: 'Die Datei ist leer.' };
    if (buffer.length > MAX_UPLOAD_BYTES) return { error: 'Eine Datei darf höchstens 4 MB groß sein.' };
    files.push({ kind, filename, mime, size: buffer.length, buffer });
  }
  return { files };
}


const STATUS_TEXT = {
  eingegangen: 'Ihr Anliegen ist bei der Landespolizei eingegangen und wird geprüft.',
  in_pruefung: 'Ihr Anliegen wird derzeit geprüft.',
  in_bearbeitung: 'Ihr Vorgang wird derzeit bearbeitet.',
  abgeschlossen: 'Ihr Vorgang wurde abgeschlossen.',
  abgelehnt: 'Ihr Vorgang konnte nicht weiterbearbeitet werden. Bitte kontaktieren Sie die zuständige Dienststelle.'
};

// Public submit
router.post('/', optionalCitizen, async (req, res) => {
  const { type, payload, applicantName, applicantEmail, applicantBirth, stationId } = req.body || {};
  const allowedTypes = ['report', 'leading_certificate', 'career', 'contact', 'appointment', 'hint', 'einsatzbericht', 'strafanzeige', 'module', 'taetigkeitsbericht'];
  if (!allowedTypes.includes(type)) return res.status(400).json({ error: 'Ungültiger Antragstyp.' });
  const ticketTypes = ['report', 'hint', 'strafanzeige', 'contact'];
  if (ticketTypes.includes(type) && !req.citizen) {
    return res.status(401).json({
      error: 'Bitte melden Sie sich mit Discord an, um ein Ticket zu erstellen.',
      requiresDiscord: true
    });
  }
  const data = payload && typeof payload === 'object' ? payload : {};
  const name = applicantName || data.name || data.applicantName || null;
  const email = applicantEmail || data.email || data.applicantEmail || null;
  const birth = applicantBirth || data.birth || data.applicantBirth || null;
  const station = stationId || data.station || data.stationId || null;

  const uploads = parseUploads(req.body && req.body.files);
  if (uploads.error) return res.status(400).json({ error: uploads.error });
  if (type === 'career') {
    const kinds = new Set(uploads.files.map((f) => f.kind));
    if (!REQUIRED_CAREER_FILES.every((kind) => kinds.has(kind))) {
      return res.status(400).json({ error: 'Bitte laden Sie Lebenslauf und Anschreiben hoch.' });
    }
    const path = String(data.path || '').trim();
    const phases = await query('SELECT label, is_open FROM recruitment_phases');
    const phase = phases.find((p) => String(p.label).toLowerCase() === path.toLowerCase());
    if (phase && !Number(phase.is_open)) {
      return res.status(403).json({ error: 'Die Bewerbungsphase für diesen Bereich ist geschlossen.' });
    }
  }

  const result = await query(
    `INSERT INTO applications (ref, type, status, payload, applicant_name, applicant_email, applicant_birth, station_id, citizen_id)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    ['PENDING', type, 'eingegangen', toJson(data), name, email, birth || null, station, req.citizen ? req.citizen.id : null]
  );
  const id = result.insertId;
  const ref = makeRef(type, id);
  await query('UPDATE applications SET ref = ? WHERE id = ?', [ref, id]);

  if (uploads.files.length) {
    try {
      for (const file of uploads.files) {
        await query(
          'INSERT INTO application_uploads (application_id, kind, filename, mime, size, data) VALUES (?,?,?,?,?,?)',
          [id, file.kind, file.filename, file.mime, file.size, file.buffer]
        );
      }
    } catch (err) {
      await query('DELETE FROM applications WHERE id = ?', [id]).catch(() => {});
      return res.status(500).json({ error: 'Dateianlagen konnten nicht gespeichert werden.' });
    }
  }

  const response = { id, ref, status: 'eingegangen', message: 'Antrag erfasst.', uploads: uploads.files.length };

  // Erstnachricht für Onlinewache-Tickets
  if (ticketTypes.includes(type)) {
    const ticketText = data.text || data.message || data.sachverhalt || data.description;
    if (ticketText) {
      try {
        const authorName = data.anonymous ? null : (name || (req.citizen ? req.citizen.displayName : null));
        await query(
          'INSERT INTO ticket_messages (application_id, sender, author_name, message, citizen_id) VALUES (?,?,?,?,?)',
          [id, 'citizen', authorName, String(ticketText), req.citizen ? req.citizen.id : null]
        );
      } catch (e) { /* Ticket-Nachricht optional */ }
    }
  }

  // Für Führungszeugnisse direkt ein PDF erzeugen und in der Datenbank ablegen
  if (type === 'leading_certificate') {
    try {
      const { generateForApplication } = require('./documents');
      const rows = await query('SELECT * FROM applications WHERE id = ? LIMIT 1', [id]);
      if (rows.length) {
        const doc = await generateForApplication(rows[0]);
        response.document = {
          id: doc.id,
          filename: doc.filename,
          size: doc.size,
          url: `/api/documents/${doc.id}/download?ref=${encodeURIComponent(ref)}`
        };
      }
    } catch (err) {
      console.error('PDF-Erzeugung fehlgeschlagen:', err.message);
    }
  }

  res.status(201).json(response);
});

// Public status check
router.get('/status/:ref', async (req, res) => {
  const ref = decodeURIComponent(req.params.ref);
  const birth = req.query.birth;
  const rows = await query('SELECT * FROM applications WHERE ref = ? LIMIT 1', [ref]);
  if (!rows.length) return res.status(404).json({ error: 'Vorgang nicht gefunden.' });
  const app = rows[0];
  if (app.applicant_birth && birth && String(app.applicant_birth) !== String(birth)) {
    return res.status(404).json({ error: 'Vorgang nicht gefunden.' });
  }
  let messages = [];
  try {
    messages = await query(
      `SELECT author_name, message, created_at FROM ticket_messages
       WHERE application_id = ? AND sender = 'police' ORDER BY created_at ASC, id ASC`,
      [app.id]
    );
  } catch (e) { messages = []; }
  res.json({
    ref: app.ref,
    type: app.type,
    status: app.status,
    statusText: STATUS_TEXT[app.status] || STATUS_TEXT.eingegangen,
    createdAt: app.created_at,
    updatedAt: app.updated_at,
    messages
  });
});

// Authenticated list
router.get('/', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const { type, status, limit = 50, offset = 0 } = req.query;
  let sql = `SELECT a.*, u.display_name AS assigned_name
             FROM applications a LEFT JOIN users u ON u.id = a.assigned_to
             WHERE a.archived_at IS NULL`;
  const params = [];
  if (type) { sql += ' AND a.type = ?'; params.push(type); }
  if (status) { sql += ' AND a.status = ?'; params.push(status); }
  sql += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
  params.push(Number(limit), Number(offset));
  const rows = await query(sql, params);
  const totalRows = await query('SELECT COUNT(*) AS c FROM applications');
  res.json({
    applications: rows.map((r) => ({ ...r, payload: safeJson(r.payload, {}) })),
    total: totalRows[0].c
  });
});

router.get('/:id', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const rows = await query(
    `SELECT a.*, u.display_name AS assigned_name FROM applications a
     LEFT JOIN users u ON u.id = a.assigned_to WHERE a.id = ? LIMIT 1`,
    [Number(req.params.id)]
  );
  if (!rows.length) return res.status(404).json({ error: 'Vorgang nicht gefunden.' });
  const r = rows[0];
  let uploads = [];
  try {
    uploads = await query(
      'SELECT id, kind, filename, mime, size, created_at FROM application_uploads WHERE application_id = ? ORDER BY id ASC',
      [Number(req.params.id)]
    );
  } catch (e) { uploads = []; }
  res.json({ application: { ...r, payload: safeJson(r.payload, {}) }, uploads });
});

router.patch('/:id', authMiddleware, requirePermission('applications.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const { status, assignedTo, internalNote } = req.body || {};
  const allowedStatus = ['eingegangen', 'in_pruefung', 'in_bearbeitung', 'abgeschlossen', 'abgelehnt'];
  if (status && !allowedStatus.includes(status)) return res.status(400).json({ error: 'Ungültiger Status.' });
  if (status) await query('UPDATE applications SET status = ? WHERE id = ?', [status, id]);
  if (assignedTo !== undefined) await query('UPDATE applications SET assigned_to = ? WHERE id = ?', [assignedTo ? Number(assignedTo) : null, id]);
  if (internalNote !== undefined) await query('UPDATE applications SET internal_note = ? WHERE id = ?', [internalNote, id]);
  await audit(null, req.user.id, 'application.update', 'application', id, { status, assignedTo, internalNote });
  res.json({ ok: true });
});

router.delete('/:id', authMiddleware, requirePermission('applications.manage'), async (req, res) => {
  const id = Number(req.params.id);
  await query('DELETE FROM applications WHERE id = ?', [id]);
  await audit(null, req.user.id, 'application.delete', 'application', id, null);
  res.json({ ok: true });
});

router.get('/:id/uploads/:uploadId/download', authMiddleware, requirePermission('applications.view'), async (req, res) => {
  const rows = await query(
    'SELECT filename, mime, data FROM application_uploads WHERE id = ? AND application_id = ? LIMIT 1',
    [Number(req.params.uploadId), Number(req.params.id)]
  );
  if (!rows.length) return res.status(404).json({ error: 'Datei nicht gefunden.' });
  const file = rows[0];
  res.setHeader('Content-Type', file.mime || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${String(file.filename || 'datei').replace(/["\\]/g, '_')}"`);
  res.send(file.data);
});

module.exports = router;