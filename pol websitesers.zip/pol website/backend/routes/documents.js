const express = require('express');
const { query } = require('../src/db');
const { authMiddleware } = require('../src/auth');
const { createCertificatePdf } = require('../src/pdf');
const { safeJson } = require('../src/utils');

const router = express.Router();

function filenameFor(ref) {
  const safe = String(ref || 'dokument').replace(/[^a-zA-Z0-9._-]+/g, '_');
  return `Fuehrungszeugnis_${safe}.pdf`;
}

async function generateForApplication(app) {
  const payload = safeJson(app.payload, {}) || {};
  const pdf = createCertificatePdf({
    ref: app.ref,
    firstName: payload.first,
    lastName: payload.last,
    birth: payload.birth,
    birthplace: payload.birthplace,
    street: payload.street,
    zip: payload.zip,
    city: payload.city,
    email: payload.email,
    type: payload.type,
    applicantName: app.applicant_name,
    issuedAt: new Date()
  });
  const filename = filenameFor(app.ref);
  const result = await query(
    `INSERT INTO documents (application_id, ref, filename, mime, size, data)
     VALUES (?,?,?,?,?,?)`,
    [app.id, app.ref, filename, 'application/pdf', pdf.length, pdf]
  );
  return { id: result.insertId, filename, size: pdf.length, pdf };
}

// Liste aller Dokumente (Intranet)
router.get('/', authMiddleware, async (req, res) => {
  if (!req.user.permissions.has('applications.view')) {
    return res.status(403).json({ error: 'Keine Berechtigung.' });
  }
  const rows = await query(
    `SELECT d.id, d.application_id, d.ref, d.filename, d.mime, d.size, d.created_at, a.type, a.applicant_name
     FROM documents d LEFT JOIN applications a ON a.id = d.application_id
     ORDER BY d.created_at DESC LIMIT 300`
  );
  res.json({ documents: rows });
});

// Download: angemeldete Nutzer oder öffentlich mit passender Referenz
router.get('/:id/download', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: 'Ungültige Dokument-ID.' });

  const rows = await query('SELECT * FROM documents WHERE id = ? LIMIT 1', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Dokument nicht gefunden.' });
  const doc = rows[0];

  let allowed = false;
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) {
    try {
      const jwt = require('jsonwebtoken');
      const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET || 'change-me-in-production');
      const perms = await query(
        `SELECT rp.permission_key FROM users u
         JOIN rank_permissions rp ON rp.rank_id = u.rank_id
         WHERE u.id = ? AND u.active = 1`,
        [payload.sub]
      );
      allowed = perms.some((p) => p.permission_key === 'applications.view');
    } catch (e) { allowed = false; }
  }
  if (!allowed && req.query.ref) {
    allowed = String(req.query.ref) === String(doc.ref);
  }
  if (!allowed) return res.status(403).json({ error: 'Keine Berechtigung für dieses Dokument.' });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${doc.filename}"`);
  res.setHeader('Content-Length', String(doc.size || doc.data.length));
  res.send(doc.data);
});

// Dokument neu erzeugen (Intranet)
router.post('/application/:applicationId', authMiddleware, async (req, res) => {
  if (!req.user.permissions.has('applications.view')) {
    return res.status(403).json({ error: 'Keine Berechtigung.' });
  }
  const appId = Number(req.params.applicationId);
  const rows = await query('SELECT * FROM applications WHERE id = ? LIMIT 1', [appId]);
  if (!rows.length) return res.status(404).json({ error: 'Vorgang nicht gefunden.' });
  const app = rows[0];
  if (app.type !== 'leading_certificate') {
    return res.status(400).json({ error: 'Für diesen Vorgang kann kein Führungszeugnis erzeugt werden.' });
  }
  const existing = await query('SELECT * FROM documents WHERE application_id = ? ORDER BY id DESC LIMIT 1', [appId]);
  if (existing.length) {
    return res.json({ id: existing[0].id, filename: existing[0].filename, existing: true });
  }
  const created = await generateForApplication(app);
  res.status(201).json({ id: created.id, filename: created.filename });
});

module.exports = router;
module.exports.generateForApplication = generateForApplication;
module.exports.filenameFor = filenameFor;
