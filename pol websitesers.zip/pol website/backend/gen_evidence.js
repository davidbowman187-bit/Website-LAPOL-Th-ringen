const fs = require('fs');
let sql = '\n-- Evidence / Asservaten\n';
sql += 'INSERT IGNORE INTO permissions (`key`, description) VALUES ("evidence.view","Asservaten einsehen"),("evidence.manage","Asservaten verwalten");\n';
sql += 'INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES (1,"evidence.view"),(1,"evidence.manage"),(2,"evidence.view"),(2,"evidence.manage"),(3,"evidence.view");\n';
sql += 'CREATE TABLE IF NOT EXISTS evidence (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  item_no VARCHAR(40) NOT NULL UNIQUE,\n  title VARCHAR(190) NOT NULL,\n  category VARCHAR(80) NULL,\n  location VARCHAR(120) NULL,\n  status VARCHAR(40) NOT NULL DEFAULT "eingelagert",\n  description TEXT NULL,\n  created_by INT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n';
fs.appendFileSync('website_schema.sql', sql);
console.log('done');