CREATE TABLE IF NOT EXISTS stations (
  id VARCHAR(80) PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  city VARCHAR(120) NOT NULL,
  region VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  hours VARCHAR(120) NOT NULL,
  services LONGTEXT NOT NULL,
  x INT NOT NULL,
  y INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("erfurt-zentrum","Polizeiinspektion Erfurt-Zentrum","Erfurt","Mitte","Andreasstraße 36, 99084 Erfurt","0361 123450","pi-erfurt-zentrum@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",47,49);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("erfurt-nord","Polizeiinspektion Erfurt-Nord","Erfurt","Mitte","Stotternheimer Straße 18, 99086 Erfurt","0361 123456","pi-erfurt-nord@polizei-rp-erfurt.de","Mo–Fr 07:00–19:00 Uhr","[\"Anzeige\",\"Beratung\",\"Termine\"]",50,41);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("weimar","Polizeiinspektion Weimar","Weimar","Mitte","Erfurter Straße 12, 99423 Weimar","03643 123400","pi-weimar@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Prävention\"]",60,47);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("jena","Polizeiinspektion Jena","Jena","Ost","Lutherstraße 24, 07743 Jena","03641 123500","pi-jena@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\",\"Prävention\"]",72,54);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("gera","Polizeiinspektion Gera","Gera","Ost","Wiesestraße 8, 07548 Gera","0365 123600","pi-gera@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",80,66);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("altenburg","Polizeiinspektion Altenburg","Altenburg","Ost","Schloßgasse 5, 04600 Altenburg","03447 123700","pi-altenburg@polizei-rp-erfurt.de","Mo–Fr 08:00–18:00 Uhr","[\"Anzeige\",\"Beratung\"]",90,70);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("nordhausen","Polizeiinspektion Nordhausen","Nordhausen","Nord","Bahnhofstraße 17, 99734 Nordhausen","03631 123800","pi-nordhausen@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",34,16);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("muehlhausen","Polizeiinspektion Mühlhausen","Mühlhausen","Nord","Unstrutstraße 9, 99974 Mühlhausen","03601 123900","pi-muehlhausen@polizei-rp-erfurt.de","Mo–Fr 07:00–19:00 Uhr","[\"Anzeige\",\"Beratung\"]",20,30);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("eisenach","Polizeiinspektion Eisenach","Eisenach","West","Karlstraße 14, 99817 Eisenach","03691 124000","pi-eisenach@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Prävention\"]",10,43);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("gotha","Polizeiinspektion Gotha","Gotha","West","Hauptmarkt 3, 99867 Gotha","03621 124100","pi-gotha@polizei-rp-erfurt.de","Mo–Fr 07:00–19:00 Uhr","[\"Anzeige\",\"Beratung\",\"Termine\"]",32,47);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("suhl","Polizeiinspektion Suhl","Suhl","Süd","Rathausstraße 6, 98527 Suhl","03681 124200","pi-suhl@polizei-rp-erfurt.de","24 Stunden täglich","[\"Anzeige\",\"Beratung\",\"Termine\"]",40,76);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("meiningen","Polizeiinspektion Meiningen","Meiningen","Süd","Markt 10, 98617 Meiningen","03693 124300","pi-meiningen@polizei-rp-erfurt.de","Mo–Fr 08:00–18:00 Uhr","[\"Anzeige\",\"Beratung\",\"Prävention\"]",27,82);
INSERT IGNORE INTO stations (id,name,city,region,address,phone,email,hours,services,x,y) VALUES ("sonneberg","Polizeiinspektion Sonneberg","Sonneberg","Süd","Bahnhofstraße 21, 96515 Sonneberg","03675 124400","pi-sonneberg@polizei-rp-erfurt.de","Mo–Fr 07:00–19:00 Uhr","[\"Anzeige\",\"Beratung\",\"Termine\"]",54,88);
