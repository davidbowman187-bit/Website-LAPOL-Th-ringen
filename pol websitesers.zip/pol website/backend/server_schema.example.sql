-- Beispiel-Schema für die Server-Datenbank (FiveM)
-- Nur als Referenz. Das Aktensystem liest aus diesen Tabellen, falls vorhanden.

CREATE TABLE IF NOT EXISTS police_cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_number VARCHAR(40) NOT NULL UNIQUE,
  title VARCHAR(190) NOT NULL,
  description TEXT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'offen',
  character_identifier VARCHAR(120) NULL,
  created_by VARCHAR(120) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS police_characters (
  id INT AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(120) NOT NULL UNIQUE,
  firstname VARCHAR(80) NULL,
  lastname VARCHAR(80) NULL,
  dateofbirth DATE NULL,
  phone VARCHAR(40) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;