-- Schema for Landespolizei Thüringen Roleplay backend
-- Target: MySQL / MariaDB (FiveM compatible)

CREATE TABLE IF NOT EXISTS ranks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  level INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS permissions (
  `key` VARCHAR(100) PRIMARY KEY,
  description VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rank_permissions (
  rank_id INT NOT NULL,
  permission_key VARCHAR(100) NOT NULL,
  PRIMARY KEY (rank_id, permission_key),
  FOREIGN KEY (rank_id) REFERENCES ranks(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_key) REFERENCES permissions(`key`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(120) NOT NULL,
  rank_id INT NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  last_login TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rank_id) REFERENCES ranks(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref VARCHAR(40) NOT NULL UNIQUE,
  type VARCHAR(40) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'eingegangen',
  payload LONGTEXT NOT NULL,
  applicant_name VARCHAR(120) NULL,
  applicant_email VARCHAR(190) NULL,
  applicant_birth DATE NULL,
  station_id VARCHAR(80) NULL,
  assigned_to INT NULL,
  internal_note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_applications_type (type),
  INDEX idx_applications_status (status),
  INDEX idx_applications_ref (ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS wanted_persons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_no VARCHAR(40) NOT NULL UNIQUE,
  category VARCHAR(40) NOT NULL DEFAULT 'person',
  title VARCHAR(190) NOT NULL,
  location VARCHAR(190) NULL,
  teaser VARCHAR(255) NULL,
  description TEXT NULL,
  facts LONGTEXT NULL,
  hint VARCHAR(255) NULL,
  icon VARCHAR(40) NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'aktiv',
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS news (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(120) NOT NULL UNIQUE,
  category VARCHAR(40) NOT NULL,
  label VARCHAR(80) NOT NULL,
  title VARCHAR(190) NOT NULL,
  teaser VARCHAR(255) NULL,
  location VARCHAR(120) NULL,
  reading INT NOT NULL DEFAULT 1,
  featured TINYINT(1) NOT NULL DEFAULT 0,
  icon VARCHAR(40) NULL,
  body LONGTEXT NULL,
  published TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id VARCHAR(40) NULL,
  details LONGTEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Permissions
INSERT IGNORE INTO permissions (`key`, description) VALUES
('dashboard.view', 'Dashboard und Übersicht einsehen'),
('applications.view', 'Anträge und Vorgänge einsehen'),
('applications.manage', 'Anträge bearbeiten und Status setzen'),
('wanted.view', 'Fahndungen einsehen'),
('wanted.manage', 'Fahndungen erstellen und bearbeiten'),
('news.view', 'Meldungen einsehen'),
('news.manage', 'Meldungen erstellen und bearbeiten'),
('users.view', 'Benutzer einsehen'),
('users.manage', 'Benutzer und Ränge zuweisen'),
('ranks.view', 'Ränge einsehen'),
('ranks.manage', 'Ränge und Berechtigungen verwalten'),
('stations.manage', 'Dienststellen verwalten');

-- Ranks
INSERT IGNORE INTO ranks (id, name, description, level) VALUES
(1, 'Administrator', 'Vollzugriff auf alle Funktionen', 100),
(2, 'Leitung', 'Leitung der Dienststelle', 80),
(3, 'Sachbearbeiter', 'Bearbeitung von Anträgen und Meldungen', 50),
(4, 'Streifendienst', 'Einsatz und Grundfunktionen', 20);

-- Rank permissions
INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(1,'dashboard.view'),(1,'applications.view'),(1,'applications.manage'),(1,'wanted.view'),(1,'wanted.manage'),(1,'news.view'),(1,'news.manage'),(1,'users.view'),(1,'users.manage'),(1,'ranks.view'),(1,'ranks.manage'),(1,'stations.manage');

INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(2,'dashboard.view'),(2,'applications.view'),(2,'applications.manage'),(2,'wanted.view'),(2,'wanted.manage'),(2,'news.view'),(2,'news.manage'),(2,'users.view'),(2,'ranks.view');

INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(3,'dashboard.view'),(3,'applications.view'),(3,'applications.manage'),(3,'wanted.view'),(3,'news.view'),(3,'news.manage');

INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
(4,'dashboard.view'),(4,'applications.view'),(4,'wanted.view'),(4,'news.view');

-- Admin user (password: Admin123!)
INSERT IGNORE INTO users (id, username, password_hash, display_name, rank_id, active)
VALUES (1, 'admin', '$2b$10$unhRwp.XRELvxn8zt0LF6etjcztCm3fWLJxjN2K8Ezv4ujuAbLTmy', 'Administrator', 1, 1);

-- Demo user (password: polizei2026)
INSERT IGNORE INTO users (id, username, password_hash, display_name, rank_id, active)
VALUES (2, 'demo', '$2b$10$Bsbyws/h87qP5MTFP4bgCujl3Ih64mHMlhBGAkgrkop1A6LRjEHNi', 'K. Weber', 3, 1);