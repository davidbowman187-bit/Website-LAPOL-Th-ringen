-- ============================================================================
--  Landespolizei Thüringen · Roleplay Erfurt
--  Vollständiges Datenbank-Schema für Website & Intranet
--  Ziel: MySQL 8 / MariaDB (FiveM-kompatibel)
--
--  Import:
--    mysql -u root -p < backend/database.sql
--  oder in phpMyAdmin / HeidiSQL komplett ausführen.
--
--  Enthält:
--    Ränge, Berechtigungen, Benutzer, Vorgänge/Anträge, Fahndungen,
--    Meldungen, Dienststellen, Asservaten, PDF-Dokumente, Audit-Log.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `lpt_website`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `lpt_website`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Ränge
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ranks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(80) NOT NULL UNIQUE,
  `description` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Berechtigungen
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
  `key` VARCHAR(100) PRIMARY KEY,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `rank_permissions` (
  `rank_id` INT NOT NULL,
  `permission_key` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`rank_id`, `permission_key`),
  FOREIGN KEY (`rank_id`) REFERENCES `ranks`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`permission_key`) REFERENCES `permissions`(`key`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Benutzer
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(80) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `display_name` VARCHAR(120) NOT NULL,
  `rank_id` INT NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`rank_id`) REFERENCES `ranks`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Vorgänge / Anträge (öffentliche Formulare + Intranet)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ref` VARCHAR(40) NOT NULL UNIQUE,
  `type` VARCHAR(40) NOT NULL,
  `status` VARCHAR(40) NOT NULL DEFAULT 'eingegangen',
  `payload` LONGTEXT NOT NULL,
  `applicant_name` VARCHAR(120) NULL,
  `applicant_email` VARCHAR(190) NULL,
  `applicant_birth` DATE NULL,
  `station_id` VARCHAR(80) NULL,
  `citizen_id` INT NULL,
  `assigned_to` INT NULL,
  `internal_note` TEXT NULL,
  `archived_at` DATETIME NULL,
  `archived_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`assigned_to`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_applications_type` (`type`),
  INDEX `idx_applications_status` (`status`),
  INDEX `idx_applications_ref` (`ref`),
  INDEX `idx_applications_citizen` (`citizen_id`),
  INDEX `idx_applications_archived` (`archived_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Fahndungen
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wanted_persons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `case_no` VARCHAR(40) NOT NULL UNIQUE,
  `category` VARCHAR(40) NOT NULL DEFAULT 'person',
  `title` VARCHAR(190) NOT NULL,
  `location` VARCHAR(190) NULL,
  `teaser` VARCHAR(255) NULL,
  `description` TEXT NULL,
  `facts` LONGTEXT NULL,
  `hint` VARCHAR(255) NULL,
  `icon` VARCHAR(40) NULL,
  `status` VARCHAR(40) NOT NULL DEFAULT 'aktiv',
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_wanted_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Meldungen / Presse
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `news` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(120) NOT NULL UNIQUE,
  `category` VARCHAR(40) NOT NULL,
  `label` VARCHAR(80) NOT NULL,
  `title` VARCHAR(190) NOT NULL,
  `teaser` VARCHAR(255) NULL,
  `location` VARCHAR(120) NULL,
  `reading` INT NOT NULL DEFAULT 1,
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `icon` VARCHAR(40) NULL,
  `body` LONGTEXT NULL,
  `published` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_news_published` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Dienststellen
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stations` (
  `id` VARCHAR(80) PRIMARY KEY,
  `name` VARCHAR(190) NOT NULL,
  `city` VARCHAR(120) NOT NULL,
  `region` VARCHAR(40) NOT NULL,
  `address` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(40) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `hours` VARCHAR(120) NOT NULL,
  `services` LONGTEXT NOT NULL,
  `x` INT NOT NULL,
  `y` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Asservaten
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `evidence` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `item_no` VARCHAR(40) NOT NULL UNIQUE,
  `title` VARCHAR(190) NOT NULL,
  `category` VARCHAR(80) NULL,
  `location` VARCHAR(120) NULL,
  `status` VARCHAR(40) NOT NULL DEFAULT 'eingelagert',
  `description` TEXT NULL,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- PDF-Dokumente (z. B. Führungszeugnis) – Inhalt wird in der DB gespeichert
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `documents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NULL,
  `ref` VARCHAR(40) NOT NULL,
  `filename` VARCHAR(190) NOT NULL,
  `mime` VARCHAR(80) NOT NULL DEFAULT 'application/pdf',
  `size` INT NOT NULL DEFAULT 0,
  `data` LONGBLOB NOT NULL,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_documents_ref` (`ref`),
  INDEX `idx_documents_application` (`application_id`),
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Audit-Log
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL,
  `action` VARCHAR(80) NOT NULL,
  `entity_type` VARCHAR(40) NULL,
  `entity_id` VARCHAR(40) NULL,
  `details` LONGTEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
--  STARTDATEN
-- ============================================================================

INSERT IGNORE INTO `permissions` (`key`, `description`) VALUES
('dashboard.view', 'Dashboard und Übersicht einsehen'),
('applications.view', 'Anträge und Vorgänge einsehen'),
('applications.manage', 'Anträge bearbeiten und Status setzen'),
('wanted.view', 'Fahndungen einsehen'),
('wanted.manage', 'Fahndungen erstellen und bearbeiten'),
('news.view', 'Meldungen einsehen'),
('news.manage', 'Meldungen erstellen und bearbeiten'),
('users.view', 'Benutzer einsehen'),
('users.manage', 'Benutzer und Ränge zuweisen'),
('ranks.view', 'Ränge einsehen'),
('ranks.manage', 'Ränge und Berechtigungen verwalten'),
('stations.manage', 'Dienststellen verwalten'),
('evidence.view', 'Asservaten einsehen'),
('evidence.manage', 'Asservaten verwalten'),
('archive.manage', 'Tickets archivieren und wiederherstellen'),
('laws.manage', 'Gesetzbuch und Paragraphen bearbeiten'),
('recruitment.manage', 'Bewerbungsphasen öffnen und schließen'),
('training.view', 'Ausbildungen, Tests und Unterlagen einsehen'),
('training.manage', 'Ausbildungen, Tests und Unterlagen erstellen und bearbeiten'),
('hr.view', 'Bewerbungen im Personalbereich einsehen'),
('hr.manage', 'Bewerbungen und Personalvorgänge bearbeiten'),
('leadership.view', 'Leitungsbereich einsehen'),
('leadership.manage', 'Leitungsnotizen erstellen und bearbeiten');

INSERT IGNORE INTO `ranks` (`id`, `name`, `description`) VALUES
(1, 'Administrator', 'Vollzugriff auf alle Funktionen'),
(2, 'Leitung', 'Leitung der Dienststelle'),
(3, 'Sachbearbeiter', 'Bearbeitung von Anträgen und Meldungen'),
(4, 'Streifendienst', 'Einsatz und Grundfunktionen'),
(5, 'Personal & Ausbildung', 'Bewerbungen, Ausbildungen und Tests verwalten');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(1,'dashboard.view'),(1,'applications.view'),(1,'applications.manage'),
(1,'wanted.view'),(1,'wanted.manage'),(1,'news.view'),(1,'news.manage'),
(1,'users.view'),(1,'users.manage'),(1,'ranks.view'),(1,'ranks.manage'),
(1,'stations.manage'),(1,'evidence.view'),(1,'evidence.manage'),
(1,'activity.view'),(1,'activity.manage'),(1,'weapons.view'),(1,'weapons.manage'),
(1,'archive.manage'),(1,'laws.manage'),(1,'recruitment.manage'),
(1,'training.view'),(1,'training.manage'),(1,'hr.view'),(1,'hr.manage'),
(1,'leadership.view'),(1,'leadership.manage');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(2,'dashboard.view'),(2,'applications.view'),(2,'applications.manage'),
(2,'wanted.view'),(2,'wanted.manage'),(2,'news.view'),(2,'news.manage'),
(2,'users.view'),(2,'ranks.view'),(2,'evidence.view'),(2,'evidence.manage'),
(2,'archive.manage'),(2,'recruitment.manage'),
(2,'training.view'),(2,'hr.view'),(2,'leadership.view'),(2,'leadership.manage');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(3,'dashboard.view'),(3,'applications.view'),(3,'applications.manage'),
(3,'wanted.view'),(3,'news.view'),(3,'news.manage'),(3,'evidence.view');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(4,'dashboard.view'),(4,'applications.view'),(4,'wanted.view'),(4,'news.view');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(5,'dashboard.view'),(5,'applications.view'),(5,'applications.manage'),
(5,'training.view'),(5,'training.manage'),(5,'hr.view'),(5,'hr.manage');

-- Benutzer: admin / Admin123!
INSERT IGNORE INTO `users` (`id`, `username`, `password_hash`, `display_name`, `rank_id`, `active`) VALUES
(1, 'admin', '$2b$10$unhRwp.XRELvxn8zt0LF6etjcztCm3fWLJxjN2K8Ezv4ujuAbLTmy', 'Administrator', 1, 1);

-- Dienststellen (13 Standorte in Thüringen)
INSERT IGNORE INTO `stations` (`id`,`name`,`city`,`region`,`address`,`phone`,`email`,`hours`,`services`,`x`,`y`) VALUES ('erfurt-zentrum','Polizeiinspektion Erfurt','Erfurt','Erfurt','Andreasstraße 36, 99084 Erfurt','','','24 Stunden täglich','["Anzeige","Beratung","Termine","Prävention"]',47,49);
DELETE FROM `stations` WHERE `id` <> 'erfurt-zentrum';

-- Beispiel-Fahndungen
INSERT IGNORE INTO `wanted_persons` (`case_no`,`category`,`title`,`location`,`teaser`,`description`,`facts`,`hint`,`icon`,`status`,`created_by`) VALUES
('F-2026-114','person','Vermisster Linus M.','Erfurt, Hauptbahnhof','15-Jähriger seit 28.10.2026 vermisst','Seit dem 28. Oktober wird der 15-jährige Linus M. aus Erfurt-Süd vermisst. Zuletzt wurde er am Hauptbahnhof gesehen.','["Zuletzt gesehen: 28.10.2026","ca. 1,75 m","schwarze Jacke"]','Bitte wenden Sie sich an die Polizei oder die Onlinewache.','user','aktiv',1);

-- Beispiel-Meldungen
INSERT IGNORE INTO `news` (`slug`,`category`,`label`,`title`,`teaser`,`location`,`reading`,`featured`,`icon`,`body`,`published`,`created_by`) VALUES
('praeventionswoche-november','presse','Presse','Präventionswoche im November','Die Polizei Thüringen informiert über Einbruchschutz und Cybercrime.','Erfurt',2,1,'file','["<p>Vom 10. bis 16. November findet die Präventionswoche der Landespolizei Thüringen statt.</p>","<p>Fachkräfte beraten kostenlos zu Einbruchschutz, Cybercrime und Seniorensicherheit.</p>"]',1,1),
('neue-software-onlinewache','service','Service','Neue Software für die Onlinewache','Die Onlinewache wurde technisch modernisiert.','Erfurt',1,0,'file','["<p>Die Onlinewache der Landespolizei Thüringen wurde aktualisiert und ist weiterhin rund um die Uhr erreichbar.</p>"]',1,1);

-- ============================================================================
--  FERTIG
--  Zugang:  admin / Admin123!
-- ============================================================================


-- ============================================================================
--  AKTENSYSTEM: Waffenregister, Tätigkeitsberichte, Gesetzbuch
-- ============================================================================

CREATE TABLE IF NOT EXISTS `weapons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `owner_name` VARCHAR(120) NOT NULL,
  `owner_identifier` VARCHAR(60) NULL,
  `weapon_type` VARCHAR(80) NOT NULL,
  `model` VARCHAR(120) NULL,
  `serial_number` VARCHAR(120) NULL,
  `license_number` VARCHAR(120) NULL,
  `registered_at` DATE NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'gueltig',
  `notes` TEXT NULL,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_weapons_owner` (`owner_name`),
  INDEX `idx_weapons_serial` (`serial_number`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `activity_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ref` VARCHAR(40) NOT NULL UNIQUE,
  `type` VARCHAR(40) NOT NULL DEFAULT 'sonstiges',
  `title` VARCHAR(190) NOT NULL,
  `officer_id` INT NULL,
  `officer_name` VARCHAR(120) NULL,
  `citizen_name` VARCHAR(120) NULL,
  `citizen_identifier` VARCHAR(60) NULL,
  `vehicle_plate` VARCHAR(20) NULL,
  `location` VARCHAR(190) NULL,
  `occurred_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` TEXT NULL,
  `measures` TEXT NULL,
  `outcome` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_activity_type` (`type`),
  INDEX `idx_activity_citizen` (`citizen_name`),
  FOREIGN KEY (`officer_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `laws` (
  `code` VARCHAR(20) PRIMARY KEY,
  `title` VARCHAR(120) NOT NULL,
  `subtitle` VARCHAR(190) NULL,
  `description` TEXT NULL,
  `icon` VARCHAR(40) NULL,
  `tags` TEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `law_sections` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `law_code` VARCHAR(20) NOT NULL,
  `number` VARCHAR(40) NOT NULL,
  `title` VARCHAR(190) NOT NULL,
  `text` TEXT NULL,
  `penalty` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `uq_law_section` (`law_code`, `number`),
  FOREIGN KEY (`law_code`) REFERENCES `laws`(`code`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `permissions` (`key`, `description`) VALUES
('weapons.view','Waffenregister einsehen'),
('weapons.manage','Waffenregister bearbeiten'),
('activity.view','Tätigkeitsberichte einsehen'),
('activity.manage','Tätigkeitsberichte erstellen und bearbeiten');

INSERT IGNORE INTO `rank_permissions` (`rank_id`, `permission_key`) VALUES
(1,'weapons.view'),(1,'weapons.manage'),(1,'activity.view'),(1,'activity.manage'),
(2,'weapons.view'),(2,'weapons.manage'),(2,'activity.view'),(2,'activity.manage'),
(3,'weapons.view'),(3,'activity.view'),(3,'activity.manage'),
(4,'activity.view');

INSERT IGNORE INTO `laws` (`code`,`title`,`subtitle`,`description`,`icon`,`tags`,`sort_order`) VALUES
('StVO','Straßenverkehrsordnung','Regeln für den Straßenverkehr und Verkehrssicherheit','Zentrale Vorschriften für alle Teilnehmer am Straßenverkehr – von Geschwindigkeit über Vorfahrt bis Parken.','car','["Verkehrsdelikte","Bußgelder"]',1),
('StVZO','Straßenverkehrszulassungsordnung','Technische Vorschriften für Kraftfahrzeuge','Regelt Zulassung, Ausrüstung und technische Prüfung von Fahrzeugen.','wrench','["Zulassung","Technik"]',2),
('StGB','Strafgesetzbuch','Allgemeine Straftaten und deren Sanktionen','Kernstrafrecht mit den wichtigsten Delikten und Strafrahmen für die polizeiliche Praxis.','gavel','["Straftaten","Sanktionen"]',3),
('StPO','Strafprozessordnung','Verfahrensregeln für Strafverfahren','Ablauf von Ermittlungs- und Strafverfahren, Durchsuchungen und Festnahmen.','search','["Verfahren","Prozessrecht"]',4),
('OWiG','Gesetz über Ordnungswidrigkeiten','Verwarnungen und Bußgeldverfahren','Regelt Ordnungswidrigkeiten, Verwarnungen und das Bußgeldverfahren.','alert','["OWi","Bußgelder"]',5),
('WaffG','Waffengesetz','Regelungen zu Waffen und Munition','Umgang, Besitz, Erwerb und Führen von Waffen sowie waffenrechtliche Erlaubnisse.','shield','["Waffen","Verstöße"]',6),
('BtMG','Betäubungsmittelgesetz','Regelungen zu Drogen und Betäubungsmitteln','Umgang mit Betäubungsmitteln, Erlaubnisse und strafrechtliche Folgen.','flask','["Betäubungsmittel","Drogendelikte"]',7),
('SprengG','Sprengstoffgesetz','Umgang mit Sprengstoffen und Explosivstoffen','Erlaubnisse, Kennzeichnung und Sicherheitsvorgaben im Umgang mit Explosivstoffen.','bomb','["Sprengstoff","Verstöße"]',8),
('VersG','Versammlungsgesetz','Regelungen für Versammlungen und Demonstrationen','Anmeldung, Durchführung und Auflagen bei Versammlungen und Demonstrationen.','megaphone','["Versammlungen","Demos"]',9),
('LuftVG','Luftverkehrsgesetz','Vorschriften für den Luftverkehr und die Nutzung des Luftraums','Regelt Luftfahrzeuge, Luftraum, Betrieb und Aufsicht im Luftverkehr.','plane','["Luftverkehr","Luftraum"]',10);

INSERT IGNORE INTO `law_sections` (`law_code`,`number`,`title`,`text`,`penalty`,`sort_order`) VALUES
('StVO','§ 1','Grundregeln','Die Teilnahme am Straßenverkehr erfordert ständige Vorsicht und gegenseitige Rücksicht. Verkehrsteilnehmer haben sich so zu verhalten, dass kein anderer geschädigt, gefährdet oder mehr als unvermeidbar behindert wird.','Verwarnung / Bußgeld',1),
('StVO','§ 3','Geschwindigkeit','Wer ein Fahrzeug führt, darf nur so schnell fahren, dass das Fahrzeug ständig beherrscht wird. Die Geschwindigkeit ist insbesondere den Straßen-, Sicht- und Wetterverhältnissen anzupassen.','Bußgeld ab 40 €',2),
('StVO','§ 24','Parken','Das Parken ist unzulässig, soweit es die Benutzung gekennzeichneter Flächen zum Abstellen von Fahrzeugen beeinträchtigt oder andere Verkehrsteilnehmer behindert.','Verwarnung / Abschleppen',3),
('StVZO','§ 29','Untersuchungspflicht','Kraftfahrzeuge sind in regelmäßigen Abständen auf ihre Verkehrssicherheit und Umweltverträglichkeit untersuchen zu lassen.','Bußgeld bei Überziehung',1),
('StVZO','§ 50','Beleuchtung','Kraftfahrzeuge müssen mit den vorgeschriebenen Beleuchtungseinrichtungen ausgerüstet sein. Diese müssen ordnungsgemäß betrieben werden können.','Bußgeld / Stilllegung',2),
('StGB','§ 242','Diebstahl','Wer eine fremde bewegliche Sache einem anderen in der Absicht wegnimmt, die Sache sich oder einem Dritten rechtswidrig zuzueignen, wird bestraft.','Freiheitsstrafe bis 5 Jahre',1),
('StGB','§ 223','Körperverletzung','Wer eine andere Person körperlich misshandelt oder an der Gesundheit schädigt, wird mit Freiheitsstrafe bis zu fünf Jahren oder mit Geldstrafe bestraft.','Freiheitsstrafe bis 5 Jahre',2),
('StGB','§ 263','Betrug','Wer in der Absicht, sich oder einem Dritten einen rechtswidrigen Vermögensvorteil zu verschaffen, das Vermögen eines anderen durch Täuschung schädigt, wird bestraft.','Freiheitsstrafe bis 5 Jahre',3),
('StPO','§ 102','Durchsuchung','Bei Verdacht einer Straftat kann die Wohnung, die Geschäftsräume und das befriedete Besitztum durchsucht werden, soweit dies zur Auffindung von Beweismitteln erforderlich ist.','Richterliche Anordnung',1),
('StPO','§ 127','Vorläufige Festnahme','Wird jemand auf frischer Tat betroffen oder verfolgt, so ist jede Person befugt, ihn auch ohne richterliche Anordnung vorläufig festzunehmen, wenn Fluchtverdacht besteht.','Festnahme / Prüfung',2),
('OWiG','§ 1','Begriffsbestimmung','Eine Ordnungswidrigkeit ist eine rechtswidrige und vorwerfbare Handlung, die den Tatbestand eines Gesetzes verwirklicht, das die Ahndung mit einer Geldbuße zulässt.','Geldbuße',1),
('OWiG','§ 56','Verwarnung','Bei geringfügigen Ordnungswidrigkeiten kann die Verwaltungsbehörde den Betroffenen verwarnen und ein Verwarnungsgeld erheben.','Verwarnungsgeld',2),
('WaffG','§ 1','Umgang mit Waffen','Der Umgang mit Waffen und Munition ist nur Personen erlaubt, die die erforderliche Zuverlässigkeit und persönliche Eignung besitzen und eine entsprechende Erlaubnis haben.','Erlaubnispflicht',1),
('WaffG','§ 51','Strafvorschriften','Wer ohne die erforderliche Erlaubnis eine Waffe erwirbt, besitzt oder führt, handelt strafbar.','Freiheitsstrafe bis 3 Jahre',2),
('BtMG','§ 1','Betäubungsmittel','Betäubungsmittel im Sinne dieses Gesetzes sind die in den Anlagen aufgeführten Stoffe und Zubereitungen.','Anlagenverweis',1),
('BtMG','§ 29','Straftaten','Mit Freiheitsstrafe bis zu fünf Jahren oder mit Geldstrafe wird bestraft, wer unbefugt Betäubungsmittel anbaut, herstellt, besitzt, abgibt oder sonst in den Verkehr bringt.','Freiheitsstrafe bis 5 Jahre',2),
('SprengG','§ 1','Anwendungsbereich','Dieses Gesetz gilt für den Umgang mit explosionsgefährlichen Stoffen sowie für die Errichtung und den Betrieb von Anlagen zu deren Herstellung oder Lagerung.','Erlaubnispflicht',1),
('SprengG','§ 40','Straftaten','Wer ohne Erlaubnis explosionsgefährliche Stoffe herstellt, lagert oder verwendet, kann strafrechtlich verfolgt werden.','Freiheitsstrafe bis 5 Jahre',2),
('VersG','§ 1','Versammlungsfreiheit','Alle Deutschen haben das Recht, sich ohne Anmeldung oder Erlaubnis friedlich und ohne Waffen zu versammeln.','Grundrecht',1),
('VersG','§ 15','Anmeldung','Wer eine Versammlung veranstalten will, hat dies spätestens 48 Stunden vor der Bekanntgabe bei der zuständigen Behörde anzumelden.','Frist 48 Stunden',2),
('LuftVG','§ 1','Luftverkehr','Der Luftverkehr unterliegt der Aufsicht des Bundes. Luftfahrzeuge dürfen nur mit Erlaubnis in den Luftraum einfliegen.','Erlaubnispflicht',1),
('LuftVG','§ 21','Luftfahrzeugführer','Luftfahrzeuge dürfen nur von Personen geführt werden, die die erforderliche Erlaubnis besitzen.','Erlaubnispflicht',2);


-- ============================================================================
--  TICKETS, BÜRGERKONTEN (DISCORD) & NEWSLETTER
-- ============================================================================

CREATE TABLE IF NOT EXISTS `citizen_accounts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `discord_id` VARCHAR(32) NOT NULL UNIQUE,
  `username` VARCHAR(100) NOT NULL,
  `global_name` VARCHAR(150) NULL,
  `avatar` VARCHAR(190) NULL,
  `email` VARCHAR(190) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `citizen_sessions` (
  `token_hash` CHAR(64) PRIMARY KEY,
  `citizen_id` INT NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `ip` VARCHAR(64) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_citizen_sessions_expires` (`expires_at`),
  INDEX `idx_citizen_sessions_citizen` (`citizen_id`),
  FOREIGN KEY (`citizen_id`) REFERENCES `citizen_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `citizen_events` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `citizen_id` INT NOT NULL,
  `event` VARCHAR(60) NOT NULL,
  `detail` TEXT NULL,
  `ip` VARCHAR(64) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_citizen_events_citizen` (`citizen_id`, `created_at`),
  FOREIGN KEY (`citizen_id`) REFERENCES `citizen_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ticket_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `sender` VARCHAR(20) NOT NULL DEFAULT 'citizen',
  `author_name` VARCHAR(120) NULL,
  `citizen_id` INT NULL,
  `message` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ticket_messages_application` (`application_id`),
  INDEX `idx_ticket_messages_citizen` (`citizen_id`),
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `newsletter_subscribers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(190) NOT NULL UNIQUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `application_uploads` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `kind` VARCHAR(30) NOT NULL,
  `filename` VARCHAR(190) NOT NULL,
  `mime` VARCHAR(100) NOT NULL,
  `size` INT NOT NULL DEFAULT 0,
  `data` LONGBLOB NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_application_uploads_app` (`application_id`),
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `recruitment_phases` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `phase_key` VARCHAR(60) NOT NULL UNIQUE,
  `label` VARCHAR(120) NOT NULL,
  `is_open` TINYINT(1) NOT NULL DEFAULT 1,
  `note` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `updated_by` INT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- Ausbildung, Bewerbertests und Personalabteilung
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trainings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(190) NOT NULL,
  `description` TEXT NULL,
  `start_date` DATE NULL,
  `end_date` DATE NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'geplant',
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_trainings_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `training_documents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `training_id` INT NOT NULL,
  `title` VARCHAR(190) NOT NULL,
  `filename` VARCHAR(190) NOT NULL,
  `mime` VARCHAR(100) NOT NULL,
  `size` INT NOT NULL DEFAULT 0,
  `data` LONGBLOB NOT NULL,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_training_documents_training` (`training_id`),
  FOREIGN KEY (`training_id`) REFERENCES `trainings`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `training_tests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `training_id` INT NULL,
  `title` VARCHAR(190) NOT NULL,
  `description` TEXT NULL,
  `pass_score` INT NOT NULL DEFAULT 70,
  `public_code` VARCHAR(32) NOT NULL UNIQUE,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_training_tests_training` (`training_id`),
  FOREIGN KEY (`training_id`) REFERENCES `trainings`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `training_test_questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `test_id` INT NOT NULL,
  `question` TEXT NOT NULL,
  `options` LONGTEXT NOT NULL,
  `correct_index` INT NOT NULL DEFAULT 0,
  `sort_order` INT NOT NULL DEFAULT 0,
  INDEX `idx_training_questions_test` (`test_id`),
  FOREIGN KEY (`test_id`) REFERENCES `training_tests`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `training_test_results` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `test_id` INT NOT NULL,
  `application_id` INT NULL,
  `applicant_name` VARCHAR(120) NOT NULL,
  `score` INT NOT NULL DEFAULT 0,
  `passed` TINYINT(1) NOT NULL DEFAULT 0,
  `answers` LONGTEXT NULL,
  `taken_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_training_results_test` (`test_id`),
  INDEX `idx_training_results_application` (`application_id`),
  FOREIGN KEY (`test_id`) REFERENCES `training_tests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `leadership_notes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(190) NOT NULL,
  `body` TEXT NULL,
  `priority` VARCHAR(20) NOT NULL DEFAULT 'normal',
  `status` VARCHAR(20) NOT NULL DEFAULT 'offen',
  `created_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_leadership_notes_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `recruitment_phases` (`phase_key`, `label`, `is_open`, `sort_order`) VALUES
('ausbildung_mittlerer_dienst', 'Ausbildung mittlerer Dienst', 1, 1),
('sachbearbeiter', 'Sachbearbeiter', 1, 2);
