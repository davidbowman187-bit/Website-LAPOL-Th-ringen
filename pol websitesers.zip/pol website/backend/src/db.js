const mysql = require('mysql2/promise');
require('dotenv').config();

function createPool(prefix) {
  return mysql.createPool({
    host: process.env[`${prefix}_HOST`] || process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env[`${prefix}_PORT`] || process.env.DB_PORT || 3306),
    user: process.env[`${prefix}_USER`] || process.env.DB_USER || 'root',
    password: process.env[`${prefix}_PASSWORD`] || process.env.DB_PASSWORD || '',
    database: process.env[`${prefix}_NAME`] || process.env.DB_NAME || 'lpt_rp',
    waitForConnections: true,
    connectionLimit: Number(process.env[`${prefix}_POOL`] || process.env.DB_POOL || 10),
    queueLimit: 0,
    charset: 'utf8mb4'
  });
}

// Website-Datenbank (eigene DB für die Website)
const websitePool = createPool('WEBSITE_DB');

// Server-Datenbank (FiveM) – nur für das Aktensystem
const serverPool = createPool('SERVER_DB');

async function query(sql, params = []) {
  const [rows] = await websitePool.execute(sql, params);
  return rows;
}

async function serverQuery(sql, params = []) {
  const [rows] = await serverPool.execute(sql, params);
  return rows;
}

async function transaction(fn) {
  const conn = await websitePool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { websitePool, serverPool, query, serverQuery, transaction };