/* Migration & Seed für das Aktensystem (Waffen, Tätigkeitsberichte, Gesetzbuch) */

const LAWS = [
  ['StVO', 'Straßenverkehrsordnung', 'Regeln für den Straßenverkehr und Verkehrssicherheit', 'Zentrale Vorschriften für alle Teilnehmer am Straßenverkehr – von Geschwindigkeit über Vorfahrt bis Parken.', 'car', ['Verkehrsdelikte', 'Bußgelder'], 1],
  ['StVZO', 'Straßenverkehrszulassungsordnung', 'Technische Vorschriften für Kraftfahrzeuge', 'Regelt Zulassung, Ausrüstung und technische Prüfung von Fahrzeugen.', 'wrench', ['Zulassung', 'Technik'], 2],
  ['StGB', 'Strafgesetzbuch', 'Allgemeine Straftaten und deren Sanktionen', 'Kernstrafrecht mit den wichtigsten Delikten und Strafrahmen für die polizeiliche Praxis.', 'gavel', ['Straftaten', 'Sanktionen'], 3],
  ['StPO', 'Strafprozessordnung', 'Verfahrensregeln für Strafverfahren', 'Ablauf von Ermittlungs- und Strafverfahren, Durchsuchungen und Festnahmen.', 'search', ['Verfahren', 'Prozessrecht'], 4],
  ['OWiG', 'Gesetz über Ordnungswidrigkeiten', 'Verwarnungen und Bußgeldverfahren', 'Regelt Ordnungswidrigkeiten, Verwarnungen und das Bußgeldverfahren.', 'alert', ['OWi', 'Bußgelder'], 5],
  ['WaffG', 'Waffengesetz', 'Regelungen zu Waffen und Munition', 'Umgang, Besitz, Erwerb und Führen von Waffen sowie waffenrechtliche Erlaubnisse.', 'shield', ['Waffen', 'Verstöße'], 6],
  ['BtMG', 'Betäubungsmittelgesetz', 'Regelungen zu Drogen und Betäubungsmitteln', 'Umgang mit Betäubungsmitteln, Erlaubnisse und strafrechtliche Folgen.', 'flask', ['Betäubungsmittel', 'Drogendelikte'], 7],
  ['SprengG', 'Sprengstoffgesetz', 'Umgang mit Sprengstoffen und Explosivstoffen', 'Erlaubnisse, Kennzeichnung und Sicherheitsvorgaben im Umgang mit Explosivstoffen.', 'bomb', ['Sprengstoff', 'Verstöße'], 8],
  ['VersG', 'Versammlungsgesetz', 'Regelungen für Versammlungen und Demonstrationen', 'Anmeldung, Durchführung und Auflagen bei Versammlungen und Demonstrationen.', 'megaphone', ['Versammlungen', 'Demos'], 9],
  ['LuftVG', 'Luftverkehrsgesetz', 'Vorschriften für den Luftverkehr und die Nutzung des Luftraums', 'Regelt Luftfahrzeuge, Luftraum, Betrieb und Aufsicht im Luftverkehr.', 'plane', ['Luftverkehr', 'Luftraum'], 10]
];

const SECTIONS = [
  ['StVO', '§ 1', 'Grundregeln', 'Die Teilnahme am Straßenverkehr erfordert ständige Vorsicht und gegenseitige Rücksicht. Verkehrsteilnehmer haben sich so zu verhalten, dass kein anderer geschädigt, gefährdet oder mehr als unvermeidbar behindert wird.', 'Verwarnung / Bußgeld', 1],
  ['StVO', '§ 3', 'Geschwindigkeit', 'Wer ein Fahrzeug führt, darf nur so schnell fahren, dass das Fahrzeug ständig beherrscht wird. Die Geschwindigkeit ist insbesondere den Straßen-, Sicht- und Wetterverhältnissen anzupassen.', 'Bußgeld ab 40 €', 2],
  ['StVO', '§ 24', 'Parken', 'Das Parken ist unzulässig, soweit es die Benutzung gekennzeichneter Flächen zum Abstellen von Fahrzeugen beeinträchtigt oder andere Verkehrsteilnehmer behindert.', 'Verwarnung / Abschleppen', 3],
  ['StVZO', '§ 29', 'Untersuchungspflicht', 'Kraftfahrzeuge sind in regelmäßigen Abständen auf ihre Verkehrssicherheit und Umweltverträglichkeit untersuchen zu lassen.', 'Bußgeld bei Überziehung', 1],
  ['StVZO', '§ 50', 'Beleuchtung', 'Kraftfahrzeuge müssen mit den vorgeschriebenen Beleuchtungseinrichtungen ausgerüstet sein. Diese müssen ordnungsgemäß betrieben werden können.', 'Bußgeld / Stilllegung', 2],
  ['StGB', '§ 242', 'Diebstahl', 'Wer eine fremde bewegliche Sache einem anderen in der Absicht wegnimmt, die Sache sich oder einem Dritten rechtswidrig zuzueignen, wird bestraft.', 'Freiheitsstrafe bis 5 Jahre', 1],
  ['StGB', '§ 223', 'Körperverletzung', 'Wer eine andere Person körperlich misshandelt oder an der Gesundheit schädigt, wird mit Freiheitsstrafe bis zu fünf Jahren oder mit Geldstrafe bestraft.', 'Freiheitsstrafe bis 5 Jahre', 2],
  ['StGB', '§ 263', 'Betrug', 'Wer in der Absicht, sich oder einem Dritten einen rechtswidrigen Vermögensvorteil zu verschaffen, das Vermögen eines anderen durch Täuschung schädigt, wird bestraft.', 'Freiheitsstrafe bis 5 Jahre', 3],
  ['StPO', '§ 102', 'Durchsuchung', 'Bei Verdacht einer Straftat kann die Wohnung, die Geschäftsräume und das befriedete Besitztum durchsucht werden, soweit dies zur Auffindung von Beweismitteln erforderlich ist.', 'Richterliche Anordnung', 1],
  ['StPO', '§ 127', 'Vorläufige Festnahme', 'Wird jemand auf frischer Tat betroffen oder verfolgt, so ist jede Person befugt, ihn auch ohne richterliche Anordnung vorläufig festzunehmen, wenn Fluchtverdacht besteht.', 'Festnahme / Prüfung', 2],
  ['OWiG', '§ 1', 'Begriffsbestimmung', 'Eine Ordnungswidrigkeit ist eine rechtswidrige und vorwerfbare Handlung, die den Tatbestand eines Gesetzes verwirklicht, das die Ahndung mit einer Geldbuße zulässt.', 'Geldbuße', 1],
  ['OWiG', '§ 56', 'Verwarnung', 'Bei geringfügigen Ordnungswidrigkeiten kann die Verwaltungsbehörde den Betroffenen verwarnen und ein Verwarnungsgeld erheben.', 'Verwarnungsgeld', 2],
  ['WaffG', '§ 1', 'Umgang mit Waffen', 'Der Umgang mit Waffen und Munition ist nur Personen erlaubt, die die erforderliche Zuverlässigkeit und persönliche Eignung besitzen und eine entsprechende Erlaubnis haben.', 'Erlaubnispflicht', 1],
  ['WaffG', '§ 51', 'Strafvorschriften', 'Wer ohne die erforderliche Erlaubnis eine Waffe erwirbt, besitzt oder führt, handelt strafbar.', 'Freiheitsstrafe bis 3 Jahre', 2],
  ['BtMG', '§ 1', 'Betäubungsmittel', 'Betäubungsmittel im Sinne dieses Gesetzes sind die in den Anlagen aufgeführten Stoffe und Zubereitungen.', 'Anlagenverweis', 1],
  ['BtMG', '§ 29', 'Straftaten', 'Mit Freiheitsstrafe bis zu fünf Jahren oder mit Geldstrafe wird bestraft, wer unbefugt Betäubungsmittel anbaut, herstellt, besitzt, abgibt oder sonst in den Verkehr bringt.', 'Freiheitsstrafe bis 5 Jahre', 2],
  ['SprengG', '§ 1', 'Anwendungsbereich', 'Dieses Gesetz gilt für den Umgang mit explosionsgefährlichen Stoffen sowie für die Errichtung und den Betrieb von Anlagen zu deren Herstellung oder Lagerung.', 'Erlaubnispflicht', 1],
  ['SprengG', '§ 40', 'Straftaten', 'Wer ohne Erlaubnis explosionsgefährliche Stoffe herstellt, lagert oder verwendet, kann strafrechtlich verfolgt werden.', 'Freiheitsstrafe bis 5 Jahre', 2],
  ['VersG', '§ 1', 'Versammlungsfreiheit', 'Alle Deutschen haben das Recht, sich ohne Anmeldung oder Erlaubnis friedlich und ohne Waffen zu versammeln.', 'Grundrecht', 1],
  ['VersG', '§ 15', 'Anmeldung', 'Wer eine Versammlung veranstalten will, hat dies spätestens 48 Stunden vor der Bekanntgabe bei der zuständigen Behörde anzumelden.', 'Frist 48 Stunden', 2],
  ['LuftVG', '§ 1', 'Luftverkehr', 'Der Luftverkehr unterliegt der Aufsicht des Bundes. Luftfahrzeuge dürfen nur mit Erlaubnis in den Luftraum einfliegen.', 'Erlaubnispflicht', 1],
  ['LuftVG', '§ 21', 'Luftfahrzeugführer', 'Luftfahrzeuge dürfen nur von Personen geführt werden, die die erforderliche Erlaubnis besitzen.', 'Erlaubnispflicht', 2]
];

async function migrateAktensystem(query) {
  await query(`CREATE TABLE IF NOT EXISTS weapons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_name VARCHAR(120) NOT NULL,
    owner_identifier VARCHAR(60) NULL,
    weapon_type VARCHAR(80) NOT NULL,
    model VARCHAR(120) NULL,
    serial_number VARCHAR(120) NULL,
    license_number VARCHAR(120) NULL,
    registered_at DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'gueltig',
    notes TEXT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_weapons_owner (owner_name),
    INDEX idx_weapons_serial (serial_number),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS activity_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ref VARCHAR(40) NOT NULL UNIQUE,
    type VARCHAR(40) NOT NULL DEFAULT 'sonstiges',
    title VARCHAR(190) NOT NULL,
    officer_id INT NULL,
    officer_name VARCHAR(120) NULL,
    citizen_name VARCHAR(120) NULL,
    citizen_identifier VARCHAR(60) NULL,
    vehicle_plate VARCHAR(20) NULL,
    location VARCHAR(190) NULL,
    occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    description TEXT NULL,
    measures TEXT NULL,
    outcome TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_activity_type (type),
    INDEX idx_activity_citizen (citizen_name),
    FOREIGN KEY (officer_id) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS laws (
    code VARCHAR(20) PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    subtitle VARCHAR(190) NULL,
    description TEXT NULL,
    icon VARCHAR(40) NULL,
    tags TEXT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS law_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    law_code VARCHAR(20) NOT NULL,
    number VARCHAR(40) NOT NULL,
    title VARCHAR(190) NOT NULL,
    text TEXT NULL,
    penalty VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    UNIQUE KEY uq_law_section (law_code, number),
    FOREIGN KEY (law_code) REFERENCES laws(code) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`INSERT IGNORE INTO permissions (\`key\`, description) VALUES
    ('weapons.view','Waffenregister einsehen'),
    ('weapons.manage','Waffenregister bearbeiten'),
    ('activity.view','Tätigkeitsberichte einsehen'),
    ('activity.manage','Tätigkeitsberichte erstellen und bearbeiten')`);

  await query(`INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
    (1,'weapons.view'),(1,'weapons.manage'),(1,'activity.view'),(1,'activity.manage'),
    (2,'weapons.view'),(2,'weapons.manage'),(2,'activity.view'),(2,'activity.manage'),
    (3,'weapons.view'),(3,'activity.view'),(3,'activity.manage'),
    (4,'activity.view')`);

  for (const [code, title, subtitle, description, icon, tags, sort] of LAWS) {
    await query(
      `INSERT IGNORE INTO laws (code, title, subtitle, description, icon, tags, sort_order)
       VALUES (?,?,?,?,?,?,?)`,
      [code, title, subtitle, description, icon, JSON.stringify(tags), sort]
    );
  }

  for (const [lawCode, number, title, text, penalty, sort] of SECTIONS) {
    await query(
      `INSERT IGNORE INTO law_sections (law_code, number, title, text, penalty, sort_order)
       VALUES (?,?,?,?,?,?)`,
      [lawCode, number, title, text, penalty, sort]
    );
  }
}

module.exports = { migrateAktensystem, LAWS, SECTIONS };
