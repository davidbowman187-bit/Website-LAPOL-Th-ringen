async function ensureColumn(query, table, column, definition) {
  const rows = await query(
    `SELECT COUNT(*) AS count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column]
  );
  if (!rows[0] || !rows[0].count) await query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
}

async function ensureIndex(query, table, indexName, columnList) {
  const rows = await query(
    `SELECT COUNT(*) AS count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`,
    [table, indexName]
  );
  if (!rows[0] || !rows[0].count) await query(`CREATE INDEX \`${indexName}\` ON \`${table}\` (${columnList})`);
}

async function migrateAdmin(query) {
  await ensureColumn(query, 'applications', 'archived_at', 'DATETIME NULL');
  await ensureColumn(query, 'applications', 'archived_by', 'INT NULL');
  await ensureIndex(query, 'applications', 'idx_applications_archived', '`archived_at`');

  await query(`CREATE TABLE IF NOT EXISTS application_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    kind VARCHAR(30) NOT NULL,
    filename VARCHAR(190) NOT NULL,
    mime VARCHAR(100) NOT NULL,
    size INT NOT NULL DEFAULT 0,
    data LONGBLOB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_application_uploads_app (application_id),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS recruitment_phases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phase_key VARCHAR(60) NOT NULL UNIQUE,
    label VARCHAR(120) NOT NULL,
    is_open TINYINT(1) NOT NULL DEFAULT 1,
    note VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_by INT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`INSERT IGNORE INTO recruitment_phases (phase_key, label, is_open, sort_order) VALUES
    ('ausbildung_mittlerer_dienst', 'Ausbildung mittlerer Dienst', 1, 1),
    ('sachbearbeiter', 'Sachbearbeiter', 1, 2)`);

  await query(`INSERT IGNORE INTO permissions (\`key\`, description) VALUES
    ('archive.manage', 'Tickets archivieren und wiederherstellen'),
    ('laws.manage', 'Gesetzbuch und Paragraphen bearbeiten'),
    ('recruitment.manage', 'Bewerbungsphasen öffnen und schließen')`);

  // Administrator erhält sämtliche Rechte – auch künftig hinzugefügte.
  await query('INSERT IGNORE INTO rank_permissions (rank_id, permission_key) SELECT 1, `key` FROM permissions');
  // Leitungsebene erhält Archiv- und Bewerbungsverwaltung.
  await query(`INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
    (2, 'archive.manage'), (2, 'recruitment.manage')`);

  // Level-Konzept vollständig entfernen; Rechte ergeben sich aus rank_permissions.
  const levelColumn = await query(
    `SELECT COUNT(*) AS count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ranks' AND COLUMN_NAME = 'level'`
  );
  if (levelColumn[0] && levelColumn[0].count) {
    await query('ALTER TABLE ranks DROP COLUMN level');
  }
}

module.exports = { migrateAdmin };
