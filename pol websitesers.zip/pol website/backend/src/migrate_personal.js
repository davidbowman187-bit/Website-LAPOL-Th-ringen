async function migratePersonal(query) {
  await query(`CREATE TABLE IF NOT EXISTS trainings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    description TEXT NULL,
    start_date DATE NULL,
    end_date DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'geplant',
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_trainings_status (status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS training_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    training_id INT NOT NULL,
    title VARCHAR(190) NOT NULL,
    filename VARCHAR(190) NOT NULL,
    mime VARCHAR(100) NOT NULL,
    size INT NOT NULL DEFAULT 0,
    data LONGBLOB NOT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_training_documents_training (training_id),
    FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS training_tests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    training_id INT NULL,
    title VARCHAR(190) NOT NULL,
    description TEXT NULL,
    pass_score INT NOT NULL DEFAULT 70,
    public_code VARCHAR(32) NOT NULL UNIQUE,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_training_tests_training (training_id),
    FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS training_test_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_id INT NOT NULL,
    question TEXT NOT NULL,
    options LONGTEXT NOT NULL,
    correct_index INT NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    INDEX idx_training_questions_test (test_id),
    FOREIGN KEY (test_id) REFERENCES training_tests(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS training_test_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_id INT NOT NULL,
    application_id INT NULL,
    applicant_name VARCHAR(120) NOT NULL,
    score INT NOT NULL DEFAULT 0,
    passed TINYINT(1) NOT NULL DEFAULT 0,
    answers LONGTEXT NULL,
    taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_training_results_test (test_id),
    INDEX idx_training_results_application (application_id),
    FOREIGN KEY (test_id) REFERENCES training_tests(id) ON DELETE CASCADE,
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS leadership_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    body TEXT NULL,
    priority VARCHAR(20) NOT NULL DEFAULT 'normal',
    status VARCHAR(20) NOT NULL DEFAULT 'offen',
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_leadership_notes_status (status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`INSERT IGNORE INTO permissions (\`key\`, description) VALUES
    ('training.view', 'Ausbildungen, Tests und Unterlagen einsehen'),
    ('training.manage', 'Ausbildungen, Tests und Unterlagen erstellen und bearbeiten'),
    ('hr.view', 'Bewerbungen im Personalbereich einsehen'),
    ('hr.manage', 'Bewerbungen und Personalvorgänge bearbeiten'),
    ('leadership.view', 'Leitungsbereich einsehen'),
    ('leadership.manage', 'Leitungsnotizen erstellen und bearbeiten')`);

  await query(`INSERT IGNORE INTO ranks (id, name, description) VALUES
    (5, 'Personal & Ausbildung', 'Bewerbungen, Ausbildungen und Tests verwalten')`);

  await query(`INSERT IGNORE INTO rank_permissions (rank_id, permission_key) VALUES
    (5,'dashboard.view'),(5,'applications.view'),(5,'applications.manage'),
    (5,'training.view'),(5,'training.manage'),(5,'hr.view'),(5,'hr.manage'),
    (2,'training.view'),(2,'hr.view'),(2,'leadership.view'),(2,'leadership.manage')`);

  // Administrator erhält auch die neuen Rechte.
  await query('INSERT IGNORE INTO rank_permissions (rank_id, permission_key) SELECT 1, `key` FROM permissions');
}

module.exports = { migratePersonal };
