/* Minimaler PDF-Generator (ohne externe Abhängigkeiten)
   Erzeugt ein Führungszeugnis als PDF-Buffer für die Demo. */

function sanitize(value) {
  return String(value == null ? '' : value)
    .replace(/[\u2018\u2019\u201A\u201B]/g, "'")
    .replace(/[\u201C\u201D\u201E\u201F]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/\u20AC/g, 'EUR')
    .replace(/\u00A0/g, ' ')
    .replace(/[^\x09\x0A\x0D\x20-\xFF]/g, '');
}

function esc(value) {
  return sanitize(value).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function formatDate(date) {
  const d = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(d.getTime())) return '-';
  return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

/**
 * Erzeugt ein Führungszeugnis-PDF.
 * @param {object} data
 * @returns {Buffer}
 */
function createCertificatePdf(data = {}) {
  const ref = data.ref || 'FZ/----/------';
  const firstName = data.firstName || '';
  const lastName = data.lastName || '';
  const name = [firstName, lastName].filter(Boolean).join(' ') || data.applicantName || '-';
  const birth = data.birth || '-';
  const birthplace = data.birthplace || '-';
  const street = data.street || '-';
  const zip = data.zip || '';
  const city = data.city || '';
  const address = [street, [zip, city].filter(Boolean).join(' ')].filter(Boolean).join(', ') || '-';
  const email = data.email || '-';
  const type = data.type === 'erweitert' ? 'Erweitertes Führungszeugnis' : 'Führungszeugnis';
  const issued = data.issuedAt ? new Date(data.issuedAt) : new Date();
  const validUntil = new Date(issued.getTime());
  validUntil.setMonth(validUntil.getMonth() + 6);

  const W = 595;
  const H = 842;
  const op = [];

  // Hintergrund
  op.push(`1 1 1 rg 0 0 ${W} ${H} re f`);
  // Kopfbereich
  op.push(`0.039 0.090 0.173 rg 0 721 ${W} 121 re f`);
  // Goldene Linie
  op.push(`0.949 0.757 0.306 rg 0 715 ${W} 6 re f`);
  // Blauer Akzent links
  op.push(`0.286 0.639 1 rg 0 721 8 121 re f`);

  // Kopftext
  op.push(`BT /F2 11 Tf 0.72 0.84 1 rg 48 806 Td (LANDESPOLIZEI THUERINGEN) Tj ET`);
  op.push(`BT /F2 27 Tf 1 1 1 rg 48 770 Td (FUEHRUNGSZEUGNIS) Tj ET`);
  op.push(`BT /F1 9 Tf 0.62 0.74 0.9 rg 48 754 Td (Digitale Bescheinigung - Roleplay-Projekt) Tj ET`);
  op.push(`BT /F2 10 Tf 0.949 0.757 0.306 rg 48 736 Td (Bundeszentralregister - Auszug) Tj ET`);

  // Aktenzeichen-Box
  op.push(`0.941 0.953 0.973 rg 48 655 ${W - 96} 52 re f`);
  op.push(`0.82 0.86 0.92 RG 1 w 48 655 ${W - 96} 52 re S`);
  op.push(`BT /F1 8 Tf 0.35 0.42 0.52 rg 62 692 Td (AKTENZEICHEN) Tj ET`);
  op.push(`BT /F2 18 Tf 0.039 0.137 0.278 rg 62 669 Td (${esc(ref)}) Tj ET`);
  op.push(`BT /F1 8 Tf 0.35 0.42 0.52 rg ${W - 210} 692 Td (AUSGESTELLT AM) Tj ET`);
  op.push(`BT /F2 11 Tf 0.039 0.137 0.278 rg ${W - 210} 671 Td (${esc(formatDate(issued))}) Tj ET`);

  // Datenblock
  let y = 615;
  op.push(`BT /F2 13 Tf 0.039 0.137 0.278 rg 48 ${y} Td (Angaben zur Person) Tj ET`);
  op.push(`0.82 0.86 0.92 RG 1 w 48 ${y - 8} ${W - 96} 0.8 re S`);
  y -= 30;

  const rows = [
    ['Name', name],
    ['Geburtsdatum', birth],
    ['Geburtsort', birthplace],
    ['Anschrift', address],
    ['E-Mail', email],
    ['Art des Zeugnisses', type],
  ];

  rows.forEach(([label, value]) => {
    op.push(`BT /F1 8 Tf 0.42 0.49 0.59 rg 48 ${y} Td (${esc(label.toUpperCase())}) Tj ET`);
    op.push(`BT /F1 12 Tf 0.09 0.13 0.19 rg 48 ${y - 15} Td (${esc(value)}) Tj ET`);
    y -= 38;
  });

  // Bescheinigungstext
  y -= 6;
  op.push(`BT /F2 12 Tf 0.039 0.137 0.278 rg 48 ${y} Td (Bescheinigung) Tj ET`);
  y -= 20;
  const text = [
    'Hiermit wird bescheinigt, dass im Bundeszentralregister keine Eintragung',
    'ueber die in diesem Dokument genannte Person vorhanden ist.',
    '',
    'Die Bescheinigung wird für den angegebenen Verwendungszweck erteilt.',
  ];
  text.forEach((line) => {
    if (line) op.push(`BT /F1 10.5 Tf 0.18 0.22 0.29 rg 48 ${y} Td (${esc(line)}) Tj ET`);
    y -= 17;
  });

  // Stempel
  y -= 26;
  op.push(`0.902 0.965 0.925 rg 48 ${y - 46} 300 56 re f`);
  op.push(`0.29 0.61 0.4 RG 2 w 48 ${y - 46} 300 56 re S`);
  op.push(`BT /F2 14 Tf 0.09 0.42 0.25 rg 66 ${y - 28} Td (KEINE EINTRAGUNG) Tj ET`);
  op.push(`BT /F1 8 Tf 0.16 0.42 0.28 rg 66 ${y - 40} Td (Bundeszentralregister - Auszug) Tj ET`);

  // Gültigkeit
  op.push(`BT /F1 8.5 Tf 0.42 0.49 0.59 rg ${W - 210} ${y - 20} Td (GUELTIG BIS) Tj ET`);
  op.push(`BT /F2 11 Tf 0.09 0.13 0.19 rg ${W - 210} ${y - 34} Td (${esc(formatDate(validUntil))}) Tj ET`);

  // Fußzeile
  op.push(`0.82 0.86 0.92 RG 1 w 48 92 ${W - 96} 0.8 re S`);
  op.push(`BT /F1 7.5 Tf 0.45 0.52 0.62 rg 48 76 Td (Dieses Dokument wurde maschinell erstellt und ist ohne Unterschrift gueltig.) Tj ET`);
  op.push(`BT /F1 7.5 Tf 0.45 0.52 0.62 rg 48 64 Td (Landespolizei Thueringen - Roleplay-Projekt, keine offizielle Behoerde.) Tj ET`);
  op.push(`BT /F1 7.5 Tf 0.45 0.52 0.62 rg 48 52 Td (Dokument-ID: ${esc(ref)} - Digitale Bescheinigung, nicht zur Vorlage bei Behoerden geeignet.) Tj ET`);

  const content = op.join('\n');

  const objects = [];
  objects.push('<< /Type /Catalog /Pages 2 0 R >>');
  objects.push('<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>`);
  objects.push(`<< /Length ${Buffer.byteLength(content, 'latin1')} >>\nstream\n${content}\nendstream`);
  objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  objects.push(`<< /Title (${esc('Fuehrungszeugnis ' + ref)}) /Producer (LPT Intranet PDF Service) /CreationDate (D:${issued.toISOString().replace(/[-:T]/g, '').slice(0, 14)}) >>`);

  let pdf = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n';
  const offsets = [0];
  objects.forEach((obj, i) => {
    offsets.push(Buffer.byteLength(pdf, 'latin1'));
    pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
  });

  const xrefStart = Buffer.byteLength(pdf, 'latin1');
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i <= objects.length; i += 1) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info ${objects.length} 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`;

  return Buffer.from(pdf, 'latin1');
}

module.exports = { createCertificatePdf };
