const crypto = require('node:crypto');
const { query } = require('./db');

const CITIZEN_COOKIE = 'lpt_citizen';
const STATE_COOKIE = 'lpt_oauth_state';
const NEXT_COOKIE = 'lpt_oauth_next';
const SESSION_DAYS = Math.max(1, Number(process.env.CITIZEN_SESSION_DAYS || 30));

function parseCookies(req) {
  const header = req.headers.cookie || '';
  const cookies = {};
  header.split(';').forEach((part) => {
    const index = part.indexOf('=');
    if (index === -1) return;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (!key) return;
    try { cookies[key] = decodeURIComponent(value); } catch (e) { cookies[key] = value; }
  });
  return cookies;
}

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function requestIsSecure(req) {
  return process.env.COOKIE_SECURE === 'true' || Boolean(req && req.secure);
}

function sessionCookieOptions(req) {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: requestIsSecure(req),
    path: '/',
    maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000
  };
}

function safeNextPath(value, fallback = '/meine-tickets.html') {
  const next = String(value || '').trim();
  if (!next || !next.startsWith('/') || next.startsWith('//') || next.includes('\\')) return fallback;
  return next.slice(0, 500);
}

function discordConfigured() {
  return Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET);
}

function publicBaseUrl(req) {
  const configured = String(process.env.PUBLIC_BASE_URL || '').trim().replace(/\/$/, '');
  const hostname = String((req && req.hostname) || '');
  const isLocal = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]';
  if (configured && !isLocal) return configured;
  return `${req.protocol}://${req.get('host')}`;
}

function discordRedirectUri(req) {
  return process.env.DISCORD_REDIRECT_URI
    || `${publicBaseUrl(req)}/api/citizen/auth/discord/callback`;
}

function avatarUrl(discordId, avatar) {
  if (avatar) return `https://cdn.discordapp.com/avatars/${discordId}/${avatar}.png?size=128`;
  let index = 0;
  try { index = Number(BigInt(discordId) >> 22n) % 6; } catch (e) { index = 0; }
  return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
}

function mapCitizen(row) {
  return {
    id: row.id,
    discordId: row.discord_id,
    username: row.username,
    globalName: row.global_name,
    displayName: row.global_name || row.username,
    avatar: row.avatar,
    avatarUrl: avatarUrl(row.discord_id, row.avatar),
    email: row.email || null,
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at
  };
}

async function recordCitizenEvent(citizenId, event, detail, req) {
  try {
    await query(
      'INSERT INTO citizen_events (citizen_id, event, detail, ip, user_agent) VALUES (?,?,?,?,?)',
      [
        citizenId,
        event,
        detail == null ? null : JSON.stringify(detail),
        req ? String(req.headers['x-forwarded-for'] || req.ip || '').slice(0, 64) : null,
        req ? String(req.headers['user-agent'] || '').slice(0, 255) : null
      ]
    );
  } catch (e) { /* Logging darf den Hauptablauf nicht blockieren. */ }
}

async function loadCitizenFromRequest(req) {
  const cookies = parseCookies(req);
  const token = cookies[CITIZEN_COOKIE];
  if (!token) return null;
  const rows = await query(
    `SELECT c.* FROM citizen_sessions s
     JOIN citizen_accounts c ON c.id = s.citizen_id
     WHERE s.token_hash = ? AND s.expires_at > NOW() LIMIT 1`,
    [hashToken(token)]
  );
  return rows.length ? mapCitizen(rows[0]) : null;
}

async function optionalCitizen(req, res, next) {
  try {
    req.citizen = await loadCitizenFromRequest(req);
    next();
  } catch (err) {
    next(err);
  }
}

function requireCitizen(req, res, next) {
  if (!req.citizen) {
    return res.status(401).json({
      error: 'Bitte melden Sie sich mit Discord an.',
      requiresDiscord: true
    });
  }
  next();
}

async function createCitizenSession(citizenId, req, res) {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await query('DELETE FROM citizen_sessions WHERE expires_at <= NOW()');
  await query(
    'INSERT INTO citizen_sessions (token_hash, citizen_id, expires_at, ip, user_agent) VALUES (?,?,?,?,?)',
    [
      hashToken(token),
      citizenId,
      expiresAt,
      String(req.headers['x-forwarded-for'] || req.ip || '').slice(0, 64),
      String(req.headers['user-agent'] || '').slice(0, 255)
    ]
  );
  res.cookie(CITIZEN_COOKIE, token, sessionCookieOptions(req));
  return token;
}

function clearCitizenCookies(res) {
  res.clearCookie(CITIZEN_COOKIE, { path: '/' });
  res.clearCookie(STATE_COOKIE, { path: '/' });
  res.clearCookie(NEXT_COOKIE, { path: '/' });
}

module.exports = {
  CITIZEN_COOKIE,
  STATE_COOKIE,
  NEXT_COOKIE,
  parseCookies,
  hashToken,
  safeNextPath,
  discordConfigured,
  publicBaseUrl,
  requestIsSecure,
  discordRedirectUri,
  mapCitizen,
  recordCitizenEvent,
  loadCitizenFromRequest,
  optionalCitizen,
  requireCitizen,
  createCitizenSession,
  clearCitizenCookies
};
