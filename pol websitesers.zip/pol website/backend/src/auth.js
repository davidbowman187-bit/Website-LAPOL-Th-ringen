const jwt = require('jsonwebtoken');
const { query } = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const JWT_EXPIRES = process.env.JWT_EXPIRES || '12h';

async function loadUser(userId) {
  const rows = await query(
    `SELECT u.id, u.username, u.display_name, u.rank_id, u.active, r.name AS rank_name
     FROM users u JOIN ranks r ON r.id = u.rank_id WHERE u.id = ? LIMIT 1`,
    [userId]
  );
  if (!rows.length || !rows[0].active) return null;
  const user = rows[0];
  const perms = await query(
    'SELECT permission_key FROM rank_permissions WHERE rank_id = ?',
    [user.rank_id]
  );
  user.permissions = perms.map((p) => p.permission_key);
  return user;
}

function signToken(user) {
  return jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
}

async function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Nicht angemeldet.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await loadUser(payload.sub);
    if (!user) return res.status(401).json({ error: 'Benutzer nicht gefunden oder deaktiviert.' });
    req.user = {
      id: user.id,
      username: user.username,
      displayName: user.display_name,
      rankId: user.rank_id,
      rankName: user.rank_name,
      permissions: new Set(user.permissions)
    };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Ungültiges oder abgelaufenes Token.' });
  }
}

function requirePermission(...keys) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Nicht angemeldet.' });
    const ok = keys.every((key) => req.user.permissions.has(key));
    if (!ok) return res.status(403).json({ error: 'Keine Berechtigung für diese Aktion.' });
    next();
  };
}

function requireAnyPermission(...keys) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Nicht angemeldet.' });
    const ok = keys.some((key) => req.user.permissions.has(key));
    if (!ok) return res.status(403).json({ error: 'Keine Berechtigung für diese Aktion.' });
    next();
  };
}

module.exports = { authMiddleware, requirePermission, requireAnyPermission, signToken, loadUser, JWT_SECRET };