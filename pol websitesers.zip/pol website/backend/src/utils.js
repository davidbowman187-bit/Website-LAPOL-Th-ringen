function safeJson(value, fallback = null) {
  if (value == null) return fallback;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch (e) { return fallback; }
}

function toJson(value) {
  if (value == null) return null;
  if (typeof value === 'string') return value;
  return JSON.stringify(value);
}

function slugify(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 100) || 'eintrag';
}

function refPrefix(type) {
  const map = {
    report: 'ST',
    leading_certificate: 'FZ',
    career: 'BW',
    contact: 'KO',
    appointment: 'TR',
    hint: 'H'
  };
  return map[type] || 'VG';
}

function makeRef(type, id) {
  const year = new Date().getFullYear();
  return `${refPrefix(type)}/${year}/${String(id).padStart(6, '0')}`;
}

async function audit(connOrQuery, userId, action, entityType, entityId, details) {
  const runner = connOrQuery && typeof connOrQuery.execute === 'function' ? connOrQuery : null;
  // accept either a connection or the query module
  const q = runner ? (sql, params) => runner.execute(sql, params) : require('./db').query;
  try {
    await q('INSERT INTO audit_log (user_id, action, entity_type, entity_id, details) VALUES (?,?,?,?,?)',
      [userId || null, action, entityType || null, entityId != null ? String(entityId) : null, toJson(details)]);
  } catch (e) { /* audit must never break main flow */ }
}

module.exports = { safeJson, toJson, slugify, refPrefix, makeRef, audit };