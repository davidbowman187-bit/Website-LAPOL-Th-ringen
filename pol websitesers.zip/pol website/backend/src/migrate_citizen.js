async function ensureColumn(query, table, column, definition) {
  const rows = await query(
    `SELECT COUNT(*) AS count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column]
  );
  if (!rows[0] || !rows[0].count) {
    await query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
  }
}

async function ensureIndex(query, table, indexName, columnList) {
  const rows = await query(
    `SELECT COUNT(*) AS count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`,
    [table, indexName]
  );
  if (!rows[0] || !rows[0].count) {
    await query(`CREATE INDEX \`${indexName}\` ON \`${table}\` (${columnList})`);
  }
}

async function migrateCitizen(query) {
  await query(`CREATE TABLE IF NOT EXISTS citizen_accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    discord_id VARCHAR(32) NOT NULL UNIQUE,
    username VARCHAR(100) NOT NULL,
    global_name VARCHAR(150) NULL,
    avatar VARCHAR(190) NULL,
    email VARCHAR(190) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS citizen_sessions (
    token_hash CHAR(64) PRIMARY KEY,
    citizen_id INT NOT NULL,
    expires_at DATETIME NOT NULL,
    ip VARCHAR(64) NULL,
    user_agent VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_citizen_sessions_expires (expires_at),
    INDEX idx_citizen_sessions_citizen (citizen_id),
    FOREIGN KEY (citizen_id) REFERENCES citizen_accounts(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await query(`CREATE TABLE IF NOT EXISTS citizen_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    citizen_id INT NOT NULL,
    event VARCHAR(60) NOT NULL,
    detail TEXT NULL,
    ip VARCHAR(64) NULL,
    user_agent VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_citizen_events_citizen (citizen_id, created_at),
    FOREIGN KEY (citizen_id) REFERENCES citizen_accounts(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await ensureColumn(query, 'applications', 'citizen_id', 'INT NULL');
  await ensureIndex(query, 'applications', 'idx_applications_citizen', '`citizen_id`');
  await ensureColumn(query, 'ticket_messages', 'citizen_id', 'INT NULL');
  await ensureIndex(query, 'ticket_messages', 'idx_ticket_messages_citizen', '`citizen_id`');
}

module.exports = { migrateCitizen };
