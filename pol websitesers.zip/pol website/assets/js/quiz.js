/* Schnupper-Einstellungstest – wird auf Startseite und Karriereseite genutzt */
(function () {
  'use strict';
  const body = document.getElementById('quizBody');
  if (!body) return;
  const app = window.LPTApp;
  const questions = app.quiz;
  if (!questions.length) return;

  let index = 0;
  let answers = [];

  function progressMarkup() {
    return `<div class="quiz-progress-label"><span>Frage ${index + 1} von ${questions.length}</span><span>${questions[index].category}</span></div>
      <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${questions.length}" aria-valuenow="${index + 1}" aria-label="Fortschritt">
        <div style="width:${((index + 1) / questions.length) * 100}%"></div>
      </div>`;
  }

  function ask() {
    const q = questions[index];
    body.innerHTML = `${progressMarkup()}
      <form id="quizForm" novalidate>
        <p class="quiz-question">${app.escapeHTML(q.question)}</p>
        <div class="quiz-options">
          ${q.options.map((option, i) => `
            <label class="quiz-option">
              <input type="radio" name="quizOption" value="${i}" ${answers[index] === i ? 'checked' : ''} required>
              <span>${app.escapeHTML(option)}</span>
            </label>`).join('')}
        </div>
        <div class="quiz-actions">
          <span style="color:var(--muted);font-size:12px">Wähle eine Antwort</span>
          <button type="submit" class="btn btn-navy btn-sm">${index === questions.length - 1 ? 'Auswerten' : 'Weiter'}</button>
        </div>
      </form>`;

    const form = document.getElementById('quizForm');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const selected = form.querySelector('input[name="quizOption"]:checked');
      if (!selected) {
        app.toast('Bitte wähle zuerst eine Antwort aus.', { type: 'error' });
        return;
      }
      answers[index] = Number(selected.value);
      if (index < questions.length - 1) {
        index += 1;
        ask();
      } else {
        result();
      }
    });
  }

  function result() {
    const score = answers.filter((answer, i) => answer === questions[i].answer).length;
    const verdict = score >= 5
      ? 'Sehr gut! Du bringst eine starke Basis für das Auswahlverfahren mit.'
      : score >= 3
        ? 'Solide Basis – mit etwas Übung wirst du sicherer.'
        : 'Da ist noch Luft nach oben. Üben lohnt sich – und der echte Test ist deutlich umfangreicher.';

    body.innerHTML = `
      <div class="quiz-head"><h3>Dein Ergebnis</h3><span class="badge badge-gold">Schnuppertest</span></div>
      <p class="quiz-result-score">${score} <small>/ ${questions.length}</small></p>
      <p style="margin:0 0 8px;font-weight:600;color:var(--navy)">${verdict}</p>
      <div style="max-height:300px;overflow-y:auto;padding-right:4px">
        ${questions.map((q, i) => {
          const ok = answers[i] === q.answer;
          return `<div class="quiz-answer ${ok ? 'ok' : 'no'}">
            <strong>${ok ? 'Richtig' : 'Falsch'} · ${app.escapeHTML(q.category)}</strong><br>
            ${app.escapeHTML(q.options[q.answer])} – ${app.escapeHTML(q.explanation)}
          </div>`;
        }).join('')}
      </div>
      <div class="quiz-tips"><strong>Tipps für die echte Bewerbung</strong>
        <ul>
          <li>Übe Zahlenreihen und Textaufgaben unter Zeitdruck.</li>
          <li>Lies täglich Nachrichten für dein Allgemeinwissen.</li>
          <li>Trainiere regelmäßig Ausdauer – der Sporttest gehört dazu.</li>
        </ul>
      </div>
      <div class="quiz-actions">
        <a class="text-link" href="karriere.html">Mehr zur Karriere ${app.ICON('arrow-right')}</a>
        <button type="button" class="btn btn-navy btn-sm" id="quizRestart">Test wiederholen</button>
      </div>`;

    document.getElementById('quizRestart').addEventListener('click', () => {
      index = 0;
      answers = [];
      ask();
    });
  }

  ask();
})();
