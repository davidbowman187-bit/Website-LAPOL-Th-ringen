/* ==========================================================================
   Landespolizei Thüringen · Roleplay Erfurt
   Zentrale Inhaltsdaten (fiktiv)
   ========================================================================== */
window.LPT = {
  news: [
    {
      id: 1,
      slug: 'falsche-polizisten-erfurt',
      category: 'warnung',
      label: 'Warnung',
      date: '2026-11-03',
      title: 'Falsche Polizeibeamte rufen Seniorinnen und Senioren in Erfurt an',
      teaser: 'Die Polizei fordert am Telefon niemals Geld, Schmuck oder Wertsachen. Auflegen und 110 wählen.',
      location: 'Erfurt',
      reading: 3,
      featured: true,
      icon: 'alert',
      body: [
        '<p>Im Stadtgebiet Erfurt häufen sich seit dem Wochenende Anrufe von Betrügerinnen und Betrügern, die sich als Polizeibeamte ausgeben. Die Anrufe erreichen überwiegend Seniorinnen und Senioren. Die Täter berichten von angeblichen Einbrüchen in der Nachbarschaft und behaupten, das Vermögen der Angerufenen sei in Gefahr.</p>',
        '<p>Anschließend fordern sie dazu auf, Geld, Schmuck oder andere Wertsachen zur „sicheren Aufbewahrung“ an einen angeblichen Zivilfahnder zu übergeben. In einigen Fällen wird Druck aufgebaut, indem die Betroffenen aufgefordert werden, Stillschweigen zu bewahren.</p>',
        '<p><strong>Wichtig:</strong> Die Polizei ruft niemals mit unterdrückter Nummer an, um Wertsachen abzuholen. Sie verlangt keine Kautionen, keine Überweisungen und keine Übergabe von Geld an der Haustür. Wer einen solchen Anruf erhält, sollte auflegen und den Notruf 110 wählen.</p>',
        '<p>Angehörige werden gebeten, ältere Menschen im persönlichen Gespräch für die Masche zu sensibilisieren. Weitere Informationen finden Sie auf unserer Präventionsseite.</p>'
      ]
    },
    {
      id: 2,
      slug: 'einbruch-gartenanlage-erfurt-nord',
      category: 'fahndung',
      label: 'Fahndung',
      date: '2026-11-02',
      title: 'Zeugen gesucht: Einbruch in Gartenanlage Erfurt-Nord',
      teaser: 'Unbekannte drangen in der Nacht in mehrere Parzellen ein und entwendeten Werkzeuge sowie Elektronik.',
      location: 'Erfurt-Nord',
      reading: 2,
      featured: false,
      icon: 'search',
      body: [
        '<p>In der Nacht zum 2. November sind Unbekannte in mehrere Parzellen einer Gartenanlage nahe der Stotternheimer Straße eingedrungen. Nach ersten Erkenntnissen wurden Gartenhäuser aufgebrochen und Werkzeuge, ein Akkuschrauber sowie ein tragbares Radio entwendet.</p>',
        '<p>Die Polizeiinspektion Erfurt ermittelt wegen besonders schweren Falls des Diebstahls. Wer in der Nacht verdächtige Personen, Fahrzeuge oder Geräusche im Bereich der Anlage beobachtet hat, wird gebeten, sich zu melden.</p>',
        '<p>Sachdienliche Hinweise nimmt die Polizeiinspektion Erfurt über die Onlinewache entgegen.</p>'
      ]
    },
    {
      id: 3,
      slug: 'verkehrskontrollen-domplatz-bilanz',
      category: 'presse',
      label: 'Presse',
      date: '2026-11-01',
      title: 'Verkehrskontrollen am Domplatz: Bilanz des Wochenendes',
      teaser: 'Schwerpunkte waren Geschwindigkeit, Handynutzung am Steuer und die Sicherung von Kindern.',
      location: 'Erfurt',
      reading: 2,
      featured: false,
      icon: 'car',
      body: [
        '<p>Am vergangenen Wochenende hat die Landespolizei Thüringen im Bereich Domplatz und Anger Schwerpunktkontrollen durchgeführt. Insgesamt wurden 142 Fahrzeuge überprüft.</p>',
        '<p>Zwölf Fahrzeugführende wurden wegen der Nutzung eines Mobiltelefons während der Fahrt verwarnt. In neun Fällen wurde die Geschwindigkeit überschritten, in vier Fahrzeugen waren Kinder nicht ausreichend gesichert.</p>',
        '<p>Die Kontrollen werden auch in den kommenden Wochen fortgesetzt. Ziel ist es, die Zahl der Ablenkungsunfälle zu senken und die Sicherheit besonders gefährdeter Verkehrsteilnehmender zu erhöhen.</p>'
      ]
    },
    {
      id: 4,
      slug: 'glaettegefahr-a71',
      category: 'verkehr',
      label: 'Verkehr',
      date: '2026-10-31',
      title: 'Glättegefahr auf der A71 zwischen Erfurt und Ilmenau',
      teaser: 'Auf Brückenbauwerken kann es zu spontaner Glatteisbildung kommen. Bitte passen Sie die Geschwindigkeit an.',
      location: 'A71 / Ilmenau',
      reading: 1,
      featured: false,
      icon: 'alert',
      body: [
        '<p>Aufgrund sinkender Temperaturen kann es auf den Brückenbauwerken der A71 zwischen Erfurt und Ilmenau kurzfristig zu Glatteisbildung kommen. Besonders in den frühen Morgenstunden ist mit glatten Fahrbahnabschnitten zu rechnen.</p>',
        '<p>Die Polizei rät zu angepasster Geschwindigkeit, ausreichendem Abstand und einer defensiven Fahrweise. Winterreifen sind bei den aktuellen Witterungsverhältnissen dringend empfohlen.</p>',
        '<p>Aktuelle Verkehrswarnungen werden über die Verkehrsleitzentrale veröffentlicht. Im Notfall wählen Sie bitte die 110.</p>'
      ]
    },
    {
      id: 5,
      slug: 'tag-der-offenen-tuer-erfurt',
      category: 'presse',
      label: 'Presse',
      date: '2026-10-30',
      title: 'Tag der offenen Tür: 2.000 Gäste besuchen das Polizeirevier Erfurt',
      teaser: 'Fahrzeuge, Diensthundestaffel und Beratung zur Einbruchsprävention begeisterten große und kleine Gäste.',
      location: 'Erfurt',
      reading: 2,
      featured: false,
      icon: 'users',
      body: [
        '<p>Rund 2.000 Besucherinnen und Besucher haben am vergangenen Samstag den Tag der offenen Tür im Polizeirevier Erfurt genutzt. Geboten wurden Einblicke in die Arbeit von Schutzpolizei, Kriminalpolizei und Verkehrspolizei.</p>',
        '<p>Besonders gefragt waren die Vorführungen der Diensthundestaffel und die Fahrzeugschau. An mehreren Ständen informierten Präventionsfachkräfte über Einbruchschutz, Cybercrime und Sicherheit im Alter.</p>',
        '<p>Die Landespolizei Thüringen bedankt sich bei allen Gästen für das große Interesse und die vielen guten Gespräche.</p>'
      ]
    },
    {
      id: 6,
      slug: 'vermisster-15-jaehriger-erfurt',
      category: 'fahndung',
      label: 'Fahndung',
      date: '2026-10-29',
      title: 'Vermisst: 15-Jähriger aus Erfurt-Süd',
      teaser: 'Der Jugendliche wurde zuletzt am Hauptbahnhof gesehen. Die Polizei bittet um Hinweise.',
      location: 'Erfurt-Süd',
      reading: 2,
      featured: false,
      icon: 'user',
      body: [
        '<p>Seit dem 28. Oktober wird der 15-jährige Linus M. aus Erfurt-Süd vermisst. Er wurde zuletzt gegen 18 Uhr am Hauptbahnhof gesehen.</p>',
        '<p>Der Jugendliche ist etwa 1,75 Meter groß, schlank und trägt eine schwarze Jacke sowie blaue Jeans. Er führt einen grauen Rucksack mit sich. Hinweise auf eine Straftat liegen derzeit nicht vor.</p>',
        '<p>Wer den Jugendlichen gesehen hat oder Angaben zu seinem Aufenthaltsort machen kann, wird gebeten, sich bei jeder Polizeidienststelle oder über die Onlinewache zu melden. Bitte nehmen Sie ihn nicht selbst mit, sondern verständigen Sie die Polizei.</p>'
      ]
    },
    {
      id: 7,
      slug: 'enkeltrick-praevention',
      category: 'warnung',
      label: 'Warnung',
      date: '2026-10-28',
      title: 'Enkeltrick: So schützen Sie sich und Ihre Angehörigen',
      teaser: 'Unbekannte geben sich als Verwandte aus und bitten um Geld. Die Polizei gibt konkrete Tipps.',
      location: 'Thüringen',
      reading: 3,
      featured: false,
      icon: 'shield',
      body: [
        '<p>Beim sogenannten Enkeltrick geben sich Betrüger am Telefon als nahe Angehörige aus. Sie erfinden eine Notlage – etwa einen Unfall oder einen dringenden Immobilienkauf – und bitten um eine schnelle Geldüberweisung.</p>',
        '<p>Die Polizei empfiehlt: Lassen Sie sich den Namen nennen und rufen Sie die Person unter der Ihnen bekannten Nummer zurück. Geben Sie niemals Geld oder Wertsachen an fremde Personen heraus. Ziehen Sie eine Vertrauensperson hinzu.</p>',
        '<p>Wenn Sie Opfer eines Betrugsversuchs geworden sind, erstatten Sie Anzeige – über die Onlinewache oder bei jeder Polizeidienststelle. Je schneller die Informationen vorliegen, desto größer sind die Chancen, Täter zu ermitteln.</p>'
      ]
    },
    {
      id: 8,
      slug: 'praeventionsstelle-cybercrime',
      category: 'presse',
      label: 'Presse',
      date: '2026-10-27',
      title: 'Neue Präventionsstelle für Cybercrime eröffnet',
      teaser: 'Beratung zu Phishing, Onlinebetrug und sicheren Passwörtern – kostenlos und ohne Termin.',
      location: 'Erfurt',
      reading: 2,
      featured: false,
      icon: 'wifi',
      body: [
        '<p>Die Landespolizei Thüringen hat ihre Beratungsangebote zum Thema Cybercrime ausgebaut. In der neuen Präventionsstelle in der Erfurter Innenstadt erhalten Bürgerinnen und Bürger kostenlose Unterstützung.</p>',
        '<p>Im Mittelpunkt stehen Fragen zu Phishing-E-Mails, betrügerischen Online-Shops, Schadsoftware und dem sicheren Umgang mit Passwörtern. Die Beratung ist kostenlos und kann ohne Termin besucht werden.</p>',
        '<p>Weitere Informationen sowie die Öffnungszeiten finden Sie auf der Seite Prävention und im Dienststellenverzeichnis.</p>'
      ]
    },
    {
      id: 9,
      slug: 'onlinewache-digitaler-vorgangsstatus',
      category: 'service',
      label: 'Service',
      date: '2026-10-25',
      title: 'Onlinewache jetzt mit digitalem Vorgangsstatus',
      teaser: 'Nach der Anzeige erhalten Sie ein Aktenzeichen und können den Bearbeitungsstand online verfolgen.',
      location: 'Thüringen',
      reading: 2,
      featured: false,
      icon: 'message',
      body: [
        '<p>Die Onlinewache der Landespolizei Thüringen wurde erweitert. Nach dem Absenden einer Anzeige erhalten Nutzerinnen und Nutzer ein persönliches Aktenzeichen.</p>',
        '<p>Mit diesem Aktenzeichen und dem Geburtsdatum der anzeigenden Person kann der Bearbeitungsstand online abgefragt werden. Die Anzeige wird an die zuständige Dienststelle weitergeleitet und dort geprüft.</p>',
        '<p>Die Onlinewache ersetzt keinen Notruf. Bei akuter Gefahr, einem laufenden Täterkontakt oder Verletzten wählen Sie bitte sofort die 110.</p>'
      ]
    },
    {
      id: 10,
      slug: 'bewerbungsphase-2027',
      category: 'karriere',
      label: 'Karriere',
      date: '2026-10-23',
      title: 'Bewerbungsphase für Ausbildung und Sachbearbeitung 2027 gestartet',
      teaser: 'Sichern Sie sich einen von 120 Ausbildungsplätzen oder bewerben Sie sich für die Sachbearbeitung.',
      location: 'Erfurt',
      reading: 2,
      featured: false,
      icon: 'cap',
      body: [
        '<p>Die Landespolizei Thüringen startet die Bewerbungsphase für die Ausbildung im mittleren Polizeivollzugsdienst und für die Sachbearbeitung 2027. Insgesamt stehen 120 Ausbildungsplätze zur Verfügung.</p>',
        '<p>Für die Ausbildung im mittleren Dienst wird die mittlere Reife oder ein vergleichbarer Abschluss vorausgesetzt. Für die Sachbearbeitung sind eine Hochschulzugangsberechtigung oder eine verwaltungsnahe Ausbildung möglich.</p>',
        '<p>Die Ausbildung beginnt am 1. September 2027. Während der Ausbildung besteht Anspruch auf eine Vergütung. Alle Informationen zum Auswahlverfahren finden Sie auf der Karriereseite.</p>'
      ]
    }
  ],

  fahndungen: [
    {
      id: 1,
      caseNo: 'F-2026-114',
      category: 'person',
      label: 'Personenfahndung',
      date: '2026-10-29',
      title: 'Vermisster 15-Jähriger aus Erfurt-Süd',
      location: 'Erfurt-Süd / Hauptbahnhof',
      teaser: 'Linus M. wird seit dem 28. Oktober vermisst. Zuletzt wurde er am Hauptbahnhof gesehen.',
      description: 'Der 15-jährige Linus M. ist seit dem Abend des 28. Oktober unbekannt verzogen. Es gibt keine Hinweise auf eine Straftat. Die Polizei bittet um Hinweise zum Aufenthaltsort.',
      facts: [
        ['Größe', 'ca. 1,75 m'],
        ['Alter', '15 Jahre'],
        ['Bekleidung', 'schwarze Jacke, blaue Jeans'],
        ['Besonderheit', 'grauer Rucksack']
      ],
      hint: 'Bitte sprechen Sie den Jugendlichen nicht an, sondern verständigen Sie die Polizei.',
      icon: 'user'
    },
    {
      id: 2,
      caseNo: 'F-2026-112',
      category: 'sache',
      label: 'Sachfahndung',
      date: '2026-11-02',
      title: 'Einbruch in Juweliergeschäft in der Erfurter Altstadt',
      location: 'Erfurt, Altstadt',
      teaser: 'In der Nacht zum 2. November wurde in ein Juweliergeschäft eingebrochen. Zeugen werden gesucht.',
      description: 'Unbekannte verschafften sich gewaltsam Zugang zu einem Juweliergeschäft in der Erfurter Altstadt und entwendeten Schmuck im Wert von mehreren tausend Euro. Die Polizei sucht Zeugen, die in der Nacht Fahrzeuge oder Personen beobachtet haben.',
      facts: [
        ['Tatzeit', '01.11., 23:00 – 02.11., 05:30'],
        ['Tatort', 'Erfurt, Altstadt'],
        ['Sachschaden', 'ca. 25.000 Euro'],
        ['Zeugenaufruf', 'ja']
      ],
      hint: 'Bitte betreten Sie keine Tatorte und verändern Sie keine Spuren.',
      icon: 'camera'
    },
    {
      id: 3,
      caseNo: 'F-2026-109',
      category: 'zeugen',
      label: 'Zeugensuche',
      date: '2026-10-30',
      title: 'Unbekannter beschädigt mehrere Fahrzeuge am Bahnhof Erfurt',
      location: 'Erfurt, Hauptbahnhof',
      teaser: 'In der Nacht zum 30. Oktober wurden mehrere geparkte Autos beschädigt. Wer hat etwas gesehen?',
      description: 'Im Bereich der Parkplätze am Erfurter Hauptbahnhof wurden in der Nacht mehrere Fahrzeuge beschädigt. Ein bislang unbekannter Mann wurde gegen 2:30 Uhr in der Nähe gesehen. Die Polizei sucht Zeugen und mögliche weitere Geschädigte.',
      facts: [
        ['Tatzeit', '30.10., ca. 02:30 Uhr'],
        ['Tatort', 'Erfurt, Hauptbahnhof'],
        ['Fahrzeuge', 'mindestens 6'],
        ['Person', 'männlich, dunkle Kleidung']
      ],
      hint: 'Hinweise bitte an die Polizeiinspektion Erfurt-Zentrum.',
      icon: 'eye'
    },
    {
      id: 4,
      caseNo: 'F-2026-107',
      category: 'sache',
      label: 'Sachfahndung',
      date: '2026-11-02',
      title: 'Diebstahl aus Gartenanlage Erfurt-Nord',
      location: 'Erfurt-Nord, Stotternheimer Straße',
      teaser: 'Werkzeuge und Elektronikgeräte aus mehreren Gartenhäusern entwendet.',
      description: 'In der Nacht zum 2. November brachen Unbekannte in mehrere Gartenhäuser ein. Entwendet wurden unter anderem Akkugeräte, Werkzeugkoffer und ein tragbares Radio. Die Polizei prüft Zusammenhänge mit weiteren Einbrüchen in der Region.',
      facts: [
        ['Tatzeit', '01.11. – 02.11.2026'],
        ['Tatort', 'Erfurt-Nord'],
        ['Beute', 'Werkzeug, Elektronik'],
        ['Sachschaden', 'ca. 4.000 Euro']
      ],
      hint: 'Achten Sie auf den Weiterverkauf auffälliger Werkzeuge oder Akkugeräte.',
      icon: 'camera'
    },
    {
      id: 5,
      caseNo: 'F-2026-103',
      category: 'zeugen',
      label: 'Zeugensuche',
      date: '2026-10-26',
      title: 'Körperverletzung am Anger: Wer kennt die Hintergründe?',
      location: 'Erfurt, Anger',
      teaser: 'Am 25. Oktober kam es zu einer Auseinandersetzung. Die Polizei sucht Zeugen.',
      description: 'Am späten Abend des 25. Oktober kam es am Erfurter Anger zu einer körperlichen Auseinandersetzung zwischen mehreren Personen. Ein 24-Jähriger wurde leicht verletzt. Die Hintergründe sind bislang unklar.',
      facts: [
        ['Tatzeit', '25.10., ca. 22:15 Uhr'],
        ['Tatort', 'Erfurt, Anger'],
        ['Verletzte', '1 Person'],
        ['Zeugen', 'mehrere Passanten']
      ],
      hint: 'Bitte melden Sie sich auch dann, wenn Sie nur Beobachtungen gemacht haben.',
      icon: 'eye'
    },
    {
      id: 6,
      caseNo: 'F-2026-098',
      category: 'sache',
      label: 'Sachfahndung',
      date: '2026-10-22',
      title: 'Hochwertiges E-Bike am Domplatz entwendet',
      location: 'Erfurt, Domplatz',
      teaser: 'Ein schwarzes E-Bike der Marke Cube wurde am 21. Oktober entwendet.',
      description: 'Vom Domplatz wurde ein schwarzes E-Bike der Marke Cube entwendet. Das Fahrrad hat auffällige goldene Felgenaufkleber und einen Gepäckträger. Die Polizei bittet um Hinweise zum Verbleib.',
      facts: [
        ['Tatzeit', '21.10., 16:00 – 18:30 Uhr'],
        ['Tatort', 'Erfurt, Domplatz'],
        ['Fahrrad', 'Cube, schwarz/gold'],
        ['Rahmennummer', 'CUBE-2026-4471']
      ],
      hint: 'Bitte prüfen Sie auch Angebote auf Online-Marktplätzen.',
      icon: 'camera'
    }
  ],

  stations: [
    {
      id: 'erfurt-zentrum',
      name: 'Polizeiinspektion Erfurt',
      city: 'Erfurt',
      region: 'Erfurt',
      address: 'Andreasstraße 36, 99084 Erfurt',
      hours: '24 Stunden täglich',
      services: ['Anzeige', 'Beratung', 'Termine', 'Prävention'],
      x: 47,
      y: 49
    }
  ],

  pages: [
    { title: 'Onlinewache', category: 'Service', url: 'onlinewache.html', desc: 'Strafanzeige oder Hinweis online erstatten', keywords: 'anzeige strafanzeige hinweis online wache diebstahl betrug discord', icon: 'message' },
    { title: 'Meine Tickets', category: 'Service', url: 'meine-tickets.html', desc: 'Eigene Tickets einsehen und mit der Dienststelle chatten', keywords: 'tickets konto discord chat verlauf aktenzeichen', icon: 'message' },
    { title: 'Führungszeugnis beantragen', category: 'Service', url: 'service.html#fuehrungszeugnis', desc: 'Privat, behördlich oder erweitert – online beantragen', keywords: 'führungszeugnis polizeiliches dokument beantragen', icon: 'file' },
    { title: 'Vorgangsstatus prüfen', category: 'Service', url: 'service.html#status', desc: 'Bearbeitungsstand mit Aktenzeichen abfragen', keywords: 'status aktenzeichen vorgang bearbeitung', icon: 'search' },
    { title: 'Dienststelle & Kontakt', category: 'Service', url: 'kontakt.html', desc: 'Polizeiinspektion Erfurt mit Adresse und Kontakt', keywords: 'dienststelle revier kontakt adresse erfurt', icon: 'map-pin' },
    { title: 'Formulare & Anträge', category: 'Service', url: 'service.html#formulare', desc: 'Services von A bis Z', keywords: 'formular antrag waffenrecht veranstaltung fundsache', icon: 'clipboard' },
    { title: 'Fahndungen', category: 'Fahndung', url: 'fahndung.html', desc: 'Aktuelle Personenfahndungen und Zeugensuche', keywords: 'fahndung vermisst zeugen gesucht person sache', icon: 'search' },
    { title: 'Presse & Meldungen', category: 'Presse', url: 'presse.html', desc: 'Warnungen, Presseinformationen und Verkehrsmeldungen', keywords: 'presse meldung nachricht warnung verkehr', icon: 'file' },
    { title: 'Prävention', category: 'Prävention', url: 'praevention.html', desc: 'Einbruchschutz, Cybercrime, Senioren und Verkehr', keywords: 'prävention schutz einbruch cybercrime senioren sicherheit', icon: 'shield' },
    { title: 'Karriere & Bewerbung', category: 'Karriere', url: 'karriere.html', desc: 'Ausbildung mittlerer Dienst, Sachbearbeitung und Einstellungstest', keywords: 'karriere bewerbung ausbildung sachbearbeiter polizei job einstellungstest', icon: 'cap' },
    { title: 'Profil & Auftrag', category: 'Über uns', url: 'ueber-uns.html', desc: 'Wer wir sind und wofür wir stehen', keywords: 'über uns profil auftrag werte geschichte', icon: 'shield' },
    { title: 'Organisation', category: 'Über uns', url: 'ueber-uns.html#organisation', desc: 'Aufbau und Gliederung der Landespolizei', keywords: 'organisation direktion präsidium aufbau', icon: 'building' },
    { title: 'KART', category: 'Über uns', url: 'ueber-uns.html#kart', desc: 'Koordinierte Analyse- und Regionalteams', keywords: 'kart analyse regionalteam ermittlung', icon: 'activity' },
    { title: 'Intranet', category: 'Intern', url: 'intranet.html', desc: 'Interner Bereich für Bedienstete mit Tickets und Akten', keywords: 'intranet dienstplan intern bedienstete tickets akten', icon: 'lock' },
    { title: 'Leichte Sprache', category: 'Barrierefreiheit', url: 'leichte-sprache.html', desc: 'Informationen in einfacher Sprache', keywords: 'leichte sprache einfach barrierefrei', icon: 'headphones' },
    { title: 'Erklärung zur Barrierefreiheit', category: 'Barrierefreiheit', url: 'barrierefreiheit.html', desc: 'Stand der Barrierefreiheit dieser Website', keywords: 'barrierefreiheit wcag zugänglich', icon: 'eye' },
    { title: 'Impressum', category: 'Rechtliches', url: 'impressum.html', desc: 'Anbieterkennzeichnung des Roleplay-Projekts', keywords: 'impressum anbieter kontakt', icon: 'info' },
    { title: 'Datenschutz', category: 'Rechtliches', url: 'datenschutz.html', desc: 'Informationen zum Datenschutz', keywords: 'datenschutz daten privatsphäre', icon: 'lock' }
  ],

  quiz: [
    {
      category: 'Deutsch',
      question: 'Welches Wort passt? „Der Zeuge sagte aus, ___ er den Täter erkannt habe.“',
      options: ['das', 'dass', 'daß', 'dasz'],
      answer: 1,
      explanation: 'Die Konjunktion „dass“ leitet einen Nebensatz ein.'
    },
    {
      category: 'Rechtschreibung',
      question: 'Welches Wort ist richtig geschrieben?',
      options: ['Ordnungswiedrigkeit', 'Ordnungswidrichkeit', 'Ordnungswidrigkeit', 'Ordnungswidriegkeit'],
      answer: 2,
      explanation: 'Abgeleitet von „widrig“: Ordnungswidrigkeit.'
    },
    {
      category: 'Logisches Denken',
      question: 'Setzen Sie die Reihe fort: 3 – 6 – 12 – 24 – ?',
      options: ['36', '42', '48', '30'],
      answer: 2,
      explanation: 'Jede Zahl wird verdoppelt: 24 × 2 = 48.'
    },
    {
      category: 'Logisches Denken',
      question: 'Setzen Sie die Reihe fort: 2 – 5 – 10 – 17 – 26 – ?',
      options: ['35', '37', '36', '38'],
      answer: 1,
      explanation: 'Die Abstände wachsen um 2 (3, 5, 7, 9, 11): 26 + 11 = 37.'
    },
    {
      category: 'Staatskunde',
      question: 'Wer wählt in Deutschland die Bundeskanzlerin oder den Bundeskanzler?',
      options: ['Das Volk direkt', 'Der Bundestag', 'Die Bundesversammlung', 'Der Bundesrat'],
      answer: 1,
      explanation: 'Der Bundestag wählt die Bundeskanzlerin oder den Bundeskanzler. Die Bundesversammlung wählt das Staatsoberhaupt.'
    },
    {
      category: 'Allgemeinwissen',
      question: 'Welche Stadt ist die Landeshauptstadt von Thüringen?',
      options: ['Jena', 'Weimar', 'Erfurt', 'Gera'],
      answer: 2,
      explanation: 'Erfurt ist die Landeshauptstadt und mit rund 215.000 Einwohnern die größte Stadt Thüringens.'
    }
  ]
};
