/* ==========================================================================
   Landespolizei Thüringen · Intranet 3.0
   Vollständige Intranet-Logik: Login, Übersicht, Vorgänge, Fahndungen,
   Meldungen, Asservaten, Dokumente (PDF), Benutzer und Ränge.
   ========================================================================== */
(function () {
  'use strict';

  const api = window.LPTApi;
  if (!api) return;

  /* ---------- Helpers ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (value) => String(value == null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  const icon = (name) => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  const dt = (value) => {
    if (!value) return '–';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '–';
    return d.toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };
  const day = (value) => {
    if (!value) return '–';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '–';
    return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };
  const bytes = (n) => {
    const v = Number(n || 0);
    if (v < 1024) return v + ' B';
    if (v < 1024 * 1024) return (v / 1024).toFixed(1) + ' KB';
    return (v / 1024 / 1024).toFixed(1) + ' MB';
  };

  function toast(message, opts = {}) {
    const stack = $('#toastStack');
    if (!stack) return;
    const type = opts.type === 'error' ? 'error' : '';
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML = `${icon(type === 'error' ? 'alert' : 'check-circle')}<div>${opts.title ? `<strong>${esc(opts.title)}</strong>` : ''}${esc(message)}</div>`;
    stack.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; }, 4200);
    setTimeout(() => el.remove(), 4600);
  }

  /* ---------- Theme: Dark / White ---------- */
  const THEME_KEY = 'lpt-intranet-theme';

  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'white' ? 'white' : 'dark';
  }

  function updateThemeButtons() {
    const isDark = currentTheme() === 'dark';
    const iconName = isDark ? 'sun' : 'moon';
    const label = isDark ? 'White Mode' : 'Dark Mode';
    const aria = isDark ? 'White Mode aktivieren' : 'Dark Mode aktivieren';
    ['themeToggle', 'themeToggleLogin'].forEach((id) => {
      const btn = document.getElementById(id);
      if (!btn) return;
      const use = btn.querySelector('use');
      if (use) use.setAttribute('href', '#i-' + iconName);
      btn.setAttribute('aria-label', aria);
      btn.setAttribute('title', aria);
      const span = btn.querySelector('span');
      if (span) span.textContent = label;
    });
  }

  function setTheme(theme, announce) {
    const next = theme === 'white' ? 'white' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* ignore */ }
    updateThemeButtons();
    if (announce) {
      toast(next === 'dark' ? 'Dark Mode aktiviert.' : 'White Mode aktiviert.', { title: 'Design gewechselt' });
    }
  }

  function toggleTheme() {
    setTheme(currentTheme() === 'dark' ? 'white' : 'dark', true);
  }

  ['themeToggle', 'themeToggleLogin'].forEach((id) => {
    const btn = document.getElementById(id);
    if (btn) btn.addEventListener('click', toggleTheme);
  });
  updateThemeButtons();

  /* ---------- State ---------- */
  const state = {
    user: null,
    view: 'overview',
    applications: [],
    tickets: [],
    archive: [],
    wanted: [],
    news: [],
    evidence: [],
    documents: [],
    users: [],
    ranks: [],
    permissions: [],
    citizens: [],
    vehicles: [],
    weapons: [],
    activity: [],
    laws: [],
    recruitment: [],
    hrApplications: [],
    hrSummary: null,
    trainings: [],
    trainingTests: [],
    leadershipSummary: null,
    leadershipNotes: [],
    filter: '',
    ticketPoll: null
  };

  const TYPE_LABEL = {
    leading_certificate: 'Führungszeugnis',
    strafanzeige: 'Strafanzeige',
    einsatzbericht: 'Einsatzbericht',
    report: 'Meldung / Bericht',
    career: 'Bewerbung',
    contact: 'Kontakt',
    appointment: 'Termin',
    hint: 'Hinweis',
    taetigkeitsbericht: 'Tätigkeitsbericht',
    module: 'Modul'
  };
  const STATUS = {
    eingegangen: ['badge-gold', 'Eingegangen'],
    in_pruefung: ['badge-blue', 'In Prüfung'],
    in_bearbeitung: ['badge-blue', 'In Bearbeitung'],
    abgeschlossen: ['badge-green', 'Abgeschlossen'],
    abgelehnt: ['badge-red', 'Abgelehnt']
  };
  const statusBadge = (value) => {
    const s = STATUS[value] || ['badge-gray', value || '–'];
    return `<span class="badge ${s[0]}">${esc(s[1])}</span>`;
  };

  const VIEW_META = {
    overview: ['Übersicht', 'Einsatzzentrale der Landespolizei Thüringen'],
    applications: ['Vorgänge', 'Anträge, Anzeigen und Bearbeitungsstände'],
    tickets: ['Tickets', 'Anzeigen, Hinweise und Kontaktanfragen bearbeiten'],
    archive: ['Archiv', 'Abgeschlossene und archivierte Tickets'],
    wanted: ['Fahndungen', 'Aktive und archivierte Fahndungen'],
    news: ['Meldungen', 'Presse- und Warnmeldungen verwalten'],
    evidence: ['Asservaten', 'Sichergestellte Gegenstände'],
    citizens: ['Bürgerregister', 'Personensuche in der ESX-Serverdatenbank'],
    vehicles: ['Fahrzeugregister', 'Fahrzeugabfrage aus der ESX-Serverdatenbank'],
    weapons: ['Waffenregister', 'Waffen und Lizenzen der Website-Datenbank'],
    activity: ['Tätigkeitsberichte', 'Dokumentation polizeilicher Tätigkeiten'],
    laws: ['Gesetzbuch', 'Gesetze, Paragraphen und Sanktionen'],
    recruitment: ['Bewerbung', 'Bewerbungsphasen öffnen und schließen'],
    hr: ['Bewerbungen', 'Bewerbungen der Personalabteilung'],
    training: ['Ausbildung', 'Ausbildungen, Unterlagen und Bewerbertests'],
    leadership: ['Leitung', 'Kennzahlen, Notizen und Entscheidungen'],
    documents: ['Dokumente', 'Erzeugte PDF-Dokumente'],
    users: ['Benutzer', 'Zugänge der Bediensteten'],
    ranks: ['Ränge', 'Ränge und Berechtigungen']
  };

  /* ---------- Auth ---------- */
  const loginView = $('#loginView');
  const appView = $('#appView');
  const loginForm = $('#loginForm');
  const loginError = $('#loginError');
  const loginSubmit = $('#loginSubmit');

  function can(perm) {
    if (!state.user) return false;
    return Array.isArray(state.user.permissions) && state.user.permissions.includes(perm);
  }

  const VIEW_PERMISSIONS = {
    applications: 'applications.view',
    tickets: 'applications.view',
    archive: 'archive.manage',
    wanted: 'wanted.view',
    news: 'news.view',
    evidence: 'evidence.view',
    citizens: 'applications.view',
    vehicles: 'applications.view',
    weapons: 'weapons.view',
    activity: 'activity.view',
    hr: 'hr.view',
    training: 'training.view',
    leadership: 'leadership.view',
    recruitment: 'recruitment.manage',
    documents: 'applications.view',
    users: 'users.view',
    ranks: 'ranks.view'
  };

  function updateUserUI() {
    if (!state.user) return;
    const name = state.user.displayName || state.user.username || 'Bedienstete';
    $('#userName').textContent = name;
    $('#userRank').textContent = state.user.rankName || 'Bedienstete';
    $('#userAvatar').textContent = name.split(/\s+/).map((p) => p[0]).join('').slice(0, 2).toUpperCase();
    $('#sysUser').textContent = name;
    $('#welcomeTitle').textContent = 'Willkommen, ' + name.split(/\s+/)[0];
    $('#welcomeText').textContent = new Date().toLocaleDateString('de-DE', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }) + ' · Alle Vorgänge und Dokumente auf einen Blick.';
  }

  function applyPermissions() {
    $$('[data-perm]').forEach((el) => {
      const perm = el.getAttribute('data-perm');
      el.hidden = !can(perm);
    });
    $$('.side-label').forEach((label) => {
      let next = label.nextElementSibling;
      let hasVisibleItem = false;
      while (next && !next.classList.contains('side-label')) {
        if (next.matches('[data-view]') && !next.hidden) {
          hasVisibleItem = true;
          break;
        }
        next = next.nextElementSibling;
      }
      label.hidden = !hasVisibleItem;
    });
  }

  function showLogin() {
    appView.hidden = true;
    loginView.hidden = false;
    if (loginForm) loginForm.reset();
    if (loginError) loginError.hidden = true;
  }

  async function showApp() {
    loginView.hidden = true;
    appView.hidden = false;
    updateUserUI();
    applyPermissions();
    switchView('overview', true);
    await Promise.allSettled([loadStats(), loadOverview(), loadUsersSilent(), loadTicketBadge(), loadArchiveBadge()]);
  }

  async function loadTicketBadge() {
    if (!can('applications.view')) return;
    try {
      const res = await api.getTickets();
      const open = (res.tickets || []).filter((t) => t.status !== 'abgeschlossen' && t.status !== 'abgelehnt').length;
      const nav = $('#navTicketCount');
      if (nav) nav.textContent = open;
    } catch (e) { /* ignore */ }
  }

  async function loadUsersSilent() {
    if (!can('users.view')) return;
    try {
      const res = await api.getUsers();
      state.users = res.users || [];
    } catch (e) { /* ignore */ }
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!loginForm.reportValidity()) return;
      const username = loginForm.querySelector('[name="user"]').value.trim();
      const password = loginForm.querySelector('[name="pass"]').value;
      if (loginSubmit) loginSubmit.disabled = true;
      try {
        const res = await api.login(username, password);
        api.setToken(res.token);
        state.user = res.user;
        if (loginError) loginError.hidden = true;
        toast('Willkommen im Intranet, ' + (res.user.displayName || res.user.username) + '.', { title: 'Anmeldung erfolgreich' });
        await showApp();
      } catch (err) {
        if (loginError) {
          loginError.hidden = false;
          const p = loginError.querySelector('p');
          if (p) p.textContent = err.message || 'Bitte prüfen Sie Benutzername und Passwort.';
        }
        toast(err.message || 'Anmeldung fehlgeschlagen.', { type: 'error', title: 'Fehler' });
      } finally {
        if (loginSubmit) loginSubmit.disabled = false;
      }
    });
  }

  const togglePass = $('#togglePass');
  const passInput = $('#loginPass');
  if (togglePass && passInput) {
    togglePass.addEventListener('click', () => {
      const visible = passInput.type === 'text';
      passInput.type = visible ? 'password' : 'text';
      togglePass.innerHTML = icon(visible ? 'eye' : 'eye-off');
      togglePass.setAttribute('aria-label', visible ? 'Passwort anzeigen' : 'Passwort verbergen');
    });
  }

  $('#logoutBtn')?.addEventListener('click', () => {
    api.setToken(null);
    state.user = null;
    state.applications = [];
    showLogin();
    toast('Sie wurden abgemeldet.', { title: 'Abgemeldet' });
  });

  /* ---------- Navigation ---------- */
  function switchView(view, force) {
    if (!VIEW_META[view]) view = 'overview';
    const requiredPermission = VIEW_PERMISSIONS[view];
    if (requiredPermission && !can(requiredPermission)) {
      toast('Für diesen Bereich fehlt die Berechtigung.', { type: 'error', title: 'Kein Zugriff' });
      view = 'overview';
    }
    state.view = view;
    state.filter = '';
    const global = $('#globalFilter');
    if (global) global.value = '';
    $$('[data-view-panel]').forEach((panel) => {
      panel.hidden = panel.getAttribute('data-view-panel') !== view;
    });
    $$('.side-item[data-view]').forEach((btn) => {
      btn.classList.toggle('is-active', btn.getAttribute('data-view') === view);
    });
    const meta = VIEW_META[view];
    $('#viewTitle').textContent = meta[0];
    $('#viewSub').textContent = meta[1];
    $('#content').scrollTop = 0;
    closeSidebar();
    if (force || !state.loadedViews) state.loadedViews = {};
    if (state.loadedViews && state.loadedViews[view] && !force) return;
    if (state.loadedViews) state.loadedViews[view] = true;
    loadView(view);
  }

  async function loadView(view) {
    try {
      if (view === 'overview') { await loadOverview(); }
      else if (view === 'applications') { await loadApplications(); }
      else if (view === 'tickets') { await loadTickets(); }
      else if (view === 'archive') { await loadArchive(); }
      else if (view === 'recruitment') { await loadRecruitment(); }
      else if (view === 'wanted') { await loadWanted(); }
      else if (view === 'news') { await loadNews(); }
      else if (view === 'evidence') { await loadEvidence(); }
      else if (view === 'citizens') { await initCitizens(); }
      else if (view === 'vehicles') { await initVehicles(); }
      else if (view === 'weapons') { await loadWeapons(); }
      else if (view === 'activity') { await loadActivity(); }
      else if (view === 'laws') { await loadLaws(); }
      else if (view === 'recruitment') { await loadRecruitment(); }
      else if (view === 'hr') { await loadHr(); }
      else if (view === 'training') { await loadTraining(); }
      else if (view === 'leadership') { await loadLeadership(); }
      else if (view === 'documents') { await loadDocuments(); }
      else if (view === 'users') { await loadUsers(); }
      else if (view === 'ranks') { await loadRanks(); }
    } catch (err) {
      toast(err.message || 'Daten konnten nicht geladen werden.', { type: 'error', title: 'Fehler' });
    }
  }

  $$('.side-item[data-view]').forEach((btn) => {
    btn.addEventListener('click', () => switchView(btn.getAttribute('data-view')));
  });
  $$('[data-view-go]').forEach((btn) => {
    btn.addEventListener('click', () => switchView(btn.getAttribute('data-view-go')));
  });

  /* Mobile sidebar */
  const menuBtn = $('#menuBtn');
  function closeSidebar() { appView.classList.remove('side-open'); }
  menuBtn?.addEventListener('click', () => appView.classList.toggle('side-open'));
  $('[data-side-close]')?.addEventListener('click', closeSidebar);

  /* Clock */
  function tickClock() {
    const el = $('#clock');
    if (el) el.textContent = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
  tickClock();
  setInterval(tickClock, 1000);

  /* ---------- Stats / Übersicht ---------- */
  async function loadStats() {
    try {
      const res = await api.request('/api/stats');
      const s = res.stats || {};
      const total = Number(s.reports || 0) + Number(s.strafanzeigen || 0) + Number(s.leading || 0)
        + Number(s.career || 0) + Number(s.contact || 0) + Number(s.appointments || 0) + Number(s.hints || 0);
      const kpiApps = $('#kpiApplications');
      if (kpiApps) kpiApps.textContent = total;
      const kWanted = $('#kpiWanted');
      if (kWanted) kWanted.textContent = s.wanted || 0;
      const kUsers = $('#kpiUsers');
      if (kUsers) kUsers.textContent = s.users || 0;
      const navWanted = $('#navWantedCount');
      if (navWanted) navWanted.textContent = s.wanted || 0;
    } catch (e) { /* ignore */ }
  }

  async function loadOverview() {
    if (can('applications.view')) {
      try {
        const res = await api.getApplications({ limit: 200 });
        state.applications = res.applications || [];
        renderOverviewApps();
        updateAppKpis();
      } catch (e) { /* ignore */ }
    }
    if (can('applications.view')) {
      try {
        const res = await api.getDocuments();
        state.documents = res.documents || [];
        const sys = $('#sysDocs');
        if (sys) sys.textContent = state.documents.length + ' gespeichert';
      } catch (e) { /* ignore */ }
    }
  }

  function updateAppKpis() {
    const open = state.applications.filter((a) => a.status !== 'abgeschlossen' && a.status !== 'abgelehnt').length;
    const kpiOpen = $('#kpiOpen');
    if (kpiOpen) kpiOpen.textContent = open;
    const navApp = $('#navAppCount');
    if (navApp) navApp.textContent = state.applications.length;
    const badge = $('#appCountBadge');
    if (badge) badge.textContent = state.applications.length + ' Vorgänge';
  }

  function renderOverviewApps() {
    const body = $('#overviewAppsBody');
    if (!body) return;
    const items = state.applications.slice(0, 6);
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="4">Noch keine Vorgänge vorhanden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((a) => `
      <tr>
        <td><span class="mono">${esc(a.ref)}</span></td>
        <td>${esc(TYPE_LABEL[a.type] || a.type)}</td>
        <td>${statusBadge(a.status)}</td>
        <td>${day(a.created_at)}</td>
      </tr>`).join('');
  }

  /* ---------- Vorgänge ---------- */
  async function loadApplications() {
    const params = { limit: 200 };
    const type = $('#appTypeFilter')?.value;
    const status = $('#appStatusFilter')?.value;
    if (type) params.type = type;
    if (status) params.status = status;
    const res = await api.getApplications(params);
    state.applications = res.applications || [];
    renderApplications();
    updateAppKpis();
  }

  function renderApplications() {
    const body = $('#appTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.applications.filter((a) => {
      if (!term) return true;
      return [a.ref, a.type, a.applicant_name, a.applicant_email, a.status]
        .filter(Boolean).join(' ').toLowerCase().includes(term);
    });
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Vorgänge gefunden.</td></tr>';
    } else {
      body.innerHTML = items.map((a) => `
        <tr>
          <td><span class="mono">${esc(a.ref)}</span></td>
          <td>${esc(TYPE_LABEL[a.type] || a.type)}</td>
          <td><strong>${esc(a.applicant_name || '–')}</strong>${a.applicant_email ? `<br><span style="font-size:11px;color:var(--i-muted-2)">${esc(a.applicant_email)}</span>` : ''}</td>
          <td>${statusBadge(a.status)}</td>
          <td>${day(a.created_at)}</td>
          <td><button type="button" class="btn btn-ghost btn-sm" data-app-view="${a.id}">${icon('search')} Öffnen</button></td>
        </tr>`).join('');
    }
    const badge = $('#appCountBadge');
    if (badge) badge.textContent = items.length + ' Vorgänge';
  }

  $('#appSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderApplications(); });
  $('#appTypeFilter')?.addEventListener('change', () => loadApplications().catch((err) => toast(err.message, { type: 'error' })));
  $('#appStatusFilter')?.addEventListener('change', () => loadApplications().catch((err) => toast(err.message, { type: 'error' })));
  $('#appRefresh')?.addEventListener('click', () => loadApplications().then(() => toast('Vorgänge aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));

  $('#appTableBody')?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-app-view]');
    if (!btn) return;
    openApplication(Number(btn.getAttribute('data-app-view')));
  });

  async function openApplication(id) {
    try {
      const res = await api.request('/api/applications/' + id);
      const a = res.application;
      const canManage = can('applications.manage');
      const statusOptions = Object.keys(STATUS).map((key) => `<option value="${key}" ${a.status === key ? 'selected' : ''}>${STATUS[key][1]}</option>`).join('');
      const userOptions = ['<option value="">– nicht zugewiesen –</option>'].concat(
        state.users.map((u) => `<option value="${u.id}" ${Number(a.assigned_to) === Number(u.id) ? 'selected' : ''}>${esc(u.display_name)} (${esc(u.rank_name)})</option>`)
      ).join('');
      const payload = a.payload && typeof a.payload === 'object' ? a.payload : {};
      const fields = Object.keys(payload).map((key) => `<div class="detail-row"><dt>${esc(key)}</dt><dd>${esc(typeof payload[key] === 'object' ? JSON.stringify(payload[key]) : payload[key])}</dd></div>`).join('');
      const uploads = res.uploads || [];
      const uploadRows = uploads.map((u) => `
        <div class="upload-row">
          <span class="upload-icon">${icon('file')}</span>
          <span class="upload-meta"><strong>${esc(u.kind === 'lebenslauf' ? 'Lebenslauf' : 'Anschreiben')}</strong><small>${esc(u.filename)} · ${Math.max(1, Math.round(Number(u.size || 0) / 1024))} KB</small></span>
          <button type="button" class="btn btn-ghost btn-sm" data-upload-download="${u.id}" data-upload-name="${esc(u.filename)}">${icon('download')} Herunterladen</button>
        </div>`).join('');

      $('#appModalTitle').textContent = TYPE_LABEL[a.type] || a.type;
      $('#appModalSub').textContent = a.ref;
      $('#appModalBody').innerHTML = `
        <div class="detail-list">
          <div class="detail-row"><dt>Referenz</dt><dd class="mono">${esc(a.ref)}</dd></div>
          <div class="detail-row"><dt>Status</dt><dd>${statusBadge(a.status)}</dd></div>
          <div class="detail-row"><dt>Antragsteller</dt><dd>${esc(a.applicant_name || '–')}</dd></div>
          <div class="detail-row"><dt>E-Mail</dt><dd>${esc(a.applicant_email || '–')}</dd></div>
          <div class="detail-row"><dt>Geburtsdatum</dt><dd>${a.applicant_birth ? day(a.applicant_birth) : esc(payload.birth || '–')}</dd></div>
          <div class="detail-row"><dt>Dienststelle</dt><dd>${esc(a.station_id || '–')}</dd></div>
          <div class="detail-row"><dt>Eingang</dt><dd>${dt(a.created_at)}</dd></div>
          <div class="detail-row"><dt>Zugewiesen an</dt><dd>${esc(a.assigned_name || '–')}</dd></div>
        </div>
        ${uploads.length ? `<h3 class="record-subtitle">Bewerbungsunterlagen</h3><div class="upload-list">${uploadRows}</div>` : (a.type === 'career' ? '<p class="form-note">Für diese Bewerbung sind keine Unterlagen gespeichert.</p>' : '')}
        ${fields ? `<h3 class="record-subtitle">Antragsdaten</h3><div class="detail-list">${fields}</div>` : ''}
        ${a.type === 'leading_certificate' ? `
          <div class="form-actions" style="margin-top:0;margin-bottom:16px">
            <button type="button" class="btn btn-gold btn-sm" id="appPdfBtn">${icon('download')} Führungszeugnis als PDF</button>
            <span class="form-note">Das PDF wird in der Datenbank gespeichert.</span>
          </div>` : ''}
        ${canManage ? `
          <form id="appEditForm">
            <div class="form-grid">
              <div class="i-field"><label>Status</label><select name="status">${statusOptions}</select></div>
              <div class="i-field"><label>Zugewiesen an</label><select name="assignedTo">${userOptions}</select></div>
              <div class="i-field span-2"><label>Interne Notiz</label><textarea name="internalNote">${esc(a.internal_note || '')}</textarea></div>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn btn-primary btn-sm">${icon('check')} Speichern</button>
              <button type="button" class="btn btn-danger btn-sm" id="appDeleteBtn">${icon('trash')} Löschen</button>
            </div>
          </form>` : '<p class="form-note">Keine Berechtigung zur Bearbeitung.</p>'}`;

      openModal('appModal');

      $$('[data-upload-download]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            const blob = await api.downloadUpload(a.id, Number(btn.getAttribute('data-upload-download')));
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = btn.getAttribute('data-upload-name') || 'bewerbungsunterlage';
            document.body.appendChild(link);
            link.click();
            link.remove();
            setTimeout(() => URL.revokeObjectURL(url), 5000);
          } catch (err) {
            toast(err.message || 'Datei konnte nicht geladen werden.', { type: 'error' });
          }
        });
      });

      $('#appPdfBtn')?.addEventListener('click', async () => {
        try {
          const meta = await api.createCertificate(a.id);
          await downloadBlob(meta.id, meta.filename || ('Fuehrungszeugnis_' + a.ref + '.pdf'));
          toast('Führungszeugnis-PDF heruntergeladen.', { title: 'PDF bereit' });
        } catch (err) { toast(err.message || 'PDF konnte nicht erzeugt werden.', { type: 'error' }); }
      });

      $('#appEditForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const fd = new FormData(event.target);
        try {
          await api.updateApplication(a.id, {
            status: fd.get('status'),
            assignedTo: fd.get('assignedTo') ? Number(fd.get('assignedTo')) : null,
            internalNote: fd.get('internalNote')
          });
          toast('Vorgang aktualisiert.', { title: 'Gespeichert' });
          closeModal('appModal');
          await loadApplications();
        } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
      });

      $('#appDeleteBtn')?.addEventListener('click', async () => {
        if (!window.confirm('Vorgang wirklich löschen?')) return;
        try {
          await api.deleteApplication(a.id);
          toast('Vorgang gelöscht.', { title: 'Gelöscht' });
          closeModal('appModal');
          await loadApplications();
        } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
      });
    } catch (err) {
      toast(err.message || 'Vorgang konnte nicht geladen werden.', { type: 'error' });
    }
  }

  /* ---------- Tickets (Onlinewache) ---------- */
  function parsePayload(app) {
    try { return JSON.parse(app.payload || '{}') || {}; } catch (e) { return {}; }
  }

  function ticketArt(t) {
    const p = parsePayload(t);
    return p.art || TYPE_LABEL[t.type] || 'Onlinewache';
  }

  function citizenDisplay(t) {
    const p = parsePayload(t);
    if (p.anonymous) return 'Anonym';
    return t.applicant_name || t.citizen_global_name || t.citizen_username || 'Anonym';
  }

  function citizenMeta(t) {
    if (!t.citizen_account_id) return '';
    const p = parsePayload(t);
    if (p.anonymous) return 'Anonym · Discord-Konto verknüpft';
    return t.citizen_username ? '@' + t.citizen_username : 'Discord-Konto';
  }

  function initials(name) {
    const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  function timeOnly(value) {
    if (!value) return '';
    try {
      return new Date(value).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return ''; }
  }

  function renderTicketThread(messages) {
    if (!messages.length) return '<p class="form-note">Noch keine Nachrichten.</p>';
    let lastDay = '';
    return messages.map((m) => {
      const police = m.sender === 'police';
      const name = police ? (m.author_name || 'Landespolizei') : (m.author_name || 'Bürger');
      const day = m.created_at ? new Date(m.created_at).toLocaleDateString('de-DE') : '';
      const divider = day && day !== lastDay ? `<div class="ticket-day">${esc(day)}</div>` : '';
      lastDay = day || lastDay;
      return `${divider}
        <div class="ticket-message ${police ? 'is-police' : 'is-citizen'}">
          <div class="ticket-message-avatar">${esc(initials(name))}</div>
          <div class="ticket-message-body">
            <div class="ticket-message-head">
              <strong>${esc(name)}</strong>
              <small>${esc(timeOnly(m.created_at))}</small>
            </div>
            <div class="ticket-message-bubble">${esc(m.message)}</div>
          </div>
        </div>`;
    }).join('');
  }

  function refreshTicketThread(messages, status, options) {
    const thread = $('#ticketThread');
    if (thread) {
      thread.innerHTML = renderTicketThread(messages);
      if (options && options.scroll) {
        window.requestAnimationFrame(() => { thread.scrollTop = thread.scrollHeight; });
      }
    }
    if (status) {
      const badge = $('#ticketStatusBadge');
      if (badge) badge.innerHTML = statusBadge(status);
    }
  }

  async function loadTickets() {
    const params = {};
    const q = $('#ticketSearch')?.value.trim();
    const status = $('#ticketStatusFilter')?.value;
    if (q) params.q = q;
    if (status) params.status = status;
    const res = await api.getTickets(params);
    state.tickets = res.tickets || [];
    renderTickets();
    const nav = $('#navTicketCount');
    if (nav) nav.textContent = state.tickets.filter((t) => t.status !== 'abgeschlossen' && t.status !== 'abgelehnt').length;
  }

  function renderTickets() {
    const body = $('#ticketsTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.tickets.filter((t) => !term || [t.ref, t.applicant_name, t.citizen_username, t.citizen_global_name, t.assigned_name, ticketArt(t), t.status]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    const badge = $('#ticketCountBadge');
    if (badge) badge.textContent = items.length + ' Tickets';
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="7">Keine Tickets vorhanden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((t) => {
      const p = parsePayload(t);
      const subjectText = p.subject || p.topic || p.text || p.message || '';
      const subject = (p.ort ? p.ort + ' – ' : '') + String(subjectText).slice(0, 70) + (String(subjectText).length > 70 ? ' …' : '');
      const meta = citizenMeta(t);
      return `
        <tr>
          <td><span class="mono">${esc(t.ref)}</span></td>
          <td><div class="ticket-subject-cell"><span class="badge badge-blue">${esc(ticketArt(t))}</span><strong>${esc(subject || '–')}</strong></div></td>
          <td><strong>${esc(citizenDisplay(t))}</strong>${meta ? `<small class="ticket-citizen-tag">${esc(meta)}</small>` : ''}${t.last_sender === 'citizen' && !['abgeschlossen','abgelehnt'].includes(t.status) ? '<span class="ticket-new-msg">Neue Nachricht</span>' : ''}</td>
          <td>${t.assigned_name ? `<span class="ticket-assignee-chip">${esc(t.assigned_name)}</span>` : '<span class="ticket-unassigned">Frei</span>'}</td>
          <td>${statusBadge(t.status)}</td>
          <td>${day(t.created_at)}</td>
          <td><div class="ticket-row-actions"><button type="button" class="btn btn-ghost btn-sm" data-ticket-view="${t.id}">${icon('message')} Öffnen</button>${!t.assigned_to && can('applications.manage') ? `<button type="button" class="btn btn-primary btn-sm" data-ticket-take="${t.id}">${icon('user')} Übernehmen</button>` : ''}</div></td>
        </tr>`;
    }).join('');
  }

  $('#ticketSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderTickets(); });
  $('#ticketStatusFilter')?.addEventListener('change', () => loadTickets().catch((err) => toast(err.message, { type: 'error' })));
  $('#ticketsRefresh')?.addEventListener('click', () => loadTickets().then(() => toast('Tickets aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));

  $('#ticketsTableBody')?.addEventListener('click', async (e) => {
    const take = e.target.closest('[data-ticket-take]');
    if (take) {
      try {
        await api.takeTicket(Number(take.getAttribute('data-ticket-take')));
        await loadTickets();
        toast('Ticket wurde übernommen.', { title: 'Zuweisung' });
      } catch (err) {
        toast(err.message || 'Ticket konnte nicht übernommen werden.', { type: 'error' });
      }
      return;
    }
    const btn = e.target.closest('[data-ticket-view]');
    if (btn) openTicket(Number(btn.getAttribute('data-ticket-view')));
  });

  const PAYLOAD_LABELS = {
    art: 'Art', ort: 'Ort', plz: 'PLZ', zeit: 'Zeit', text: 'Sachverhalt',
    beteiligte: 'Beteiligte', name: 'Name', email: 'E-Mail', phone: 'Telefon',
    topic: 'Anliegen', subject: 'Betreff', message: 'Nachricht', station: 'Dienststelle',
    anonymous: 'Anonym'
  };

  function payloadLabel(key) {
    return PAYLOAD_LABELS[key] || key;
  }

  async function openTicket(id) {
    try {
      const res = await api.getTicket(id);
      let currentTicket = res.ticket || {};
      const messages = res.messages || [];
      const canManage = can('applications.manage');
      const p = parsePayload(currentTicket);
      const meta = citizenMeta(currentTicket);
      const subject = p.subject || p.topic || p.text || p.message || 'Ticket';
      const officerName = state.user ? (state.user.displayName || state.user.username || 'Polizei') : 'Polizei';
      $('#ticketModalTitle').textContent = ticketArt(currentTicket);
      $('#ticketModalSub').textContent = currentTicket.ref || '';

      const infoItems = [
        `<div class="ticket-info-item"><label>Antragsteller</label><span>${esc(currentTicket.applicant_name || citizenDisplay(currentTicket))}</span></div>`,
        currentTicket.applicant_email
          ? `<div class="ticket-info-item"><label>E-Mail</label><span>${esc(currentTicket.applicant_email)}</span></div>`
          : '',
        currentTicket.citizen_account_id
          ? `<div class="ticket-info-item"><label>Discord</label><span>${esc(citizenDisplay(currentTicket))}${meta && !p.anonymous ? ` <small class="ticket-citizen-tag">${esc(meta)}</small>` : ''}</span></div>`
          : '',
        `<div class="ticket-info-item"><label>Eingang</label><span>${dt(currentTicket.created_at)}</span></div>`,
        `<div class="ticket-info-item"><label>Bearbeiter</label><span id="ticketInfoAssignee">–</span></div>`
      ].join('');

      const payloadItems = Object.keys(p).map((key) => {
        const value = p[key];
        if (value == null || value === '') return '';
        return `<div class="ticket-info-item"><label>${esc(payloadLabel(key))}</label><span>${esc(typeof value === 'object' ? JSON.stringify(value) : value)}</span></div>`;
      }).join('');

      $('#ticketModalBody').innerHTML = `
        <div class="ticket-chat-shell">
          <div class="ticket-chat-main">
            <div class="ticket-chat-head">
              <div class="ticket-chat-title">
                <div class="ticket-head-eyebrow">
                  <span class="badge badge-blue">${esc(ticketArt(currentTicket))}</span>
                  <span class="ticket-ref mono">${esc(currentTicket.ref)}</span>
                </div>
                <h3>${esc(subject)}</h3>
                <p class="ticket-chat-subject">${esc(citizenDisplay(currentTicket))} · ${dt(currentTicket.created_at)}</p>
              </div>
              <div class="ticket-chat-head-actions">
                <span id="ticketStatusBadge">${statusBadge(currentTicket.status)}</span>
                <span class="ticket-assignee" id="ticketAssigneeLabel"></span>
                ${canManage ? '<button type="button" class="btn btn-primary btn-sm" id="ticketTakeBtn">Ticket übernehmen</button>' : ''}
                ${can('archive.manage') ? '<button type="button" class="btn btn-ghost btn-sm" id="ticketArchiveBtn" hidden>Archivieren</button>' : ''}
              </div>
            </div>

            <div class="ticket-thread" id="ticketThread">
              ${renderTicketThread(messages)}
            </div>

            ${canManage ? `
              <form id="ticketReplyForm" class="ticket-composer">
                <div class="ticket-composer-top">
                  <div class="ticket-reply-as">
                    <span class="ticket-message-avatar">${esc(initials(officerName))}</span>
                    <span>Antwort als <strong>${esc(officerName)}</strong></span>
                  </div>
                  <select id="ticketStatusSelect" class="i-select ticket-status-select" name="status">
                    ${Object.keys(STATUS).map((key) => `<option value="${key}" ${currentTicket.status === key ? 'selected' : ''}>${STATUS[key][1]}</option>`).join('')}
                  </select>
                </div>
                <textarea id="ticketReply" name="message" placeholder="Nachricht an den Bürger …"></textarea>
                <div class="ticket-composer-actions">
                  <span class="form-note">Die Antwort erscheint direkt im Ticket-Chat des Bürgers.</span>
                  <button type="button" class="btn btn-ghost btn-sm" id="ticketRefresh">${icon('refresh')} Aktualisieren</button>
                  <button type="submit" class="btn btn-primary btn-sm">${icon('send')} Senden</button>
                </div>
              </form>` : '<p class="form-note">Keine Berechtigung zum Bearbeiten.</p>'}
          </div>

          <aside class="ticket-chat-side">
            <details class="ticket-info" open>
              <summary>Ticketdaten</summary>
              <div class="ticket-info-grid">
                ${infoItems}
                ${payloadItems}
              </div>
            </details>
          </aside>
        </div>`;

      openModal('ticketModal');
      window.requestAnimationFrame(() => {
        const thread = $('#ticketThread');
        if (thread) thread.scrollTop = thread.scrollHeight;
      });

      function applyTicketMeta(ticket) {
        const status = $('#ticketStatusBadge');
        if (status) status.innerHTML = statusBadge(ticket.status);
        const assignedName = ticket.assigned_name || 'Nicht zugewiesen';
        const label = $('#ticketAssigneeLabel');
        if (label) {
          label.textContent = ticket.assigned_to ? 'Bearbeiter: ' + assignedName : 'Noch nicht zugewiesen';
          label.classList.toggle('is-free', !ticket.assigned_to);
        }
        const info = $('#ticketInfoAssignee');
        if (info) info.textContent = assignedName;
        const select = $('#ticketStatusSelect');
        if (select && document.activeElement !== select) select.value = ticket.status;
        const btn = $('#ticketTakeBtn');
        if (btn) {
          const mine = ticket.assigned_to && state.user && Number(ticket.assigned_to) === Number(state.user.id);
          btn.textContent = mine ? 'Bearbeitung abgeben' : 'Ticket übernehmen';
          btn.className = 'btn btn-sm ' + (mine ? 'btn-ghost' : 'btn-primary');
          btn.title = mine ? 'Ticket wieder freigeben' : (ticket.assigned_name ? `Von ${ticket.assigned_name} übernehmen` : 'Ticket übernehmen');
        }
        const archiveBtn = $('#ticketArchiveBtn');
        if (archiveBtn) {
          archiveBtn.hidden = !ticket.archived_at && ticket.status !== 'abgeschlossen';
          archiveBtn.textContent = ticket.archived_at ? 'Aus Archiv holen' : 'Archivieren';
          archiveBtn.className = 'btn btn-sm ' + (ticket.archived_at ? 'btn-ghost' : 'btn-primary');
        }
      }

      applyTicketMeta(currentTicket);

      $('#ticketTakeBtn')?.addEventListener('click', async () => {
        const mine = currentTicket.assigned_to && state.user && Number(currentTicket.assigned_to) === Number(state.user.id);
        try {
          const result = mine ? await api.releaseTicket(id) : await api.takeTicket(id);
          currentTicket.assigned_to = result.assigned_to;
          currentTicket.assigned_name = result.assigned_name;
          applyTicketMeta(currentTicket);
          await loadTickets();
          toast(mine ? 'Bearbeitung wurde abgegeben.' : 'Ticket wurde übernommen.', { title: 'Zuweisung' });
        } catch (err) {
          toast(err.message || 'Ticket konnte nicht zugewiesen werden.', { type: 'error' });
        }
      });

      $('#ticketArchiveBtn')?.addEventListener('click', async () => {
        const archived = Boolean(currentTicket.archived_at);
        try {
          if (archived) await api.unarchiveTicket(id);
          else await api.archiveTicket(id);
          toast(archived ? 'Ticket wurde aus dem Archiv geholt.' : 'Ticket wurde archiviert.', { title: archived ? 'Wiederhergestellt' : 'Archiviert' });
          closeModal('ticketModal');
          if (state.view === 'archive') await loadArchive();
          else await loadTickets();
          await loadArchiveBadge();
        } catch (err) {
          toast(err.message || 'Archivierung fehlgeschlagen.', { type: 'error' });
        }
      });

      $('#ticketRefresh')?.addEventListener('click', async () => {
        try {
          const latest = await api.getTicket(id);
          currentTicket = { ...currentTicket, ...(latest.ticket || {}) };
          refreshTicketThread(latest.messages || [], currentTicket.status, { scroll: true });
          applyTicketMeta(currentTicket);
          toast('Ticket aktualisiert.');
        } catch (err) { toast(err.message || 'Aktualisieren fehlgeschlagen.', { type: 'error' }); }
      });

      $('#ticketReplyForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const message = $('#ticketReply').value.trim();
        if (!message) { toast('Bitte eine Nachricht eingeben.', { type: 'error' }); return; }
        try {
          await api.replyTicket(id, { message, status: $('#ticketStatusSelect').value });
          $('#ticketReply').value = '';
          const latest = await api.getTicket(id);
          currentTicket = { ...currentTicket, ...(latest.ticket || {}) };
          refreshTicketThread(latest.messages || [], currentTicket.status, { scroll: true });
          applyTicketMeta(currentTicket);
          await loadTickets();
          toast('Antwort wurde gesendet.', { title: 'Gespeichert' });
        } catch (err) { toast(err.message || 'Antwort konnte nicht gesendet werden.', { type: 'error' }); }
      });

      let lastKey = messages.map((m) => m.id).join(',');
      stopTicketPoll();
      state.ticketPoll = window.setInterval(async () => {
        if ($('#ticketModal')?.hidden) return;
        try {
          const latest = await api.getTicket(id);
          const latestTicket = latest.ticket || {};
          const key = (latest.messages || []).map((m) => m.id).join(',');
          const assignmentChanged = latestTicket.assigned_to !== currentTicket.assigned_to;
          const statusChanged = latestTicket.status !== currentTicket.status;
          if (key !== lastKey || assignmentChanged || statusChanged) {
            currentTicket = { ...currentTicket, ...latestTicket };
            if (key !== lastKey) {
              lastKey = key;
              refreshTicketThread(latest.messages || [], currentTicket.status, { scroll: true });
            }
            applyTicketMeta(currentTicket);
          }
        } catch (e) { /* still */ }
      }, 5000);
    } catch (err) {
      toast(err.message || 'Ticket konnte nicht geladen werden.', { type: 'error' });
    }
  }

  function stopTicketPoll() {
    if (state.ticketPoll) {
      window.clearInterval(state.ticketPoll);
      state.ticketPoll = null;
    }
  }

  async function loadArchiveBadge() {
    if (!can('archive.manage')) return;
    try {
      const res = await api.getTickets({ archived: 1 });
      const nav = $('#navArchiveCount');
      if (nav) nav.textContent = (res.tickets || []).length;
    } catch (e) { /* ignore */ }
  }

  async function loadArchive() {
    const res = await api.getTickets({ archived: 1 });
    state.archive = res.tickets || [];
    renderArchive();
    const nav = $('#navArchiveCount');
    if (nav) nav.textContent = state.archive.length;
  }

  function renderArchive() {
    const body = $('#archiveTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.archive.filter((t) => !term || [t.ref, t.applicant_name, t.citizen_username, t.assigned_name, ticketArt(t)]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    const badge = $('#archiveCountBadge');
    if (badge) badge.textContent = items.length + ' archiviert';
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="7">Keine archivierten Tickets vorhanden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((t) => {
      const p = parsePayload(t);
      const subjectText = p.subject || p.topic || p.text || p.message || '';
      const subject = String(subjectText).slice(0, 70) + (String(subjectText).length > 70 ? ' …' : '');
      return `
        <tr>
          <td><span class="mono">${esc(t.ref)}</span></td>
          <td><div class="ticket-subject-cell"><span class="badge badge-blue">${esc(ticketArt(t))}</span><strong>${esc(subject || '–')}</strong></div></td>
          <td>${esc(citizenDisplay(t))}</td>
          <td>${t.assigned_name ? `<span class="ticket-assignee-chip">${esc(t.assigned_name)}</span>` : '<span class="ticket-unassigned">Frei</span>'}</td>
          <td>${dt(t.updated_at)}</td>
          <td>${dt(t.archived_at)}</td>
          <td><div class="ticket-row-actions"><button type="button" class="btn btn-ghost btn-sm" data-ticket-view="${t.id}">${icon('eye')} Öffnen</button><button type="button" class="btn btn-primary btn-sm" data-ticket-restore="${t.id}">${icon('refresh')} Zurückholen</button></div></td>
        </tr>`;
    }).join('');
  }

  $('#archiveSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderArchive(); });
  $('#archiveRefresh')?.addEventListener('click', () => loadArchive().then(() => toast('Archiv aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#archiveTableBody')?.addEventListener('click', async (e) => {
    const restore = e.target.closest('[data-ticket-restore]');
    if (restore) {
      try {
        await api.unarchiveTicket(Number(restore.getAttribute('data-ticket-restore')));
        toast('Ticket wurde aus dem Archiv geholt.', { title: 'Wiederhergestellt' });
        await loadArchive();
        await loadArchiveBadge();
      } catch (err) { toast(err.message || 'Ticket konnte nicht wiederhergestellt werden.', { type: 'error' }); }
      return;
    }
    const btn = e.target.closest('[data-ticket-view]');
    if (btn) openTicket(Number(btn.getAttribute('data-ticket-view')));
  });

  /* ---------- Fahndungen ---------- */
  async function loadWanted() {
    const res = can('wanted.manage')
      ? await api.request('/api/wanted/admin/all')
      : await api.getWanted();
    state.wanted = res.wanted || [];
    const nav = $('#navWantedCount');
    if (nav) nav.textContent = state.wanted.filter((w) => w.status === 'aktiv').length;
    renderWanted();
  }

  function renderWanted() {
    const body = $('#wantedTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.wanted.filter((w) => !term || [w.case_no, w.title, w.location, w.category, w.status].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Fahndungen gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((w) => `
      <tr>
        <td><span class="mono">${esc(w.case_no)}</span></td>
        <td><strong>${esc(w.title)}</strong></td>
        <td>${esc(w.category || '–')}</td>
        <td>${esc(w.location || '–')}</td>
        <td><span class="badge ${w.status === 'aktiv' ? 'badge-red' : 'badge-gray'}">${esc(w.status)}</span></td>
        <td><div class="row-actions">
          ${can('wanted.manage') ? `
            <button type="button" class="icon-action" data-wanted-edit="${w.id}" title="Bearbeiten">${icon('edit')}</button>
            <button type="button" class="icon-action danger" data-wanted-delete="${w.id}" title="Löschen">${icon('trash')}</button>` : '–'}
        </div></td>
      </tr>`).join('');
  }

  $('#wantedSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderWanted(); });
  $('#wantedRefresh')?.addEventListener('click', () => loadWanted().then(() => toast('Fahndungen aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#wantedNew')?.addEventListener('click', () => openWantedForm(null));

  $('#wantedTableBody')?.addEventListener('click', async (e) => {
    const edit = e.target.closest('[data-wanted-edit]');
    const del = e.target.closest('[data-wanted-delete]');
    if (edit) {
      const item = state.wanted.find((w) => w.id === Number(edit.getAttribute('data-wanted-edit')));
      if (item) openWantedForm(item);
    }
    if (del) {
      if (!window.confirm('Fahndung wirklich löschen?')) return;
      try {
        await api.deleteWanted(Number(del.getAttribute('data-wanted-delete')));
        toast('Fahndung gelöscht.', { title: 'Gelöscht' });
        await loadWanted();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openWantedForm(item) {
    const form = $('#wantedForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#wantedModalTitle').textContent = item ? 'Fahndung bearbeiten' : 'Neue Fahndung';
    if (item) {
      form.querySelector('[name="caseNo"]').value = item.case_no || '';
      form.querySelector('[name="category"]').value = item.category || 'person';
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="location"]').value = item.location || '';
      form.querySelector('[name="status"]').value = item.status || 'aktiv';
      form.querySelector('[name="teaser"]').value = item.teaser || '';
      form.querySelector('[name="description"]').value = item.description || '';
      form.querySelector('[name="hint"]').value = item.hint || '';
    }
    openModal('wantedModal');
  }

  $('#wantedForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      caseNo: fd.get('caseNo') || undefined,
      category: fd.get('category'),
      title: fd.get('title'),
      location: fd.get('location'),
      teaser: fd.get('teaser'),
      description: fd.get('description'),
      hint: fd.get('hint'),
      status: fd.get('status')
    };
    try {
      if (id) await api.updateWanted(Number(id), body);
      else await api.createWanted(body);
      toast(id ? 'Fahndung aktualisiert.' : 'Fahndung erstellt.', { title: 'Gespeichert' });
      closeModal('wantedModal');
      await loadWanted();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Meldungen ---------- */
  async function loadNews() {
    const res = can('news.manage') ? await api.request('/api/news/admin/all') : await api.getNews();
    state.news = res.news || [];
    renderNews();
  }

  function renderNews() {
    const body = $('#newsTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.news.filter((n) => !term || [n.title, n.category, n.label].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="5">Keine Meldungen gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((n) => `
      <tr>
        <td><strong>${esc(n.title)}</strong><br><span style="font-size:11px;color:var(--i-muted-2)">${esc(n.teaser || '')}</span></td>
        <td><span class="badge badge-blue">${esc(n.category)}</span></td>
        <td><span class="badge ${n.published ? 'badge-green' : 'badge-gray'}">${n.published ? 'Ja' : 'Nein'}</span></td>
        <td>${day(n.created_at)}</td>
        <td><div class="row-actions">
          ${can('news.manage') ? `
            <button type="button" class="icon-action" data-news-edit="${n.id}" title="Bearbeiten">${icon('edit')}</button>
            <button type="button" class="icon-action danger" data-news-delete="${n.id}" title="Löschen">${icon('trash')}</button>` : '–'}
        </div></td>
      </tr>`).join('');
  }

  $('#newsSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderNews(); });
  $('#newsRefresh')?.addEventListener('click', () => loadNews().then(() => toast('Meldungen aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#newsNew')?.addEventListener('click', () => openNewsForm(null));

  $('#newsTableBody')?.addEventListener('click', async (e) => {
    const edit = e.target.closest('[data-news-edit]');
    const del = e.target.closest('[data-news-delete]');
    if (edit) {
      const item = state.news.find((n) => n.id === Number(edit.getAttribute('data-news-edit')));
      if (item) openNewsForm(item);
    }
    if (del) {
      if (!window.confirm('Meldung wirklich löschen?')) return;
      try {
        await api.deleteNews(Number(del.getAttribute('data-news-delete')));
        toast('Meldung gelöscht.', { title: 'Gelöscht' });
        await loadNews();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openNewsForm(item) {
    const form = $('#newsForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#newsModalTitle').textContent = item ? 'Meldung bearbeiten' : 'Neue Meldung';
    if (item) {
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="category"]').value = item.category || 'presse';
      form.querySelector('[name="label"]').value = item.label || 'Presse';
      form.querySelector('[name="teaser"]').value = item.teaser || '';
      form.querySelector('[name="location"]').value = item.location || '';
      form.querySelector('[name="reading"]').value = item.reading || 2;
      form.querySelector('[name="published"]').value = item.published ? '1' : '0';
      form.querySelector('[name="featured"]').value = item.featured ? '1' : '0';
      const bodyText = Array.isArray(item.body) ? item.body.map((p) => String(p).replace(/<[^>]*>/g, '')).join('\n') : '';
      form.querySelector('[name="body"]').value = bodyText;
    }
    openModal('newsModal');
  }

  $('#newsForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const lines = String(fd.get('body') || '').split(/\n+/).map((l) => l.trim()).filter(Boolean);
    const body = lines.map((line) => '<p>' + esc(line) + '</p>');
    const payload = {
      title: fd.get('title'),
      category: fd.get('category'),
      label: fd.get('label'),
      teaser: fd.get('teaser'),
      location: fd.get('location'),
      reading: Number(fd.get('reading') || 2),
      published: fd.get('published') === '1',
      featured: fd.get('featured') === '1',
      body
    };
    try {
      if (id) await api.updateNews(Number(id), payload);
      else await api.createNews(payload);
      toast(id ? 'Meldung aktualisiert.' : 'Meldung erstellt.', { title: 'Gespeichert' });
      closeModal('newsModal');
      await loadNews();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Asservaten ---------- */
  async function loadEvidence() {
    const res = await api.getEvidence();
    state.evidence = res.evidence || [];
    renderEvidence();
  }

  function renderEvidence() {
    const body = $('#evidenceTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.evidence.filter((v) => !term || [v.item_no, v.title, v.category, v.location, v.status].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Asservaten gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((v) => `
      <tr>
        <td><span class="mono">${esc(v.item_no)}</span></td>
        <td><strong>${esc(v.title)}</strong></td>
        <td>${esc(v.category || '–')}</td>
        <td>${esc(v.location || '–')}</td>
        <td><span class="badge ${v.status === 'eingelagert' ? 'badge-green' : 'badge-gray'}">${esc(v.status)}</span></td>
        <td><div class="row-actions">
          ${can('evidence.manage') ? `
            <button type="button" class="icon-action" data-evidence-edit="${v.id}" title="Bearbeiten">${icon('edit')}</button>
            <button type="button" class="icon-action danger" data-evidence-delete="${v.id}" title="Löschen">${icon('trash')}</button>` : '–'}
        </div></td>
      </tr>`).join('');
  }

  $('#evidenceSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderEvidence(); });
  $('#evidenceRefresh')?.addEventListener('click', () => loadEvidence().then(() => toast('Asservaten aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#evidenceNew')?.addEventListener('click', () => openEvidenceForm(null));

  $('#evidenceTableBody')?.addEventListener('click', async (e) => {
    const edit = e.target.closest('[data-evidence-edit]');
    const del = e.target.closest('[data-evidence-delete]');
    if (edit) {
      const item = state.evidence.find((v) => v.id === Number(edit.getAttribute('data-evidence-edit')));
      if (item) openEvidenceForm(item);
    }
    if (del) {
      if (!window.confirm('Asservat wirklich löschen?')) return;
      try {
        await api.deleteEvidence(Number(del.getAttribute('data-evidence-delete')));
        toast('Asservat gelöscht.', { title: 'Gelöscht' });
        await loadEvidence();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openEvidenceForm(item) {
    const form = $('#evidenceForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#evidenceModalTitle').textContent = item ? 'Asservat bearbeiten' : 'Neues Asservat';
    if (item) {
      form.querySelector('[name="itemNo"]').value = item.item_no || '';
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="category"]').value = item.category || '';
      form.querySelector('[name="location"]').value = item.location || '';
      form.querySelector('[name="status"]').value = item.status || 'eingelagert';
      form.querySelector('[name="description"]').value = item.description || '';
    }
    openModal('evidenceModal');
  }

  $('#evidenceForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      itemNo: fd.get('itemNo') || undefined,
      title: fd.get('title'),
      category: fd.get('category'),
      location: fd.get('location'),
      status: fd.get('status'),
      description: fd.get('description')
    };
    try {
      if (id) await api.updateEvidence(Number(id), body);
      else await api.createEvidence(body);
      toast(id ? 'Asservat aktualisiert.' : 'Asservat erstellt.', { title: 'Gespeichert' });
      closeModal('evidenceModal');
      await loadEvidence();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Dokumente ---------- */
  async function loadDocuments() {
    const res = await api.getDocuments();
    state.documents = res.documents || [];
    renderDocuments();
    const sys = $('#sysDocs');
    if (sys) sys.textContent = state.documents.length + ' gespeichert';
  }

  function renderDocuments() {
    const body = $('#documentsTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.documents.filter((d) => !term || [d.ref, d.filename, d.type].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Noch keine Dokumente erzeugt. Führungszeugnis-Anträge erstellen automatisch ein PDF.</td></tr>';
      return;
    }
    body.innerHTML = items.map((d) => `
      <tr>
        <td class="mono">#${d.id}</td>
        <td><span class="mono">${esc(d.ref || '–')}</span></td>
        <td><strong>${esc(d.filename)}</strong></td>
        <td>${bytes(d.size)}</td>
        <td>${dt(d.created_at)}</td>
        <td><button type="button" class="btn btn-ghost btn-sm" data-doc-download="${d.id}" data-doc-name="${esc(d.filename)}">${icon('download')} Download</button></td>
      </tr>`).join('');
  }

  $('#documentsTableBody')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-doc-download]');
    if (!btn) return;
    try {
      await downloadBlob(Number(btn.getAttribute('data-doc-download')), btn.getAttribute('data-doc-name'));
      toast('Dokument heruntergeladen.', { title: 'Download' });
    } catch (err) { toast(err.message || 'Download fehlgeschlagen.', { type: 'error' }); }
  });
  $('#docsRefresh')?.addEventListener('click', () => loadDocuments().then(() => toast('Dokumente aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));

  async function downloadBlob(id, filename) {
    const blob = await api.downloadDocument(id);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'dokument.pdf';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  /* ---------- Benutzer ---------- */
  async function ensureRanks() {
    if (state.ranks.length) return;
    try {
      const res = await api.getRanks();
      state.ranks = res.ranks || [];
    } catch (e) { state.ranks = []; }
  }

  async function loadUsers() {
    const res = await api.getUsers();
    state.users = res.users || [];
    await ensureRanks();
    renderUsers();
  }

  function renderUsers() {
    const body = $('#usersTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.users.filter((u) => !term || [u.username, u.display_name, u.rank_name].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Benutzer gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((u) => `
      <tr>
        <td><strong>${esc(u.username)}</strong></td>
        <td>${esc(u.display_name)}</td>
        <td><span class="badge badge-blue">${esc(u.rank_name)}</span></td>
        <td><span class="badge ${u.active ? 'badge-green' : 'badge-red'}">${u.active ? 'Aktiv' : 'Inaktiv'}</span></td>
        <td>${u.last_login ? dt(u.last_login) : '–'}</td>
        <td><div class="row-actions">
          ${can('users.manage') ? `<button type="button" class="icon-action" data-user-edit="${u.id}" title="Bearbeiten">${icon('edit')}</button>` : '–'}
        </div></td>
      </tr>`).join('');
  }

  $('#userSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderUsers(); });
  $('#usersRefresh')?.addEventListener('click', () => loadUsers().then(() => toast('Benutzer aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#userNew')?.addEventListener('click', async () => { await ensureRanks(); openUserForm(null); });

  $('#usersTableBody')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-user-edit]');
    if (!btn) return;
    const item = state.users.find((u) => u.id === Number(btn.getAttribute('data-user-edit')));
    if (item) { await ensureRanks(); openUserForm(item); }
  });

  function openUserForm(item) {
    const form = $('#userForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#userModalTitle').textContent = item ? 'Benutzer bearbeiten' : 'Neuer Benutzer';
    const select = $('#userRankSelect');
    select.innerHTML = state.ranks.map((r) => `<option value="${r.id}">${esc(r.name)}</option>`).join('');
    if (item) {
      form.querySelector('[name="username"]').value = item.username || '';
      form.querySelector('[name="username"]').disabled = true;
      form.querySelector('[name="displayName"]').value = item.display_name || '';
      form.querySelector('[name="password"]').value = '';
      form.querySelector('[name="password"]').required = false;
      select.value = item.rank_id;
      form.querySelector('[name="active"]').value = item.active ? '1' : '0';
    } else {
      form.querySelector('[name="username"]').disabled = false;
      form.querySelector('[name="password"]').required = true;
    }
    openModal('userModal');
  }

  $('#userForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      username: fd.get('username'),
      displayName: fd.get('displayName'),
      rankId: Number(fd.get('rankId')),
      active: fd.get('active') === '1'
    };
    const password = fd.get('password');
    if (password) body.password = password;
    try {
      if (id) await api.updateUser(Number(id), body);
      else {
        if (!password) { toast('Passwort ist erforderlich.', { type: 'error' }); return; }
        await api.createUser(body);
      }
      toast(id ? 'Benutzer aktualisiert.' : 'Benutzer erstellt.', { title: 'Gespeichert' });
      closeModal('userModal');
      await loadUsers();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Ränge ---------- */
  async function loadRanks() {
    const res = await api.getRanks();
    state.ranks = res.ranks || [];
    try {
      const p = await api.request('/api/permissions');
      state.permissions = p.permissions || [];
    } catch (e) { state.permissions = []; }
    renderRanks();
  }

  function renderRanks() {
    const body = $('#ranksTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.ranks.filter((r) => !term || [r.name, r.description].filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="4">Keine Ränge gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((r) => `
      <tr>
        <td><strong>${esc(r.name)}</strong></td>
        <td>${esc(r.description || '–')}</td>
        <td><span class="badge badge-blue">${(r.permissions || []).length} Rechte</span></td>
        <td><div class="row-actions">
          ${can('ranks.manage') ? `<button type="button" class="icon-action" data-rank-edit="${r.id}" title="Bearbeiten">${icon('edit')}</button>` : '–'}
        </div></td>
      </tr>`).join('');
  }

  $('#ranksRefresh')?.addEventListener('click', () => loadRanks().then(() => toast('Ränge aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#rankNew')?.addEventListener('click', () => openRankForm(null));

  $('#ranksTableBody')?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-rank-edit]');
    if (!btn) return;
    const item = state.ranks.find((r) => r.id === Number(btn.getAttribute('data-rank-edit')));
    if (item) openRankForm(item);
  });

  function openRankForm(item) {
    const form = $('#rankForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#rankModalTitle').textContent = item ? 'Rang bearbeiten' : 'Neuer Rang';
    const selected = new Set(item ? (item.permissions || []) : []);
    const box = $('#rankPermissions');
    box.innerHTML = state.permissions.length
      ? state.permissions.map((p) => `
        <label class="i-checkbox" style="margin:0;font-size:12px">
          <input type="checkbox" name="perm" value="${esc(p.key)}" ${selected.has(p.key) ? 'checked' : ''}>
          <span><strong style="color:var(--i-text)">${esc(p.key)}</strong><br><span style="font-size:11px;color:var(--i-muted-2)">${esc(p.description || '')}</span></span>
        </label>`).join('')
      : '<p class="form-note">Keine Berechtigungen verfügbar.</p>';
    if (item) {
      form.querySelector('[name="name"]').value = item.name || '';
      form.querySelector('[name="description"]').value = item.description || '';
    }
    openModal('rankModal');
  }

  $('#rankForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const perms = $$('input[name="perm"]:checked', form).map((cb) => cb.value);
    const body = {
      name: fd.get('name'),
      description: fd.get('description'),
      permissions: perms
    };
    try {
      if (id) await api.updateRank(Number(id), body);
      else await api.createRank(body);
      toast(id ? 'Rang aktualisiert.' : 'Rang erstellt.', { title: 'Gespeichert' });
      closeModal('rankModal');
      await loadRanks();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ==========================================================================
     AKTENSYSTEM
     ========================================================================== */

  /* ---------- Namensvorschläge aus der ESX-Datenbank ---------- */
  function attachNameSuggestions(input, hiddenSelector, onPick) {
    if (!input) return null;
    const field = input.closest('.i-field') || input.parentElement;
    if (!field) return null;
    field.classList.add('has-suggest');

    const box = document.createElement('div');
    box.className = 'name-suggest';
    field.appendChild(box);

    let timer = null;
    let items = [];
    let active = -1;

    const hidden = () => (hiddenSelector ? document.querySelector(hiddenSelector) : null);
    const close = () => { box.classList.remove('is-open'); active = -1; };

    const choose = (item) => {
      if (!item) return;
      input.value = [item.firstname, item.lastname].filter(Boolean).join(' ');
      const hid = hidden();
      if (hid) hid.value = item.identifier || '';
      close();
      if (onPick) onPick(item);
    };

    const render = (list, term) => {
      items = list;
      if (!list.length) {
        box.innerHTML = `<div class="name-suggest-empty">Keine Person für „${esc(term)}“ gefunden.</div>`;
        box.classList.add('is-open');
        return;
      }
      box.innerHTML = list.slice(0, 8).map((c, i) => `
        <button type="button" class="name-suggest-item${i === active ? ' is-active' : ''}" data-index="${i}">
          <span><strong>${esc(citizenName(c))}</strong>${c.dateofbirth ? ` <small>· ${esc(c.dateofbirth)}</small>` : ''}</span>
          <small>${esc(c.job_label || c.job || '')}</small>
        </button>`).join('');
      box.classList.add('is-open');
    };

    const search = async () => {
      const term = input.value.trim();
      if (term.length < 2) { close(); return; }
      try {
        const res = await api.searchCitizens(term, '');
        render(res.citizens || [], term);
      } catch (e) { close(); }
    };

    input.addEventListener('input', () => {
      const hid = hidden();
      if (hid) hid.value = '';
      clearTimeout(timer);
      active = -1;
      timer = setTimeout(search, 220);
    });

    input.addEventListener('focus', () => {
      if (input.value.trim().length >= 2) search();
    });

    input.addEventListener('keydown', (e) => {
      if (!box.classList.contains('is-open')) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        active = Math.min(active + 1, items.length - 1);
        render(items, input.value.trim());
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        active = Math.max(active - 1, 0);
        render(items, input.value.trim());
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (active >= 0 && items[active]) choose(items[active]);
        else if (items.length === 1) choose(items[0]);
        else close();
      } else if (e.key === 'Escape') {
        close();
      }
    });

    box.addEventListener('mousedown', (e) => {
      const btn = e.target.closest('[data-index]');
      if (!btn) return;
      e.preventDefault();
      choose(items[Number(btn.getAttribute('data-index'))]);
    });

    // Fallback: bei eindeutigem Namen automatisch den Identifier ergänzen
    input.addEventListener('blur', () => {
      setTimeout(async () => {
        close();
        if (!hiddenSelector) return;
        const hid = hidden();
        if (!hid || hid.value) return;
        const term = input.value.trim();
        if (term.length < 3) return;
        try {
          const res = await api.searchCitizens(term, '');
          const list = res.citizens || [];
          const exact = list.filter((c) => citizenName(c).toLowerCase() === term.toLowerCase());
          if (exact.length === 1) choose(exact[0]);
          else if (list.length === 1) choose(list[0]);
        } catch (e) { /* ignore */ }
      }, 200);
    });

    return box;
  }

  attachNameSuggestions($('#weaponOwner'), '#weaponOwnerId');
  attachNameSuggestions($('#activityCitizen'), '#activityCitizenId');
  attachNameSuggestions($('#citizenQuery'), null, () => {
    const form = $('#citizenSearchForm');
    if (form) form.requestSubmit();
  });

  /* ---------- Bürgerregister (ESX) ---------- */
  async function initCitizens() {
    if (state.citizens.length) { renderCitizens(); return; }
    try {
      const res = await api.searchCitizens('', '');
      state.citizens = res.citizens || [];
      renderCitizens();
    } catch (err) {
      toast(err.message || 'Bürgerregister konnte nicht geladen werden.', { type: 'error' });
      renderCitizens();
    }
  }

  function citizenName(c) {
    return [c.firstname, c.lastname].filter(Boolean).join(' ').trim() || 'Unbekannt';
  }

  function renderCitizens() {
    const body = $('#citizenResults');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.citizens.filter((c) => !term || [citizenName(c), c.identifier, c.dateofbirth, c.job_label, c.job, c.phone_number]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    const count = $('#citizenCount');
    if (count) count.textContent = items.length + ' Treffer';
    const summary = $('#citizenSummary');
    if (summary) {
      const open = items.filter((c) => Number(c.open_tickets || 0) > 0).length;
      const wanted = items.filter((c) => c.wanted).length;
      summary.innerHTML = `
        <span class="summary-chip">${items.length} Personen</span>
        <span class="summary-chip is-gold">${open} mit offenen Tickets</span>
        <span class="summary-chip is-red">${wanted} Fahndungen</span>`;
    }
    if (!items.length) {
      body.innerHTML = '<div class="empty-state-panel">Keine Personen gefunden.</div>';
      return;
    }
    body.innerHTML = items.map((c) => {
      const name = citizenName(c);
      const openTickets = Number(c.open_tickets || 0);
      const wantedTitle = c.wanted_cases && c.wanted_cases.length ? c.wanted_cases[0].title : '';
      const refs = (c.open_ticket_refs || []).slice(0, 3).join(', ');
      return `<article class="citizen-card">
        <div class="citizen-card-top">
          <span class="citizen-avatar">${esc(initials(name))}</span>
          <div class="citizen-card-id">
            <strong>${esc(name)}</strong>
            <small>${esc(c.job_label || c.job || 'Keine Berufsangabe')}${c.dateofbirth ? ' · ' + esc(c.dateofbirth) : ''}</small>
          </div>
          <button type="button" class="btn btn-ghost btn-sm" data-citizen="${esc(c.identifier || '')}">${icon('folder-open')} Akte</button>
        </div>
        <div class="citizen-badges">
          ${c.wanted
            ? `<span class="badge badge-red" title="${esc(wantedTitle)}">${icon('alert')} Wird gefahndet</span>`
            : `<span class="badge badge-green">${icon('check')} Nicht gefahndet</span>`}
          ${openTickets
            ? `<span class="badge badge-gold" title="${esc(refs)}">${icon('message')} ${openTickets} offene${openTickets === 1 ? 's' : ''} Ticket${openTickets === 1 ? '' : 's'}</span>`
            : `<span class="badge badge-blue">${icon('check')} Keine offenen Tickets</span>`}
        </div>
        <div class="citizen-card-meta">
          <span>${icon('phone')} ${esc(c.phone_number || 'Keine Telefonnummer')}</span>
          <span class="mono">${esc(c.identifier || '')}</span>
        </div>
      </article>`;
    }).join('');
  }

  $('#citizenResults')?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-citizen]');
    if (btn) openCitizen(btn.getAttribute('data-citizen'));
  });

  $('#citizenSearchForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const q = $('#citizenQuery')?.value.trim() || '';
    const birth = $('#citizenBirth')?.value || '';
    try {
      const res = await api.searchCitizens(q, birth);
      state.citizens = res.citizens || [];
      renderCitizens();
      toast(state.citizens.length + ' Treffer im Bürgerregister.', { title: 'Suche abgeschlossen' });
    } catch (err) {
      toast(err.message || 'Suche fehlgeschlagen.', { type: 'error' });
    }
  });

  async function openCitizen(identifier) {
    if (!identifier) return;
    try {
      const res = await api.getCitizen(identifier);
      const c = res.character || res.citizen || {};
      const licenses = res.licenses || [];
      const vehicles = res.vehicles || [];
      $('#citizenModalTitle').textContent = citizenName(c);
      $('#citizenModalSub').textContent = c.identifier || identifier;
      const openTickets = res.openTickets || [];
      const wantedCases = res.wantedCases || [];
      $('#citizenModalBody').innerHTML = `
        <div class="citizen-status-banner">
          ${c.wanted
            ? `<span class="badge badge-red">${icon('alert')} Wird gefahndet</span>`
            : `<span class="badge badge-green">${icon('check')} Nicht gefahndet</span>`}
          ${openTickets.length
            ? `<span class="badge badge-gold">${icon('message')} ${openTickets.length} offene${openTickets.length === 1 ? 's' : ''} Ticket${openTickets.length === 1 ? '' : 's'}</span>`
            : `<span class="badge badge-blue">${icon('check')} Keine offenen Tickets</span>`}
        </div>
        <div class="detail-list">
          <div class="detail-row"><dt>Name</dt><dd>${esc(citizenName(c))}</dd></div>
          <div class="detail-row"><dt>Identifikator</dt><dd class="mono">${esc(c.identifier || identifier)}</dd></div>
          <div class="detail-row"><dt>Geburtsdatum</dt><dd>${esc(c.dateofbirth || '–')}</dd></div>
          <div class="detail-row"><dt>Geschlecht</dt><dd>${c.sex === 'm' ? 'Männlich' : c.sex === 'f' ? 'Weiblich' : esc(c.sex || '–')}</dd></div>
          <div class="detail-row"><dt>Größe</dt><dd>${c.height ? esc(c.height) + ' cm' : '–'}</dd></div>
          <div class="detail-row"><dt>Beruf</dt><dd>${esc(c.job_label || c.job || '–')}${c.job_grade ? ' · Grad ' + esc(c.job_grade) : ''}</dd></div>
          <div class="detail-row"><dt>Telefon</dt><dd>${esc(c.phone_number || '–')}</dd></div>
          <div class="detail-row"><dt>Nationalität</dt><dd>${esc(c.nationality || '–')}</dd></div>
          <div class="detail-row"><dt>Status</dt><dd>${Number(c.disabled) === 1 ? '<span class="badge badge-red">Gesperrt</span>' : '<span class="badge badge-green">Aktiv</span>'}</dd></div>
          <div class="detail-row"><dt>Zuletzt gesehen</dt><dd>${c.last_seen ? dt(c.last_seen) : '–'}</dd></div>
          <div class="detail-row"><dt>Spielzeit</dt><dd>${c.playtime ? Math.round(Number(c.playtime) / 60) + ' Stunden' : '–'}</dd></div>
        </div>

        <h3 class="record-subtitle">Offene Tickets</h3>
        ${openTickets.length
          ? `<div class="citizen-ticket-list">${openTickets.map((t) => `<div class="citizen-ticket-row"><strong class="mono">${esc(t.ref)}</strong><span>${esc(TYPE_LABEL[t.type] || t.type)}</span>${statusBadge(t.status)}</div>`).join('')}</div>`
          : '<p class="form-note">Keine offenen Tickets für diesen Namen gefunden.</p>'}

        <h3 class="record-subtitle">Fahndungen</h3>
        ${wantedCases.length
          ? `<div class="citizen-ticket-list">${wantedCases.map((w) => `<div class="citizen-ticket-row"><strong class="mono">${esc(w.caseNo)}</strong><span>${esc(w.title || '')}</span></div>`).join('')}</div>`
          : '<p class="form-note">Keine aktive Fahndung für diesen Namen gefunden.</p>'}

        <h3 class="record-subtitle">Lizenzen</h3>
        ${licenses.length
          ? `<div class="chip-list">${licenses.map((l) => `<span class="badge badge-blue">${esc(l.label || l.type)}</span>`).join('')}</div>`
          : '<p class="form-note">Keine Lizenzen hinterlegt.</p>'}

        <h3 class="record-subtitle">Fahrzeuge</h3>
        ${vehicles.length
          ? `<div class="table-wrap"><table class="i-table" style="min-width:0">
               <thead><tr><th>Kennzeichen</th><th>Modell</th><th>Typ</th><th>Status</th></tr></thead>
               <tbody>${vehicles.map((v) => `<tr>
                 <td class="mono">${esc(v.plate)}</td>
                 <td>${esc(v.model)}</td>
                 <td>${esc(v.type)}</td>
                 <td>${v.stored ? '<span class="badge badge-green">Eingelagert</span>' : '<span class="badge badge-gold">Unterwegs</span>'}</td>
               </tr>`).join('')}</tbody>
             </table></div>`
          : '<p class="form-note">Keine Fahrzeuge registriert.</p>'}`;
      openModal('citizenModal');
    } catch (err) {
      toast(err.message || 'Bürgerakte konnte nicht geladen werden.', { type: 'error' });
    }
  }

  /* ---------- Fahrzeugregister (ESX) ---------- */
  async function initVehicles() {
    if (state.vehicles.length) { renderVehicles(); return; }
    try {
      const res = await api.searchVehicles('');
      state.vehicles = res.vehicles || [];
      renderVehicles();
    } catch (err) {
      toast(err.message || 'Fahrzeugregister konnte nicht geladen werden.', { type: 'error' });
      renderVehicles();
    }
  }

  function renderVehicles() {
    const body = $('#vehicleResults');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.vehicles.filter((v) => !term || [v.plate, v.model, v.ownerName, v.type].filter(Boolean).join(' ').toLowerCase().includes(term));
    const count = $('#vehicleCount');
    if (count) count.textContent = items.length + ' Fahrzeuge';
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Fahrzeuge gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((v) => `
      <tr>
        <td><span class="mono">${esc(v.plate)}</span></td>
        <td><strong>${esc(v.model)}</strong>${v.label ? `<br><span style="font-size:11px;color:var(--i-muted-2)">${esc(v.label)}</span>` : ''}</td>
        <td>${esc(v.ownerName)}</td>
        <td>${esc(v.type)}</td>
        <td>${v.stored ? '<span class="badge badge-green">Eingelagert</span>' : '<span class="badge badge-gold">Unterwegs</span>'}</td>
        <td><button type="button" class="btn btn-ghost btn-sm" data-vehicle="${esc(v.plate)}">${icon('search')} Akte</button></td>
      </tr>`).join('');
  }

  $('#vehicleResults')?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-vehicle]');
    if (btn) openVehicle(btn.getAttribute('data-vehicle'));
  });

  $('#vehicleSearchForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const q = $('#vehicleQuery')?.value.trim() || '';
    try {
      const res = await api.searchVehicles(q);
      state.vehicles = res.vehicles || [];
      renderVehicles();
      toast(state.vehicles.length + ' Fahrzeuge gefunden.', { title: 'Suche abgeschlossen' });
    } catch (err) {
      toast(err.message || 'Suche fehlgeschlagen.', { type: 'error' });
    }
  });

  async function openVehicle(plate) {
    if (!plate) return;
    try {
      const res = await api.getVehicle(plate);
      const v = res.vehicle || {};
      $('#vehicleModalTitle').textContent = 'Fahrzeug ' + (v.plate || plate);
      $('#vehicleModalSub').textContent = v.model || '';
      $('#vehicleModalBody').innerHTML = `
        <div class="detail-list">
          <div class="detail-row"><dt>Kennzeichen</dt><dd class="mono">${esc(v.plate || plate)}</dd></div>
          <div class="detail-row"><dt>Modell</dt><dd>${esc(v.model || '–')}</dd></div>
          <div class="detail-row"><dt>Label</dt><dd>${esc(v.label || '–')}</dd></div>
          <div class="detail-row"><dt>Halter</dt><dd>${esc(v.ownerName || '–')}</dd></div>
          <div class="detail-row"><dt>Halter-ID</dt><dd class="mono">${esc(v.ownerIdentifier || '–')}</dd></div>
          <div class="detail-row"><dt>Typ</dt><dd>${esc(v.type || '–')}</dd></div>
          <div class="detail-row"><dt>Job</dt><dd>${esc(v.job || '–')}</dd></div>
          <div class="detail-row"><dt>Status</dt><dd>${v.stored ? '<span class="badge badge-green">Eingelagert</span>' : '<span class="badge badge-gold">Unterwegs</span>'}</dd></div>
          <div class="detail-row"><dt>Kilometerstand</dt><dd>${esc(Number(v.mileage || 0).toFixed(0))} km</dd></div>
          <div class="detail-row"><dt>Favorit</dt><dd>${v.favourite === '1' ? 'Ja' : 'Nein'}</dd></div>
        </div>
        <details class="record-details">
          <summary>Technische Fahrzeugdaten (JSON)</summary>
          <pre>${esc(JSON.stringify(v.raw || {}, null, 2))}</pre>
        </details>`;
      openModal('vehicleModal');
    } catch (err) {
      toast(err.message || 'Fahrzeugakte konnte nicht geladen werden.', { type: 'error' });
    }
  }

  /* ---------- Waffenregister (lokale DB) ---------- */
  const WEAPON_STATUS = {
    gueltig: ['badge-green', 'Gültig'],
    abgelaufen: ['badge-gold', 'Abgelaufen'],
    eingezogen: ['badge-red', 'Eingezogen']
  };

  async function loadWeapons() {
    const params = {};
    const q = $('#weaponSearch')?.value.trim();
    const type = $('#weaponTypeFilter')?.value;
    if (q) params.q = q;
    if (type) params.type = type;
    const res = await api.getWeapons(params);
    state.weapons = res.weapons || [];
    renderWeapons();
  }

  function renderWeapons() {
    const body = $('#weaponsTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.weapons.filter((w) => !term || [w.owner_name, w.weapon_type, w.model, w.serial_number, w.license_number]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="6">Keine Waffen registriert.</td></tr>';
      return;
    }
    body.innerHTML = items.map((w) => {
      const st = WEAPON_STATUS[w.status] || ['badge-gray', w.status || '–'];
      return `
        <tr>
          <td><strong>${esc(w.owner_name)}</strong>${w.owner_identifier ? `<br><span class="mono" style="font-size:10.5px">${esc(w.owner_identifier)}</span>` : ''}</td>
          <td>${esc(w.weapon_type)}${w.model ? `<br><span style="font-size:11px;color:var(--i-muted-2)">${esc(w.model)}</span>` : ''}</td>
          <td class="mono">${esc(w.serial_number || '–')}</td>
          <td>${esc(w.license_number || '–')}</td>
          <td><span class="badge ${st[0]}">${esc(st[1])}</span></td>
          <td><div class="row-actions">
            ${can('weapons.manage') ? `
              <button type="button" class="icon-action" data-weapon-edit="${w.id}" title="Bearbeiten">${icon('edit')}</button>
              <button type="button" class="icon-action danger" data-weapon-delete="${w.id}" title="Löschen">${icon('trash')}</button>` : '–'}
          </div></td>
        </tr>`;
    }).join('');
  }

  $('#weaponSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderWeapons(); });
  $('#weaponTypeFilter')?.addEventListener('change', () => loadWeapons().catch((err) => toast(err.message, { type: 'error' })));
  $('#weaponsRefresh')?.addEventListener('click', () => loadWeapons().then(() => toast('Waffenregister aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#weaponNew')?.addEventListener('click', () => openWeaponForm(null));

  $('#weaponsTableBody')?.addEventListener('click', async (e) => {
    const edit = e.target.closest('[data-weapon-edit]');
    const del = e.target.closest('[data-weapon-delete]');
    if (edit) {
      const item = state.weapons.find((w) => w.id === Number(edit.getAttribute('data-weapon-edit')));
      if (item) openWeaponForm(item);
    }
    if (del) {
      if (!window.confirm('Waffe wirklich löschen?')) return;
      try {
        await api.deleteWeapon(Number(del.getAttribute('data-weapon-delete')));
        toast('Waffe gelöscht.', { title: 'Gelöscht' });
        await loadWeapons();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openWeaponForm(item) {
    const form = $('#weaponForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#weaponModalTitle').textContent = item ? 'Waffe bearbeiten' : 'Neue Waffe registrieren';
    if (item) {
      form.querySelector('[name="ownerName"]').value = item.owner_name || '';
      form.querySelector('[name="ownerIdentifier"]').value = item.owner_identifier || '';
      form.querySelector('[name="weaponType"]').value = item.weapon_type || 'Pistole';
      form.querySelector('[name="model"]').value = item.model || '';
      form.querySelector('[name="serialNumber"]').value = item.serial_number || '';
      form.querySelector('[name="licenseNumber"]').value = item.license_number || '';
      form.querySelector('[name="registeredAt"]').value = item.registered_at ? String(item.registered_at).slice(0, 10) : '';
      form.querySelector('[name="status"]').value = item.status || 'gueltig';
      form.querySelector('[name="notes"]').value = item.notes || '';
    }
    openModal('weaponModal');
  }

  $('#weaponForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      ownerName: fd.get('ownerName'),
      ownerIdentifier: fd.get('ownerIdentifier') || undefined,
      weaponType: fd.get('weaponType'),
      model: fd.get('model'),
      serialNumber: fd.get('serialNumber'),
      licenseNumber: fd.get('licenseNumber'),
      registeredAt: fd.get('registeredAt') || null,
      status: fd.get('status'),
      notes: fd.get('notes')
    };
    try {
      if (id) await api.updateWeapon(Number(id), body);
      else await api.createWeapon(body);
      toast(id ? 'Waffe aktualisiert.' : 'Waffe registriert.', { title: 'Gespeichert' });
      closeModal('weaponModal');
      await loadWeapons();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Tätigkeitsberichte ---------- */
  const ACTIVITY_TYPES = {
    streife: ['Streife', 'badge-blue'],
    verkehrskontrolle: ['Verkehrskontrolle', 'badge-gold'],
    durchsuchung: ['Durchsuchung', 'badge-red'],
    einsatz: ['Einsatz', 'badge-blue'],
    vernehmung: ['Vernehmung', 'badge-gray'],
    sonstiges: ['Sonstiges', 'badge-gray']
  };

  async function loadActivity() {
    const params = {};
    const q = $('#activitySearch')?.value.trim();
    const type = $('#activityTypeFilter')?.value;
    if (q) params.q = q;
    if (type) params.type = type;
    const res = await api.getActivityReports(params);
    state.activity = res.reports || [];
    renderActivity();
  }

  function renderActivity() {
    const body = $('#activityTableBody');
    if (!body) return;
    const term = state.filter.toLowerCase();
    const items = state.activity.filter((r) => !term || [r.ref, r.title, r.officer_name, r.citizen_name, r.vehicle_plate, r.location, r.type]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="7">Keine Tätigkeitsberichte vorhanden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((r) => {
      const t = ACTIVITY_TYPES[r.type] || ['Sonstiges', 'badge-gray'];
      return `
        <tr>
          <td><span class="mono">${esc(r.ref)}</span></td>
          <td><span class="badge ${t[1]}">${esc(t[0])}</span></td>
          <td><strong>${esc(r.title)}</strong>${r.location ? `<br><span style="font-size:11px;color:var(--i-muted-2)">${esc(r.location)}</span>` : ''}</td>
          <td>${esc(r.officer_name || '–')}</td>
          <td>${esc(r.citizen_name || '–')}${r.vehicle_plate ? `<br><span class="mono" style="font-size:10.5px">${esc(r.vehicle_plate)}</span>` : ''}</td>
          <td>${dt(r.occurred_at)}</td>
          <td><div class="row-actions">
            ${can('activity.manage') ? `
              <button type="button" class="icon-action" data-activity-edit="${r.id}" title="Bearbeiten">${icon('edit')}</button>
              <button type="button" class="icon-action danger" data-activity-delete="${r.id}" title="Löschen">${icon('trash')}</button>` : '–'}
          </div></td>
        </tr>`;
    }).join('');
  }

  $('#activitySearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderActivity(); });
  $('#activityTypeFilter')?.addEventListener('change', () => loadActivity().catch((err) => toast(err.message, { type: 'error' })));
  $('#activityRefresh')?.addEventListener('click', () => loadActivity().then(() => toast('Tätigkeitsberichte aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#activityNew')?.addEventListener('click', () => openActivityForm(null));

  $('#activityTableBody')?.addEventListener('click', async (e) => {
    const edit = e.target.closest('[data-activity-edit]');
    const del = e.target.closest('[data-activity-delete]');
    if (edit) {
      const item = state.activity.find((r) => r.id === Number(edit.getAttribute('data-activity-edit')));
      if (item) openActivityForm(item);
    }
    if (del) {
      if (!window.confirm('Bericht wirklich löschen?')) return;
      try {
        await api.deleteActivityReport(Number(del.getAttribute('data-activity-delete')));
        toast('Bericht gelöscht.', { title: 'Gelöscht' });
        await loadActivity();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function toLocalInput(value) {
    if (!value) return '';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '';
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function openActivityForm(item) {
    const form = $('#activityForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#activityModalTitle').textContent = item ? 'Tätigkeitsbericht bearbeiten' : 'Neuer Tätigkeitsbericht';
    if (item) {
      form.querySelector('[name="type"]').value = item.type || 'sonstiges';
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="occurredAt"]').value = toLocalInput(item.occurred_at);
      form.querySelector('[name="citizenName"]').value = item.citizen_name || '';
      form.querySelector('[name="citizenIdentifier"]').value = item.citizen_identifier || '';
      form.querySelector('[name="vehiclePlate"]').value = item.vehicle_plate || '';
      form.querySelector('[name="location"]').value = item.location || '';
      form.querySelector('[name="description"]').value = item.description || '';
      form.querySelector('[name="measures"]').value = item.measures || '';
      form.querySelector('[name="outcome"]').value = item.outcome || '';
    } else {
      form.querySelector('[name="occurredAt"]').value = toLocalInput(new Date());
    }
    openModal('activityModal');
  }

  $('#activityForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      type: fd.get('type'),
      title: fd.get('title'),
      occurredAt: fd.get('occurredAt') ? String(fd.get('occurredAt')).replace('T', ' ') + ':00' : null,
      citizenName: fd.get('citizenName'),
      citizenIdentifier: fd.get('citizenIdentifier'),
      vehiclePlate: fd.get('vehiclePlate'),
      location: fd.get('location'),
      description: fd.get('description'),
      measures: fd.get('measures'),
      outcome: fd.get('outcome')
    };
    try {
      if (id) await api.updateActivityReport(Number(id), body);
      else {
        const res = await api.createActivityReport(body);
        toast('Bericht ' + (res.ref || '') + ' erstellt.', { title: 'Gespeichert' });
      }
      if (id) toast('Bericht aktualisiert.', { title: 'Gespeichert' });
      closeModal('activityModal');
      await loadActivity();
    } catch (err) { toast(err.message || 'Speichern fehlgeschlagen.', { type: 'error' }); }
  });

  /* ---------- Gesetzbuch ---------- */
  async function loadRecruitment() {
    const res = await api.getRecruitmentPhases();
    state.recruitment = res.phases || [];
    renderRecruitment();
  }

  function renderRecruitment() {
    const list = $('#recruitmentPhaseCards');
    if (!list) return;
    if (!state.recruitment.length) {
      list.innerHTML = '<div class="empty-state-panel">Keine Bewerbungsbereiche hinterlegt.</div>';
      return;
    }
    list.innerHTML = state.recruitment.map((p) => `
      <article class="recruit-card ${p.isOpen ? 'is-open' : 'is-closed'}">
        <div class="recruit-card-head">
          <span class="badge ${p.isOpen ? 'badge-green' : 'badge-red'}">${p.isOpen ? 'Offen' : 'Geschlossen'}</span>
          <h3>${esc(p.label)}</h3>
          <p>${p.isOpen ? 'Bewerbungen für diesen Bereich sind möglich.' : 'Für diesen Bereich werden derzeit keine Bewerbungen angenommen.'}</p>
        </div>
        <div class="recruit-card-actions">
          <span class="form-note">Sichtbar auf Startseite und in der Bereichsauswahl</span>
          <button type="button" class="btn ${p.isOpen ? 'btn-ghost' : 'btn-primary'} btn-sm" data-recruitment-toggle="${esc(p.key)}" data-open="${p.isOpen ? '0' : '1'}">
            ${p.isOpen ? 'Phase schließen' : 'Phase öffnen'}
          </button>
        </div>
      </article>`).join('');
  }

  $('#recruitmentPhaseCards')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-recruitment-toggle]');
    if (!btn) return;
    const key = btn.getAttribute('data-recruitment-toggle');
    const open = btn.getAttribute('data-open') === '1';
    btn.disabled = true;
    try {
      await api.updateRecruitmentPhase(key, { isOpen: open });
      await loadRecruitment();
      toast(open ? 'Bewerbungsphase geöffnet.' : 'Bewerbungsphase geschlossen.', { title: 'Gespeichert' });
    } catch (err) {
      toast(err.message || 'Bewerbungsphase konnte nicht geändert werden.', { type: 'error' });
    } finally {
      btn.disabled = false;
    }
  });

  /* ---------- Bewerbungen / Personal ---------- */
  async function loadHr() {
    const q = $('#hrSearch')?.value.trim() || '';
    const res = await api.getHrApplications(q);
    state.hrApplications = res.applications || [];
    state.hrSummary = res.summary || null;
    renderHr();
  }

  function renderHr() {
    const body = $('#hrTableBody');
    if (!body) return;
    const summary = state.hrSummary || {};
    const summaryBox = $('#hrSummary');
    if (summaryBox) {
      summaryBox.innerHTML = `
        <span class="summary-chip">${Number(summary.total || 0)} Bewerbungen</span>
        <span class="summary-chip is-gold">${Number(summary.open || 0)} offen</span>
        <span class="summary-chip is-green">${Number(summary.tested || 0)} getestet</span>
        <span class="summary-chip is-red">${Number(summary.passed || 0)} bestanden</span>`;
    }
    const badge = $('#hrCountBadge');
    if (badge) badge.textContent = state.hrApplications.length + ' Bewerbungen';
    const term = state.filter.toLowerCase();
    const items = state.hrApplications.filter((a) => {
      if (!term) return true;
      const p = parsePayload(a);
      return [a.ref, a.applicant_name, a.applicant_email, p.path, p.first, p.last].filter(Boolean).join(' ').toLowerCase().includes(term);
    });
    if (!items.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="8">Keine Bewerbungen gefunden.</td></tr>';
      return;
    }
    body.innerHTML = items.map((a) => {
      const p = parsePayload(a);
      const test = a.test_score != null
        ? `<span class="badge ${Number(a.test_passed) ? 'badge-green' : 'badge-red'}">${esc(a.test_score)}%</span>`
        : '<span class="badge badge-gold">Offen</span>';
      return `
        <tr>
          <td><span class="mono">${esc(a.ref)}</span></td>
          <td><strong>${esc(a.applicant_name || '–')}</strong><small class="ticket-citizen-tag">${esc(a.applicant_email || '')}</small></td>
          <td>${esc(p.path || '–')}</td>
          <td>${day(a.created_at)}</td>
          <td><span class="badge badge-blue">${Number(a.upload_count || 0)} Dateien</span></td>
          <td>${test}${a.test_title ? `<small class="ticket-citizen-tag">${esc(a.test_title)}</small>` : ''}</td>
          <td>${statusBadge(a.status)}</td>
          <td><button type="button" class="btn btn-ghost btn-sm" data-hr-view="${a.id}">${icon('eye')} Akte</button></td>
        </tr>`;
    }).join('');
  }

  $('#hrSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderHr(); });
  $('#hrRefresh')?.addEventListener('click', () => loadHr().then(() => toast('Bewerbungen aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#hrTableBody')?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-hr-view]');
    if (btn) openApplication(Number(btn.getAttribute('data-hr-view')));
  });

  /* ---------- Ausbildung ---------- */
  async function loadTraining() {
    const [trainingsRes, testsRes] = await Promise.all([api.getTrainings(), api.getTrainingTests()]);
    state.trainings = trainingsRes.trainings || [];
    state.trainingTests = testsRes.tests || [];
    renderTraining();
  }

  function renderTraining() {
    const term = state.filter.toLowerCase();
    const trainingBody = $('#trainingTableBody');
    const testsBody = $('#trainingTestsBody');
    if (trainingBody) {
      const items = state.trainings.filter((t) => !term || [t.title, t.description, t.status].filter(Boolean).join(' ').toLowerCase().includes(term));
      const badge = $('#trainingCountBadge');
      if (badge) badge.textContent = items.length + ' Ausbildungen';
      trainingBody.innerHTML = items.length ? items.map((t) => `
        <tr>
          <td><strong>${esc(t.title)}</strong>${t.description ? `<small class="ticket-citizen-tag">${esc(t.description).slice(0, 90)}</small>` : ''}</td>
          <td>${t.start_date ? day(t.start_date) : '–'}${t.end_date ? ' – ' + day(t.end_date) : ''}</td>
          <td>${statusBadge(t.status === 'laufend' ? 'in_bearbeitung' : t.status === 'abgeschlossen' ? 'abgeschlossen' : 'eingegangen')}<small class="ticket-citizen-tag">${esc(t.status)}</small></td>
          <td><span class="badge badge-blue">${Number(t.document_count || 0)}</span></td>
          <td><span class="badge badge-gold">${Number(t.test_count || 0)}</span></td>
          <td><div class="ticket-row-actions">
            <button type="button" class="btn btn-ghost btn-sm" data-training-view="${t.id}">${icon('eye')} Öffnen</button>
            ${can('training.manage') ? `<button type="button" class="icon-action" data-training-edit="${t.id}" title="Bearbeiten">${icon('edit')}</button><button type="button" class="icon-action danger" data-training-delete="${t.id}" title="Löschen">${icon('trash')}</button>` : ''}
          </div></td>
        </tr>`).join('') : '<tr class="empty-row"><td colspan="6">Keine Ausbildungen angelegt.</td></tr>';
    }
    if (testsBody) {
      const items = state.trainingTests.filter((t) => !term || [t.title, t.training_title, t.public_code].filter(Boolean).join(' ').toLowerCase().includes(term));
      const badge = $('#trainingTestCountBadge');
      if (badge) badge.textContent = items.length + ' Tests';
      testsBody.innerHTML = items.length ? items.map((t) => `
        <tr>
          <td><strong>${esc(t.title)}</strong><small class="ticket-citizen-tag">${esc(t.training_title || 'Keine Ausbildung')}</small></td>
          <td><button type="button" class="btn btn-ghost btn-sm" data-test-copy="${esc(t.public_code)}">${icon('copy')} ${esc(t.public_code)}</button></td>
          <td><span class="badge badge-blue">${Number(t.question_count || 0)}</span></td>
          <td><span class="badge ${Number(t.passed_count || 0) ? 'badge-green' : 'badge-gold'}">${Number(t.passed_count || 0)} / ${Number(t.result_count || 0)}</span></td>
          <td><div class="ticket-row-actions">
            <button type="button" class="btn btn-ghost btn-sm" data-test-view="${t.id}">${icon('eye')} Ergebnisse</button>
            ${can('training.manage') ? `<button type="button" class="icon-action" data-test-edit="${t.id}" title="Bearbeiten">${icon('edit')}</button><button type="button" class="icon-action danger" data-test-delete="${t.id}" title="Löschen">${icon('trash')}</button>` : ''}
          </div></td>
        </tr>`).join('') : '<tr class="empty-row"><td colspan="5">Keine Tests angelegt.</td></tr>';
    }
  }

  $('#trainingSearch')?.addEventListener('input', (e) => { state.filter = e.target.value; renderTraining(); });
  $('#trainingRefresh')?.addEventListener('click', () => loadTraining().then(() => toast('Ausbildung aktualisiert.')).catch((err) => toast(err.message, { type: 'error' })));
  $('#trainingNew')?.addEventListener('click', () => openTrainingForm(null));
  $('#trainingTestNew')?.addEventListener('click', () => openTestForm(null));

  $('#trainingTableBody')?.addEventListener('click', async (e) => {
    const view = e.target.closest('[data-training-view]');
    const edit = e.target.closest('[data-training-edit]');
    const del = e.target.closest('[data-training-delete]');
    if (view) openTrainingDetail(Number(view.getAttribute('data-training-view')));
    if (edit) {
      const item = state.trainings.find((t) => Number(t.id) === Number(edit.getAttribute('data-training-edit')));
      if (item) openTrainingForm(item);
    }
    if (del) {
      if (!window.confirm('Ausbildung wirklich löschen?')) return;
      try {
        await api.deleteTraining(Number(del.getAttribute('data-training-delete')));
        toast('Ausbildung gelöscht.', { title: 'Gelöscht' });
        await loadTraining();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  $('#trainingTestsBody')?.addEventListener('click', async (e) => {
    const view = e.target.closest('[data-test-view]');
    const edit = e.target.closest('[data-test-edit]');
    const del = e.target.closest('[data-test-delete]');
    const copy = e.target.closest('[data-test-copy]');
    if (view) openTestDetail(Number(view.getAttribute('data-test-view')));
    if (edit) openTestForm(Number(edit.getAttribute('data-test-edit')));
    if (copy) {
      const url = window.location.origin + '/bewerber-test.html?code=' + encodeURIComponent(copy.getAttribute('data-test-copy'));
      try {
        await navigator.clipboard.writeText(url);
        toast('Test-Link kopiert.', { title: 'Kopiert' });
      } catch (err) {
        window.prompt('Test-Link:', url);
      }
    }
    if (del) {
      if (!window.confirm('Test wirklich löschen?')) return;
      try {
        await api.deleteTrainingTest(Number(del.getAttribute('data-test-delete')));
        toast('Test gelöscht.', { title: 'Gelöscht' });
        await loadTraining();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openTrainingForm(item) {
    const form = $('#trainingForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#trainingFormTitle').textContent = item ? 'Ausbildung bearbeiten' : 'Neue Ausbildung';
    if (item) {
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="description"]').value = item.description || '';
      form.querySelector('[name="startDate"]').value = item.start_date ? String(item.start_date).slice(0, 10) : '';
      form.querySelector('[name="endDate"]').value = item.end_date ? String(item.end_date).slice(0, 10) : '';
      form.querySelector('[name="status"]').value = item.status || 'geplant';
    }
    openModal('trainingFormModal');
  }

  $('#trainingForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      title: fd.get('title'),
      description: fd.get('description'),
      startDate: fd.get('startDate') || null,
      endDate: fd.get('endDate') || null,
      status: fd.get('status')
    };
    try {
      if (id) await api.updateTraining(Number(id), body);
      else await api.createTraining(body);
      toast(id ? 'Ausbildung aktualisiert.' : 'Ausbildung erstellt.', { title: 'Gespeichert' });
      closeModal('trainingFormModal');
      await loadTraining();
    } catch (err) { toast(err.message || 'Ausbildung konnte nicht gespeichert werden.', { type: 'error' }); }
  });

  async function openTrainingDetail(id) {
    try {
      const res = await api.getTraining(id);
      const t = res.training || {};
      const docs = res.documents || [];
      const tests = res.tests || [];
      $('#trainingDetailTitle').textContent = t.title || 'Ausbildung';
      $('#trainingDetailSub').textContent = `${t.start_date ? day(t.start_date) : '–'} – ${t.end_date ? day(t.end_date) : 'offen'}`;
      $('#trainingDetailBody').innerHTML = `
        <div class="detail-list">
          <div class="detail-row"><dt>Status</dt><dd>${esc(t.status || '–')}</dd></div>
          <div class="detail-row"><dt>Beschreibung</dt><dd>${esc(t.description || '–')}</dd></div>
        </div>
        <h3 class="record-subtitle">Ausbildungsunterlagen</h3>
        <div class="upload-list">${docs.length ? docs.map((d) => `<div class="upload-row"><span class="upload-icon">${icon('file')}</span><span class="upload-meta"><strong>${esc(d.title)}</strong><small>${esc(d.filename)} · ${Math.max(1, Math.round(Number(d.size || 0) / 1024))} KB</small></span><button type="button" class="btn btn-ghost btn-sm" data-training-doc="${d.id}" data-training-id="${t.id}" data-training-doc-name="${esc(d.filename)}">${icon('download')} Herunterladen</button>${can('training.manage') ? `<button type="button" class="icon-action danger" data-training-doc-delete="${d.id}" data-training-id="${t.id}" title="Löschen">${icon('trash')}</button>` : ''}</div>`).join('') : '<p class="form-note">Noch keine Unterlagen hinterlegt.</p>'}</div>
        ${can('training.manage') ? `<form id="trainingDocForm" class="ticket-composer"><div class="form-grid"><div class="i-field"><label for="trainingDocTitle">Titel *</label><input id="trainingDocTitle" name="title" type="text" required placeholder="Ausbildungsplan"></div><div class="i-field"><label for="trainingDocFile">Datei *</label><input id="trainingDocFile" name="file" type="file" required accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"></div></div><div class="form-actions"><button type="submit" class="btn btn-primary btn-sm">${icon('upload')} Unterlage hochladen</button><span class="form-note">PDF, JPG, PNG, DOC oder DOCX · max. 8 MB</span></div></form>` : ''}
        <h3 class="record-subtitle">Zugehörige Tests</h3>
        ${tests.length ? `<div class="upload-list">${tests.map((x) => `<div class="upload-row"><span class="upload-icon">${icon('file')}</span><span class="upload-meta"><strong>${esc(x.title)}</strong><small>Code ${esc(x.public_code)} · ${Number(x.question_count || 0)} Fragen</small></span><button type="button" class="btn btn-ghost btn-sm" data-training-test-view="${x.id}">${icon('eye')} Ergebnisse</button></div>`).join('')}</div>` : '<p class="form-note">Noch keine Tests zugeordnet.</p>'}`;
      openModal('trainingDetailModal');

      $$('[data-training-doc]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            const blob = await api.downloadTrainingDocument(Number(btn.getAttribute('data-training-id')), Number(btn.getAttribute('data-training-doc')));
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = btn.getAttribute('data-training-doc-name') || 'ausbildungsunterlage';
            document.body.appendChild(link);
            link.click();
            link.remove();
            setTimeout(() => URL.revokeObjectURL(url), 5000);
          } catch (err) { toast(err.message || 'Dokument konnte nicht geladen werden.', { type: 'error' }); }
        });
      });
      $$('[data-training-doc-delete]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          if (!window.confirm('Unterlage wirklich löschen?')) return;
          try {
            await api.deleteTrainingDocument(Number(btn.getAttribute('data-training-id')), Number(btn.getAttribute('data-training-doc-delete')));
            toast('Unterlage gelöscht.', { title: 'Gelöscht' });
            closeModal('trainingDetailModal');
            await loadTraining();
          } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
        });
      });
      $$('[data-training-test-view]').forEach((btn) => {
        btn.addEventListener('click', () => openTestDetail(Number(btn.getAttribute('data-training-test-view'))));
      });
      $('#trainingDocForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.target;
        if (!form.reportValidity()) return;
        const title = $('#trainingDocTitle').value.trim();
        const file = $('#trainingDocFile').files[0];
        if (!file) return;
        try {
          const data = await readFileBase64(file);
          await api.uploadTrainingDocument(t.id, { title, filename: file.name, mime: file.type, data });
          toast('Unterlage hochgeladen.', { title: 'Gespeichert' });
          closeModal('trainingDetailModal');
          await loadTraining();
          await openTrainingDetail(t.id);
        } catch (err) { toast(err.message || 'Upload fehlgeschlagen.', { type: 'error' }); }
      });
    } catch (err) { toast(err.message || 'Ausbildung konnte nicht geladen werden.', { type: 'error' }); }
  }

  function readFileBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('Datei konnte nicht gelesen werden.'));
      reader.readAsDataURL(file);
    });
  }

  function questionBlock(question) {
    const q = question || {};
    const options = (q.options || ['', '', '', '']).slice(0, 4);
    while (options.length < 4) options.push('');
    return `<div class="test-question-block" data-test-question>
      <div class="test-question-head"><strong>Frage</strong><button type="button" class="icon-action danger" data-test-question-remove title="Entfernen">${icon('trash')}</button></div>
      <input class="i-input test-question-text" type="text" placeholder="Frage" value="${esc(q.question || '')}">
      <div class="test-options">
        ${options.map((opt, i) => `<label><span>${i + 1}</span><input class="i-input test-option" type="text" placeholder="Antwort ${i + 1}" value="${esc(opt)}"></label>`).join('')}
      </div>
      <label class="test-correct-label">Richtige Antwort
        <select class="i-select test-correct">${[0, 1, 2, 3].map((i) => `<option value="${i}" ${Number(q.correctIndex) === i ? 'selected' : ''}>Antwort ${i + 1}</option>`).join('')}</select>
      </label>
    </div>`;
  }

  function renumberTestQuestions() {
    $$('#testQuestions [data-test-question]').forEach((block, index) => {
      const head = $('.test-question-head strong', block);
      if (head) head.textContent = 'Frage ' + (index + 1);
    });
  }

  function addTestQuestion(question) {
    const box = $('#testQuestions');
    if (!box) return;
    box.insertAdjacentHTML('beforeend', questionBlock(question));
    renumberTestQuestions();
    const blocks = $$('#testQuestions [data-test-question]');
    const last = blocks[blocks.length - 1];
    $('[data-test-question-remove]', last)?.addEventListener('click', () => {
      last.remove();
      renumberTestQuestions();
    });
  }

  $('#testAddQuestion')?.addEventListener('click', () => addTestQuestion(null));

  async function openTestForm(itemOrId) {
    const form = $('#trainingTestForm');
    if (!form) return;
    form.reset();
    $('#testQuestions').innerHTML = '';
    const id = itemOrId && typeof itemOrId === 'object' ? itemOrId.id : itemOrId;
    let item = null;
    let questions = [];
    if (id) {
      try {
        const res = await api.getTrainingTest(id);
        item = res.test;
        questions = res.questions || [];
      } catch (err) { toast(err.message || 'Test konnte nicht geladen werden.', { type: 'error' }); return; }
    }
    form.querySelector('[name="id"]').value = item ? item.id : '';
    $('#testFormTitle').textContent = item ? 'Test bearbeiten' : 'Neuer Test';
    const select = $('#testTraining');
    if (select) {
      select.innerHTML = '<option value="">Keine Zuordnung</option>' + state.trainings.map((t) => `<option value="${t.id}">${esc(t.title)}</option>`).join('');
      if (item && item.training_id) select.value = String(item.training_id);
    }
    if (item) {
      form.querySelector('[name="title"]').value = item.title || '';
      form.querySelector('[name="description"]').value = item.description || '';
      form.querySelector('[name="passScore"]').value = item.pass_score || 70;
      form.querySelector('[name="isActive"]').value = Number(item.is_active) ? '1' : '0';
    }
    if (questions.length) questions.forEach((q) => addTestQuestion({ ...q, correctIndex: q.correct_index }));
    else addTestQuestion(null);
    openModal('testFormModal');
  }

  $('#trainingTestForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    let invalidOptions = false;
    const questions = $$('#testQuestions [data-test-question]').map((block) => {
      const question = $('.test-question-text', block).value.trim();
      const options = $$('.test-option', block).map((input) => input.value.trim());
      if (options.some((value) => !value)) invalidOptions = true;
      const correctIndex = Number($('.test-correct', block).value);
      return { question, options, correctIndex };
    }).filter((q) => q.question && q.options.length >= 2);
    if (invalidOptions) {
      toast('Bitte alle vier Antwortmöglichkeiten ausfüllen.', { type: 'error' });
      return;
    }
    if (!questions.length) {
      toast('Bitte mindestens eine Frage mit zwei Antworten anlegen.', { type: 'error' });
      return;
    }
    const body = {
      title: fd.get('title'),
      description: fd.get('description'),
      trainingId: fd.get('trainingId') ? Number(fd.get('trainingId')) : null,
      passScore: Number(fd.get('passScore') || 70),
      isActive: fd.get('isActive') === '1',
      questions
    };
    const id = fd.get('id');
    try {
      if (id) await api.updateTrainingTest(Number(id), body);
      else await api.createTrainingTest(body);
      toast(id ? 'Test aktualisiert.' : 'Test erstellt.', { title: 'Gespeichert' });
      closeModal('testFormModal');
      await loadTraining();
    } catch (err) { toast(err.message || 'Test konnte nicht gespeichert werden.', { type: 'error' }); }
  });

  async function openTestDetail(id) {
    try {
      const res = await api.getTrainingTest(id);
      const test = res.test || {};
      const questions = res.questions || [];
      const results = res.results || [];
      const link = window.location.origin + '/bewerber-test.html?code=' + encodeURIComponent(test.public_code || '');
      $('#testDetailTitle').textContent = test.title || 'Test';
      $('#testDetailSub').textContent = `Code ${test.public_code || '–'} · Bestehensgrenze ${test.pass_score || 70}%`;
      $('#testDetailBody').innerHTML = `
        <div class="detail-list">
          <div class="detail-row"><dt>Ausbildung</dt><dd>${esc(test.training_title || '–')}</dd></div>
          <div class="detail-row"><dt>Test-Link</dt><dd><span class="mono">${esc(link)}</span><button type="button" class="btn btn-ghost btn-sm" id="testDetailCopy">${icon('copy')} Kopieren</button></dd></div>
        </div>
        <h3 class="record-subtitle">Fragen</h3>
        <div class="detail-list">${questions.map((q, index) => `<div class="detail-row"><dt>Frage ${index + 1}</dt><dd><strong>${esc(q.question)}</strong><br><small>${q.options.map((o, i) => `${i + 1}. ${esc(o)}${Number(q.correct_index) === i ? ' ✓' : ''}`).join(' · ')}</small></dd></div>`).join('') || '<p class="form-note">Keine Fragen.</p>'}</div>
        <h3 class="record-subtitle">Ergebnisse</h3>
        ${results.length ? `<div class="table-wrap"><table class="i-table" style="min-width:0"><thead><tr><th>Bewerber</th><th>Bewerbung</th><th>Ergebnis</th><th>Datum</th></tr></thead><tbody>${results.map((r) => `<tr><td>${esc(r.applicant_name)}</td><td class="mono">${esc(r.application_ref || '–')}</td><td><span class="badge ${Number(r.passed) ? 'badge-green' : 'badge-red'}">${esc(r.score)}%</span></td><td>${dt(r.taken_at)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="form-note">Noch keine Testergebnisse.</p>'}`;
      openModal('testDetailModal');
      $('#testDetailCopy')?.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(link); toast('Test-Link kopiert.', { title: 'Kopiert' }); }
        catch (err) { window.prompt('Test-Link:', link); }
      });
    } catch (err) { toast(err.message || 'Test konnte nicht geladen werden.', { type: 'error' }); }
  }

  /* ---------- Leitungsbereich ---------- */
  async function loadLeadership() {
    const [summary, notesRes] = await Promise.all([api.getLeadershipSummary(), api.getLeadershipNotes()]);
    state.leadershipSummary = summary;
    state.leadershipNotes = notesRes.notes || [];
    renderLeadershipSummary();
    renderLeadershipNotes();
  }

  function renderLeadershipSummary() {
    const box = $('#leadershipKpis');
    if (!box) return;
    const s = state.leadershipSummary || {};
    const kpi = (value, label, cls) => `<div class="kpi ${cls || ''}"><div class="kpi-value">${value}</div><div class="kpi-label">${label}</div></div>`;
    box.innerHTML = [
      kpi(Number(s.applications?.open || 0), 'Offene Vorgänge', 'kpi-blue'),
      kpi(Number(s.applications?.career || 0), 'Bewerbungen', 'kpi-gold'),
      kpi(Number(s.tickets?.open || 0), 'Offene Tickets', 'kpi-red'),
      kpi(Number(s.trainings?.active || 0), 'Laufende Ausbildungen', 'kpi-green'),
      kpi(Number(s.tests?.passed || 0), 'Bestandene Tests', 'kpi-green'),
      kpi(Number(s.users?.active || 0), 'Aktive Bedienstete', 'kpi-blue')
    ].join('');
  }

  function renderLeadershipNotes() {
    const box = $('#leadershipNotes');
    if (!box) return;
    const term = state.filter.toLowerCase();
    const items = state.leadershipNotes.filter((n) => !term || [n.title, n.body, n.priority, n.status].filter(Boolean).join(' ').toLowerCase().includes(term));
    box.innerHTML = items.length ? items.map((n) => `
      <article class="leadership-note ${n.status === 'erledigt' ? 'is-done' : ''}">
        <div class="leadership-note-head">
          <div><span class="badge ${n.priority === 'hoch' ? 'badge-red' : n.priority === 'niedrig' ? 'badge-blue' : 'badge-gold'}">${esc(n.priority)}</span> <strong>${esc(n.title)}</strong></div>
          <span class="badge ${n.status === 'erledigt' ? 'badge-green' : 'badge-blue'}">${esc(n.status)}</span>
        </div>
        ${n.body ? `<p>${esc(n.body)}</p>` : ''}
        <div class="leadership-note-foot">
          <small>${dt(n.created_at)}</small>
          ${can('leadership.manage') ? `<div class="ticket-row-actions"><button type="button" class="btn btn-ghost btn-sm" data-note-toggle="${n.id}">${n.status === 'erledigt' ? 'Wieder öffnen' : 'Erledigt'}</button><button type="button" class="icon-action" data-note-edit="${n.id}">${icon('edit')}</button><button type="button" class="icon-action danger" data-note-delete="${n.id}">${icon('trash')}</button></div>` : ''}
        </div>
      </article>`).join('') : '<p class="form-note">Keine Leitungsnotizen vorhanden.</p>';
  }

  $('#leadershipNoteNew')?.addEventListener('click', () => openLeadershipNote(null));
  $('#leadershipNotes')?.addEventListener('click', async (e) => {
    const toggle = e.target.closest('[data-note-toggle]');
    const edit = e.target.closest('[data-note-edit]');
    const del = e.target.closest('[data-note-delete]');
    if (toggle) {
      const note = state.leadershipNotes.find((n) => Number(n.id) === Number(toggle.getAttribute('data-note-toggle')));
      if (!note) return;
      try {
        await api.updateLeadershipNote(note.id, { status: note.status === 'erledigt' ? 'offen' : 'erledigt' });
        await loadLeadership();
      } catch (err) { toast(err.message || 'Notiz konnte nicht geändert werden.', { type: 'error' }); }
    }
    if (edit) {
      const note = state.leadershipNotes.find((n) => Number(n.id) === Number(edit.getAttribute('data-note-edit')));
      if (note) openLeadershipNote(note);
    }
    if (del) {
      if (!window.confirm('Notiz wirklich löschen?')) return;
      try {
        await api.deleteLeadershipNote(Number(del.getAttribute('data-note-delete')));
        toast('Notiz gelöscht.', { title: 'Gelöscht' });
        await loadLeadership();
      } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
    }
  });

  function openLeadershipNote(note) {
    const form = $('#leadershipNoteForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="id"]').value = note ? note.id : '';
    $('#leadershipNoteTitle').textContent = note ? 'Notiz bearbeiten' : 'Neue Leitungsnotiz';
    if (note) {
      form.querySelector('[name="title"]').value = note.title || '';
      form.querySelector('[name="body"]').value = note.body || '';
      form.querySelector('[name="priority"]').value = note.priority || 'normal';
      form.querySelector('[name="status"]').value = note.status || 'offen';
    }
    openModal('leadershipNoteModal');
  }

  $('#leadershipNoteForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    const body = {
      title: fd.get('title'),
      body: fd.get('body'),
      priority: fd.get('priority'),
      status: fd.get('status')
    };
    try {
      if (id) await api.updateLeadershipNote(Number(id), body);
      else await api.createLeadershipNote(body);
      toast(id ? 'Notiz aktualisiert.' : 'Notiz erstellt.', { title: 'Gespeichert' });
      closeModal('leadershipNoteModal');
      await loadLeadership();
    } catch (err) { toast(err.message || 'Notiz konnte nicht gespeichert werden.', { type: 'error' }); }
  });

  async function loadLaws() {
    const q = $('#lawSearch')?.value.trim() || '';
    const res = await api.getLaws(q);
    state.laws = res.laws || [];
    renderLaws();
  }

  function renderLaws() {
    const grid = $('#lawsGrid');
    if (!grid) return;
    const term = state.filter.toLowerCase();
    const items = state.laws.filter((l) => !term || [l.code, l.title, l.subtitle, l.description, (l.tags || []).join(' ')]
      .filter(Boolean).join(' ').toLowerCase().includes(term));
    if (!items.length) {
      grid.innerHTML = '<div class="empty-state-panel">Keine Gesetze gefunden.</div>';
      return;
    }
    grid.innerHTML = items.map((l) => `
      <button type="button" class="law-card" data-law="${esc(l.code)}">
        <span class="law-icon">${icon(l.icon || 'book')}</span>
        <span class="law-main">
          <span class="law-code">${esc(l.code)}</span>
          <span class="law-title">${esc(l.title)}</span>
          <span class="law-sub">${esc(l.subtitle || '')}</span>
          <span class="law-desc">${esc(l.description || '')}</span>
          <span class="law-tags">${(l.tags || []).map((t) => `<span class="law-tag">${esc(t)}</span>`).join('')}</span>
        </span>
        <span class="law-count">${l.sectionCount || 0} §§</span>
      </button>`).join('');
  }

  $('#lawsGrid')?.addEventListener('click', (e) => {
    const card = e.target.closest('[data-law]');
    if (card) openLaw(card.getAttribute('data-law'));
  });

  let lawSearchTimer = null;
  $('#lawSearch')?.addEventListener('input', () => {
    clearTimeout(lawSearchTimer);
    lawSearchTimer = setTimeout(() => loadLaws().catch((err) => toast(err.message, { type: 'error' })), 260);
  });

  $('#lawNew')?.addEventListener('click', () => openLawForm(null));

  async function openLaw(code) {
    try {
      const res = await api.getLaw(code);
      const law = res.law || {};
      const sections = law.sections || [];
      const canEdit = can('laws.manage');
      $('#lawModalTitle').textContent = law.code + ' · ' + law.title;
      $('#lawModalSub').textContent = law.subtitle || '';
      $('#lawModalBody').innerHTML = `
        ${canEdit ? `<div class="law-admin-bar">
          <button type="button" class="btn btn-primary btn-sm" id="lawEditBtn">${icon('edit')} Gesetz bearbeiten</button>
          <button type="button" class="btn btn-ghost btn-sm" id="lawSectionAdd">${icon('plus')} Paragraph hinzufügen</button>
          <button type="button" class="btn btn-ghost btn-sm danger" id="lawDeleteBtn">${icon('trash')} Löschen</button>
        </div>` : ''}
        <p class="record-lead">${esc(law.description || '')}</p>
        <div class="chip-list" style="margin-bottom:18px">${(law.tags || []).map((t) => `<span class="law-tag">${esc(t)}</span>`).join('')}</div>
        ${sections.length ? sections.map((s) => `
          <article class="law-section">
            <div class="law-section-head">
              <span class="mono">${esc(s.number)}</span><strong>${esc(s.title)}</strong>
              ${canEdit ? `<div class="law-section-actions">
                <button type="button" class="icon-action" data-law-section-edit="${s.id}" title="Paragraph bearbeiten">${icon('edit')}</button>
                <button type="button" class="icon-action danger" data-law-section-delete="${s.id}" title="Paragraph löschen">${icon('trash')}</button>
              </div>` : ''}
            </div>
            <p>${esc(s.text || '')}</p>
            ${s.penalty ? `<div class="law-penalty">${icon('gavel')} ${esc(s.penalty)}</div>` : ''}
          </article>`).join('') : '<p class="form-note">Für dieses Gesetz sind noch keine Paragraphen hinterlegt.</p>'}`;
      openModal('lawModal');

      if (canEdit) {
        $('#lawEditBtn')?.addEventListener('click', () => {
          closeModal('lawModal');
          openLawForm(law);
        });
        $('#lawSectionAdd')?.addEventListener('click', () => {
          closeModal('lawModal');
          openLawSectionForm(law.code, null);
        });
        $('#lawDeleteBtn')?.addEventListener('click', async () => {
          if (!window.confirm(`Gesetz ${law.code} wirklich löschen?`)) return;
          try {
            await api.deleteLaw(law.code);
            closeModal('lawModal');
            toast('Gesetz gelöscht.', { title: 'Gelöscht' });
            await loadLaws();
          } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
        });
        $$('[data-law-section-edit]', $('#lawModalBody')).forEach((btn) => {
          btn.addEventListener('click', () => {
            const section = sections.find((s) => Number(s.id) === Number(btn.getAttribute('data-law-section-edit')));
            if (!section) return;
            closeModal('lawModal');
            openLawSectionForm(law.code, section);
          });
        });
        $$('[data-law-section-delete]', $('#lawModalBody')).forEach((btn) => {
          btn.addEventListener('click', async () => {
            if (!window.confirm('Paragraphen wirklich löschen?')) return;
            try {
              await api.deleteLawSection(law.code, Number(btn.getAttribute('data-law-section-delete')));
              toast('Paragraph gelöscht.', { title: 'Gelöscht' });
              await openLaw(law.code);
              await loadLaws();
            } catch (err) { toast(err.message || 'Löschen fehlgeschlagen.', { type: 'error' }); }
          });
        });
      }
    } catch (err) {
      toast(err.message || 'Gesetz konnte nicht geladen werden.', { type: 'error' });
    }
  }

  function openLawForm(item) {
    const form = $('#lawForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="oldCode"]').value = item ? item.code : '';
    form.querySelector('[name="code"]').value = item ? item.code : '';
    form.querySelector('[name="code"]').disabled = Boolean(item);
    form.querySelector('[name="title"]').value = item ? item.title || '' : '';
    form.querySelector('[name="subtitle"]').value = item ? item.subtitle || '' : '';
    form.querySelector('[name="description"]').value = item ? item.description || '' : '';
    form.querySelector('[name="icon"]').value = item ? item.icon || 'book' : 'book';
    form.querySelector('[name="tags"]').value = item ? (item.tags || []).join(', ') : '';
    form.querySelector('[name="sortOrder"]').value = item ? item.sortOrder : 999;
    $('#lawFormTitle').textContent = item ? 'Gesetz bearbeiten' : 'Neues Gesetz';
    openModal('lawFormModal');
  }

  $('#lawForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const oldCode = fd.get('oldCode');
    const body = {
      code: fd.get('code'),
      title: fd.get('title'),
      subtitle: fd.get('subtitle'),
      description: fd.get('description'),
      icon: fd.get('icon') || 'book',
      tags: fd.get('tags'),
      sortOrder: Number(fd.get('sortOrder') || 999)
    };
    try {
      if (oldCode) await api.updateLaw(oldCode, body);
      else await api.createLaw(body);
      toast(oldCode ? 'Gesetz aktualisiert.' : 'Gesetz erstellt.', { title: 'Gespeichert' });
      closeModal('lawFormModal');
      await loadLaws();
    } catch (err) { toast(err.message || 'Gesetz konnte nicht gespeichert werden.', { type: 'error' }); }
  });

  function openLawSectionForm(lawCode, section) {
    const form = $('#lawSectionForm');
    if (!form) return;
    form.reset();
    form.querySelector('[name="lawCode"]').value = lawCode;
    form.querySelector('[name="id"]').value = section ? section.id : '';
    form.querySelector('[name="number"]').value = section ? section.number || '' : '';
    form.querySelector('[name="title"]').value = section ? section.title || '' : '';
    form.querySelector('[name="text"]').value = section ? section.text || '' : '';
    form.querySelector('[name="penalty"]').value = section ? section.penalty || '' : '';
    form.querySelector('[name="sortOrder"]').value = section ? section.sort_order : 999;
    $('#lawSectionFormTitle').textContent = section ? 'Paragraph bearbeiten' : 'Neuer Paragraph';
    $('#lawSectionFormSub').textContent = lawCode;
    openModal('lawSectionFormModal');
  }

  $('#lawSectionForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const fd = new FormData(form);
    const code = fd.get('lawCode');
    const id = fd.get('id');
    const body = {
      number: fd.get('number'),
      title: fd.get('title'),
      text: fd.get('text'),
      penalty: fd.get('penalty'),
      sortOrder: Number(fd.get('sortOrder') || 999)
    };
    try {
      if (id) await api.updateLawSection(code, Number(id), body);
      else await api.createLawSection(code, body);
      toast(id ? 'Paragraph aktualisiert.' : 'Paragraph erstellt.', { title: 'Gespeichert' });
      closeModal('lawSectionFormModal');
      await loadLaws();
      await openLaw(code);
    } catch (err) { toast(err.message || 'Paragraph konnte nicht gespeichert werden.', { type: 'error' }); }
  });


  /* ---------- Modals ---------- */
  function openModal(id) {
    const modal = $('#' + id);
    if (!modal) return;
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    const focusable = Array.from(modal.querySelectorAll('input, select, textarea'))
      .find((el) => el.type !== 'hidden' && !el.disabled && el.offsetParent !== null)
      || modal.querySelector('.i-modal-close');
    if (focusable) focusable.focus({ preventScroll: true });
  }
  function closeModal(id) {
    const modal = $('#' + id);
    if (!modal) return;
    modal.hidden = true;
    if (id === 'ticketModal') stopTicketPoll();
    if (!$$('.i-modal').some((m) => !m.hidden)) document.body.style.overflow = '';
  }
  $$('.i-modal').forEach((modal) => {
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(modal.id); });
  });
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-modal-close]');
    if (!btn) return;
    const modal = btn.closest('.i-modal');
    if (modal) closeModal(modal.id);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const open = $$('.i-modal').find((m) => !m.hidden);
      if (open) closeModal(open.id);
      if (appView.classList.contains('side-open')) closeSidebar();
    }
  });

  /* Global filter delegates to active view */
  $('#globalFilter')?.addEventListener('input', (e) => {
    state.filter = e.target.value;
    if (state.view === 'applications') renderApplications();
    else if (state.view === 'tickets') renderTickets();
    else if (state.view === 'archive') renderArchive();
    else if (state.view === 'wanted') renderWanted();
    else if (state.view === 'news') renderNews();
    else if (state.view === 'evidence') renderEvidence();
    else if (state.view === 'citizens') renderCitizens();
    else if (state.view === 'vehicles') renderVehicles();
    else if (state.view === 'weapons') renderWeapons();
    else if (state.view === 'activity') renderActivity();
    else if (state.view === 'laws') renderLaws();
    else if (state.view === 'recruitment') renderRecruitment();
    else if (state.view === 'hr') renderHr();
    else if (state.view === 'training') renderTraining();
    else if (state.view === 'leadership') renderLeadershipNotes();
    else if (state.view === 'documents') renderDocuments();
    else if (state.view === 'users') renderUsers();
    else if (state.view === 'ranks') renderRanks();
  });

  /* ---------- Init ---------- */
  async function init() {
    const token = api.getToken();
    if (token) {
      try {
        const res = await api.me();
        state.user = res.user;
        await showApp();
        return;
      } catch (e) {
        api.setToken(null);
      }
    }
    showLogin();
  }

  init();
})();
