/* Prävention page – safety check */
(function () {
  'use strict';

  const app = window.LPTApp;
  if (!app) return;

  const form = document.getElementById('safetyForm');
  const result = document.getElementById('safetyResult');
  const reset = document.getElementById('safetyReset');
  if (!form || !result) return;

  const tips = {
    sq1: 'Schließen Sie die Wohnungstür immer mit dem Schlüssel ab – auch wenn Sie nur kurz weg sind.',
    sq2: 'Verwenden Sie für jedes Konto ein eigenes, langes Passwort. Ein Passwort-Manager hilft dabei.',
    sq3: 'Speichern Sie die 110 im Telefon und bringen Sie Kindern den Notruf spielerisch näher.',
    sq4: 'Prüfen Sie bei Links zuerst den Absender und fahren Sie mit der Maus über die Zieladresse.',
    sq5: 'Nach einem Einbruch: nichts anfassen, Spuren sichern, sofort die 110 rufen und die Nachbarn informieren.',
    sq6: 'Machen Sie sich mit den Maschen von Enkeltrick, Schockanruf und falschen Polizisten vertraut.'
  };

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const data = new FormData(form);
    const missing = Object.keys(tips).filter((name) => data.get(name) === 'nein');
    const score = 6 - missing.length;

    let title;
    let tone;
    if (score >= 5) {
      title = 'Starke Basis – Sie sind gut aufgestellt.';
      tone = 'is-good';
    } else if (score >= 3) {
      title = 'Solide Basis – mit ein paar einfachen Schritten wird es noch besser.';
      tone = 'is-mid';
    } else {
      title = 'Hier gibt es Handlungsbedarf – aber das lässt sich ändern.';
      tone = 'is-warn';
    }

    result.className = `safety-result is-visible ${tone}`;
    result.innerHTML = `
      <strong>${score} von 6 Punkten · ${title}</strong>
      <p>${missing.length
        ? 'Diese Punkte sollten Sie sich noch einmal ansehen:'
        : 'Sie haben alle Fragen mit Ja beantwortet. Bleiben Sie aufmerksam und sprechen Sie auch mit Angehörigen über die Themen.'}</p>
      ${missing.length ? `<ul class="check-list">${missing.map((name) => `<li>${app.ICON('info')}<span>${app.escapeHTML(tips[name])}</span></li>`).join('')}</ul>` : ''}
      <p><a class="text-link" href="kontakt.html#formular">Persönliche Beratung anfragen ${app.ICON('arrow-right')}</a></p>`;
    result.hidden = false;
    result.setAttribute('tabindex', '-1');
    result.focus({ preventScroll: true });
    app.toast(`Ihr Sicherheitscheck ergab ${score} von 6 Punkten.`, { title: 'Auswertung fertig' });
  });

  if (reset) {
    reset.addEventListener('click', () => {
      form.reset();
      result.hidden = true;
      result.className = 'safety-result';
      result.innerHTML = '';
      const first = form.querySelector('input');
      if (first) first.focus({ preventScroll: true });
    });
  }

  // Deep links such as praevention.html#einbruchschutz should open the matching tips.
  if (window.location.hash) {
    const target = document.getElementById(window.location.hash.slice(1));
    if (target) {
      const details = target.querySelector('details');
      if (details) details.open = true;
    }
  }
})();
