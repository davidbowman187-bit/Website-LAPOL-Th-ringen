/* Öffentlicher Bewerbertest */
(function () {
  'use strict';

  const app = window.LPTApp;
  const api = window.LPTApi;
  if (!app || !api) return;

  const params = new URLSearchParams(window.location.search);
  const code = String(params.get('code') || '').trim().toUpperCase();
  const loading = document.getElementById('testLoading');
  const errorBox = document.getElementById('testError');
  const errorText = document.getElementById('testErrorText');
  const appBox = document.getElementById('testApp');
  const form = document.getElementById('applicantTestForm');
  const questionList = document.getElementById('testQuestionList');
  const result = document.getElementById('testResult');
  const resultTitle = document.getElementById('testResultTitle');
  const resultText = document.getElementById('testResultText');
  const scoreBox = document.getElementById('testScore');
  const resultHint = document.getElementById('testResultHint');
  const resultIcon = document.getElementById('testResultIcon');
  const refInput = document.getElementById('testApplicationRef');
  const nameInput = document.getElementById('testApplicantName');
  const startBox = document.getElementById('testStart');
  const startForm = document.getElementById('testStartForm');
  const startCode = document.getElementById('testStartCode');
  const startRef = document.getElementById('testStartRef');
  let test = null;
  let questions = [];

  function showError(message) {
    if (loading) loading.hidden = true;
    if (appBox) appBox.hidden = true;
    if (errorBox) errorBox.hidden = false;
    if (errorText) errorText.textContent = message;
    if (startBox) {
      startBox.hidden = false;
      if (startCode && code) startCode.value = code;
      if (startRef && params.get('ref') && !startRef.value) startRef.value = params.get('ref');
    }
  }

  function renderQuestions() {
    if (!questionList) return;
    questionList.innerHTML = questions.map((q, index) => `
      <article class="test-public-question" data-question-id="${q.id}">
        <div class="test-public-number">Frage ${index + 1}</div>
        <h3>${app.escapeHTML(q.question)}</h3>
        <div class="test-public-options">
          ${q.options.map((option, i) => `<label class="test-public-option">
            <input type="radio" name="question-${q.id}" value="${i}">
            <span class="test-public-option-index">${String.fromCharCode(65 + i)}</span>
            <span>${app.escapeHTML(option)}</span>
          </label>`).join('')}
        </div>
      </article>`).join('');
  }

  if (startForm) {
    startForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!startForm.reportValidity()) return;
      const nextCode = startCode ? startCode.value.trim().toUpperCase() : '';
      const nextRef = startRef ? startRef.value.trim() : '';
      if (!nextCode) return;
      const url = new URL(window.location.href);
      url.searchParams.set('code', nextCode);
      if (nextRef) url.searchParams.set('ref', nextRef);
      else url.searchParams.delete('ref');
      window.location.href = url.toString();
    });
  }

  if (!code) {
    if (loading) loading.hidden = true;
    if (startBox) startBox.hidden = false;
    if (startRef && params.get('ref')) startRef.value = params.get('ref');
    return;
  }
  if (refInput && params.get('ref')) refInput.value = params.get('ref');

  (async () => {
    try {
      const res = await api.getPublicTest(code);
      test = res.test || {};
      questions = res.questions || [];
      if (!questions.length) {
        showError('Dieser Test enthält noch keine Fragen.');
        return;
      }
      document.getElementById('testTitle').textContent = test.title || 'Bewerbertest';
      document.getElementById('testDescription').textContent = test.description || '';
      document.getElementById('testTraining').textContent = test.trainingTitle || 'Bewerbertest';
      document.getElementById('testPassScore').textContent = 'Bestehensgrenze: ' + (test.passScore || 70) + ' %';
      renderQuestions();
      if (loading) loading.hidden = true;
      if (appBox) appBox.hidden = false;
    } catch (err) {
      showError(err.message || 'Der Test konnte nicht geladen werden.');
    }
  })();

  if (form) {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const answers = {};
      for (const q of questions) {
        const selected = form.querySelector(`input[name="question-${q.id}"]:checked`);
        if (!selected) {
          app.toast('Bitte beantworten Sie alle Fragen.', { type: 'error' });
          const target = document.querySelector(`[data-question-id="${q.id}"]`);
          if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          return;
        }
        answers[String(q.id)] = Number(selected.value);
      }
      try {
        const res = await api.submitPublicTest(code, {
          applicantName: nameInput.value.trim(),
          applicationRef: refInput.value.trim(),
          answers
        });
        form.hidden = true;
        if (result) result.hidden = false;
        if (resultIcon) resultIcon.innerHTML = res.passed ? app.ICON('check-circle') : app.ICON('alert');
        if (resultTitle) resultTitle.textContent = res.passed ? 'Test bestanden' : 'Test nicht bestanden';
        if (resultText) resultText.textContent = `Sie haben ${res.correct} von ${res.total} Fragen richtig beantwortet. Das Ergebnis wurde an die Personalabteilung übermittelt.`;
        if (scoreBox) scoreBox.textContent = res.score + ' %';
        if (resultHint) resultHint.textContent = `Bestehensgrenze: ${res.passScore} %`;
        if (result) result.className = 'test-result ' + (res.passed ? 'is-passed' : 'is-failed');
        result.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } catch (err) {
        app.toast(err.message || 'Test konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
      }
    });
  }
})();
