/* Startseite: Hero-Karussell & aktuelle Meldungen */
(async function () {
  'use strict';
  const app = window.LPTApp;
  const $ = app.$;
  const $$ = app.$$;

  /* ---------- Hero carousel ---------- */
  const slides = $$('.hero-slide');
  const dots = $$('.hero-dots button');
  const counter = $('.hero-count-current');
  const pauseBtn = $('.hero-pause');
  let current = 0;
  let paused = false;
  let timer = null;

  function go(next) {
    current = (next + slides.length) % slides.length;
    slides.forEach((slide, i) => {
      const isActive = i === current;
      slide.classList.toggle('is-active', isActive);
      slide.setAttribute('aria-hidden', String(!isActive));
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === current);
      dot.setAttribute('aria-current', i === current ? 'true' : 'false');
    });
    if (counter) counter.textContent = String(current + 1).padStart(2, '0');
  }

  function start() {
    stop();
    if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    timer = window.setInterval(() => go(current + 1), 7500);
  }
  function stop() {
    if (timer) window.clearInterval(timer);
    timer = null;
  }

  if (slides.length) {
    go(0);
    dots.forEach((dot, i) => dot.addEventListener('click', () => {
      go(i);
      start();
    }));
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        paused = !paused;
        pauseBtn.setAttribute('aria-label', paused ? 'Automatischen Wechsel fortsetzen' : 'Automatischen Wechsel pausieren');
        pauseBtn.innerHTML = `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${paused ? 'play' : 'pause'}"></use></svg>`;
        if (paused) stop();
        else start();
      });
    }
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stop();
      else start();
    });
    const hero = $('.hero');
    if (hero && window.matchMedia('(hover:hover)').matches) {
      hero.addEventListener('mouseenter', stop);
      hero.addEventListener('mouseleave', start);
    }
    start();
  }

  /* ---------- Latest news ---------- */
  const container = $('#homeNews');
  if (container) {
    let newsData = (window.LPT.news || []).slice();
    if (window.LPTApi) {
      try {
        const res = await window.LPTApi.getNews();
        if (Array.isArray(res.news)) {
          newsData = res.news.map((n) => ({
            id: n.id, category: n.category, label: n.label,
            date: (n.created_at ? String(n.created_at).slice(0, 10) : n.date),
            title: n.title, teaser: n.teaser, reading: n.reading, icon: n.icon
          }));
        }
      } catch (e) { /* static fallback */ }
    }
    const latest = newsData.slice(0, 6);
    container.innerHTML = latest.map((n, i) => `
      <article class="news-card${i === 0 ? ' is-featured' : ''}">
        <div class="news-visual v-${n.category}">
          <span class="visual-icon">${app.ICON(n.icon || 'file')}</span>
          <span class="news-tag">${app.ICON(n.category === 'warnung' ? 'alert' : n.category === 'fahndung' ? 'search' : 'file')} ${app.escapeHTML(n.label)}</span>
        </div>
        <div class="news-body">
          <div class="news-meta">
            <span>${app.ICON('calendar')} ${app.formatDate(n.date)}</span>
            <span>${app.ICON('clock')} ${n.reading} Min. Lesezeit</span>
          </div>
          <h3><a href="meldung.html?id=${n.id}">${app.escapeHTML(n.title)}</a></h3>
          <p>${app.escapeHTML(n.teaser)}</p>
          <a class="text-link" href="meldung.html?id=${n.id}">Mehr lesen ${app.ICON('arrow-right')}</a>
        </div>
      </article>
    `).join('');
  }
  /* ---------- Bewerbungsphase ---------- */
  const phaseBox = $('#homeRecruitmentStatus');
  if (phaseBox && window.LPTApi) {
    try {
      const res = await window.LPTApi.getRecruitmentPhases();
      const phases = res.phases || [];
      phaseBox.innerHTML = phases.length
        ? phases.map((p) => `<span class="recruitment-chip ${p.isOpen ? 'is-open' : 'is-closed'}"><span class="recruitment-dot"></span>${app.escapeHTML(p.label)}: ${p.isOpen ? 'offen' : 'geschlossen'}</span>`).join('')
        : '<span class="recruitment-chip is-closed">Bewerbungsstatus nicht verfügbar</span>';
    } catch (e) {
      phaseBox.innerHTML = '<span class="recruitment-chip is-closed">Bewerbungsstatus nicht verfügbar</span>';
    }
  }
})();
