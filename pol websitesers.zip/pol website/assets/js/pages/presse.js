/* Presseseite: Filter, Suche und Nachladen */
(function () {
  'use strict';
  const app = window.LPTApp;
  const list = document.getElementById('pressList');
  if (!list) return;

  const chips = app.$$('[data-press-filter]');
  const search = document.getElementById('pressSearch');
  const count = document.getElementById('pressCount');
  const moreBtn = document.getElementById('pressMore');
  let category = 'alle';
  let term = '';
  let visible = 6;
  let newsData = (window.LPT.news || []).slice();

  function mapNews(n) {
    return {
      id: n.id,
      slug: n.slug,
      category: n.category,
      label: n.label,
      date: (n.created_at ? String(n.created_at).slice(0, 10) : n.date),
      title: n.title,
      teaser: n.teaser,
      location: n.location,
      reading: n.reading,
      featured: !!n.featured,
      icon: n.icon
    };
  }

  async function loadNews() {
    if (window.LPTApi) {
      try {
        const res = await window.LPTApi.getNews();
        if (Array.isArray(res.news)) {
          newsData = res.news.map(mapNews);
        }
      } catch (e) { /* static fallback */ }
    }
    render();
  }

  function card(n, featured) {
    return `<article class="news-card${featured ? ' is-featured' : ''}">
      <div class="news-visual v-${n.category}">
        <span class="visual-icon">${app.ICON(n.icon || 'file')}</span>
        <span class="news-tag">${app.ICON(n.category === 'warnung' ? 'alert' : n.category === 'fahndung' ? 'search' : 'file')} ${app.escapeHTML(n.label)}</span>
      </div>
      <div class="news-body">
        <div class="news-meta">
          <span>${app.ICON('calendar')} ${app.formatDate(n.date)}</span>
          <span>${app.ICON('clock')} ${n.reading} Min. Lesezeit</span>
        </div>
        <h3><a href="meldung.html?id=${n.id}">${app.escapeHTML(n.title)}</a></h3>
        <p>${app.escapeHTML(n.teaser)}</p>
        <a class="text-link" href="meldung.html?id=${n.id}">Mehr lesen ${app.ICON('arrow-right')}</a>
      </div>
    </article>`;
  }

  function render() {
    const q = app.normalize(term);
    const filtered = newsData.filter((n) => {
      const categoryOk = category === 'alle' || n.category === category;
      const textOk = !q || app.normalize(`${n.title} ${n.teaser} ${n.location} ${n.label}`).includes(q);
      return categoryOk && textOk;
    });

    if (count) {
      count.textContent = `${filtered.length} ${filtered.length === 1 ? 'Meldung' : 'Meldungen'}`;
    }

    if (!filtered.length) {
      list.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        ${app.ICON('search')}
        <p><strong>Keine Meldungen gefunden.</strong><br>Versuchen Sie einen anderen Suchbegriff oder wählen Sie „Alle“.</p>
      </div>`;
      if (moreBtn) moreBtn.hidden = true;
      return;
    }

    const shown = filtered.slice(0, visible);
    list.innerHTML = shown.map((n, i) => card(n, category === 'alle' && !term && i === 0)).join('');
    if (moreBtn) {
      moreBtn.hidden = filtered.length <= visible;
      moreBtn.innerHTML = `Weitere Meldungen laden ${app.ICON('arrow-down')}`;
    }
  }

  chips.forEach((chip) => {
    chip.addEventListener('click', () => {
      category = chip.getAttribute('data-press-filter');
      visible = 6;
      chips.forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
      render();
    });
  });

  if (search) {
    search.addEventListener('input', () => {
      term = search.value;
      visible = 6;
      render();
    });
  }

  if (moreBtn) {
    moreBtn.addEventListener('click', () => {
      visible += 6;
      render();
    });
  }

  loadNews();
})();
