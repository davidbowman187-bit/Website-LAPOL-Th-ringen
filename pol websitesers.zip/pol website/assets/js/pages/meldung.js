/* Einzelne Meldung rendern */
(async function () {
  'use strict';
  const app = window.LPTApp;
  const hero = document.getElementById('articleHero');
  const root = document.getElementById('articleRoot');
  if (!hero || !root) return;

  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get('id'));

  let newsData = (window.LPT.news || []).slice();
  if (window.LPTApi) {
    try {
      const res = await window.LPTApi.getNews();
      if (Array.isArray(res.news)) {
        newsData = res.news.map((n) => ({
          id: n.id,
          slug: n.slug,
          category: n.category,
          label: n.label,
          date: (n.created_at ? String(n.created_at).slice(0, 10) : n.date),
          title: n.title,
          teaser: n.teaser,
          location: n.location,
          reading: n.reading,
          featured: !!n.featured,
          icon: n.icon,
          body: Array.isArray(n.body) ? n.body : []
        }));
      }
    } catch (e) { /* static fallback */ }
  }

  const article = newsData.find((n) => n.id === id);

  if (!article) {
    hero.innerHTML = `<h1>Meldung nicht gefunden</h1>
      <p class="page-hero-lead">Die aufgerufene Meldung existiert nicht oder wurde verschoben. Alle aktuellen Meldungen finden Sie in unserer Übersicht.</p>
      <div class="hero-actions" style="margin-top:20px">
        <a class="btn btn-red" href="presse.html">Zur Übersicht ${app.ICON('arrow-right')}</a>
      </div>`;
    root.innerHTML = `<div class="empty-state">${app.ICON('file')}<p>Diese Meldung ist nicht mehr verfügbar.</p></div>`;
    document.title = 'Meldung nicht gefunden | Landespolizei Thüringen · Roleplay Erfurt';
    return;
  }

  document.title = `${article.title} | Landespolizei Thüringen · Roleplay Erfurt`;
  const meta = document.querySelector('meta[name="description"]');
  if (meta) meta.setAttribute('content', article.teaser);

  hero.innerHTML = `
    <span class="article-tag">${app.ICON(article.category === 'warnung' ? 'alert' : article.category === 'fahndung' ? 'search' : 'file')} ${app.escapeHTML(article.label)}</span>
    <h1>${app.escapeHTML(article.title)}</h1>
    <p class="article-lead">${app.escapeHTML(article.teaser)}</p>
    <div class="article-meta" style="color:#9fb3d2">
      <span>${app.ICON('calendar')} ${app.formatDate(article.date)}</span>
      <span>${app.ICON('map-pin')} ${app.escapeHTML(article.location)}</span>
      <span>${app.ICON('clock')} ${article.reading} Min. Lesezeit</span>
      <span>${app.ICON('building')} Landespolizei Thüringen</span>
    </div>`;

  const related = newsData.filter((n) => n.id !== article.id).sort((a, b) => {
    const aScore = a.category === article.category ? 1 : 0;
    const bScore = b.category === article.category ? 1 : 0;
    return bScore - aScore || new Date(b.date) - new Date(a.date);
  }).slice(0, 3);

  root.innerHTML = `
    <article>
      <div class="article-hero v-${article.category}">
        <span class="visual-icon">${app.ICON(article.icon || 'file')}</span>
        <span class="hero-caption">${app.escapeHTML(article.label)} · ${app.escapeHTML(article.location)}<small>Symbolbild · Fiktive Meldung im Roleplay-Projekt</small></span>
      </div>
      <div class="prose">
        ${article.body.join('')}
        ${article.category === 'warnung' ? `<div class="notice notice-warning">${app.ICON('alert')}<div><strong>Im Notfall zählt jede Sekunde</strong><p>Wenn Sie sich bedroht fühlen oder ein Verbrechen gerade stattfindet, wählen Sie sofort den Notruf <a href="tel:110">110</a>.</p></div></div>` : ''}
        ${article.category === 'fahndung' ? `<div class="notice">${app.ICON('info')}<div><strong>Hinweise an die Polizei</strong><p>Bitte greifen Sie nicht selbst ein. Übermitteln Sie Ihre Beobachtung über die <a href="onlinewache.html">Onlinewache</a> oder rufen Sie die 110 an.</p></div></div>` : ''}
      </div>
      <div class="article-footer">
        <div class="share-row">
          <span>Meldung teilen:</span>
          <button type="button" class="share-btn" data-copy data-copy-target="#articleShareUrl">${app.ICON('copy')} Link kopieren</button>
          <button type="button" class="share-btn" data-share="native" data-share-title="${app.escapeHTML(article.title)}">${app.ICON('share')} Teilen</button>
          <button type="button" class="share-btn" data-print>${app.ICON('print')} Drucken</button>
          <span id="articleShareUrl" class="sr-only">${window.location.href}</span>
        </div>
      </div>
    </article>

    <aside class="sidebar">
      <div class="sidebar-card sidebar-card-dark">
        <span class="eyebrow eyebrow-light">Pressestelle</span>
        <h3>Ihre Ansprechpartner</h3>
        <p>Bei Fragen zu dieser Meldung erreichen Sie die Pressestelle der Landespolizei Thüringen.</p>
        <a class="btn btn-gold btn-sm" style="margin-top:12px" href="kontakt.html#formular">Medienanfrage senden</a>
      </div>
      <div class="sidebar-card">
        <h3>Weitere Meldungen</h3>
        <ul class="sidebar-links">
          ${newsData.filter((n) => n.id !== article.id).slice(0, 4).map((n) => `<li><a href="meldung.html?id=${n.id}"><span>${app.escapeHTML(n.title)}</span>${app.ICON('arrow-right')}</a></li>`).join('')}
        </ul>
        <a class="text-link" style="margin-top:14px" href="presse.html">Alle Meldungen ${app.ICON('arrow-right')}</a>
      </div>
      <div class="sidebar-card sidebar-card-accent">
        <h3>Etwas beobachtet?</h3>
        <p>Ihr Hinweis kann bei der Aufklärung helfen – auch anonym.</p>
        <a class="btn btn-red btn-sm btn-block" href="onlinewache.html">Hinweis übermitteln</a>
      </div>
    </aside>

    <div class="related-block" style="grid-column:1/-1;margin-top:38px">
      <div class="section-head" style="margin-bottom:18px">
        <div><span class="eyebrow">Zum Weiterlesen</span><h2 style="font-size:28px">Das könnte Sie auch interessieren</h2></div>
      </div>
      <div class="related-grid">
        ${related.map((n) => `<article class="news-card">
          <div class="news-visual v-${n.category}" style="min-height:130px"><span class="news-tag">${app.escapeHTML(n.label)}</span></div>
          <div class="news-body">
            <div class="news-meta"><span>${app.formatDate(n.date)}</span></div>
            <h3 style="font-size:16px"><a href="meldung.html?id=${n.id}">${app.escapeHTML(n.title)}</a></h3>
            <a class="text-link" href="meldung.html?id=${n.id}">Mehr lesen ${app.ICON('arrow-right')}</a>
          </div>
        </article>`).join('')}
      </div>
    </div>
  `;

  const current = document.querySelector('.breadcrumb [aria-current="page"]');
  if (current) current.textContent = article.label;
})();
