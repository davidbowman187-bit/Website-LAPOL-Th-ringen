/* Fahndungsseite: Filter, Suche und Hinweisformular */
(function () {
  'use strict';
  const app = window.LPTApp;
  const list = document.getElementById('wantedList');
  if (!list) return;

  const chips = app.$$('[data-wanted-filter]');
  const search = document.getElementById('wantedSearch');
  const count = document.getElementById('wantedCount');
  let category = 'alle';
  let term = '';
  let highlight = window.location.hash ? window.location.hash.slice(1) : '';
  let wantedData = (window.LPT.fahndungen || []).slice();

  function mapWanted(w) {
    const cat = w.category || 'person';
    return {
      caseNo: w.case_no || w.caseNo,
      category: cat,
      label: cat === 'person' ? 'Personenfahndung' : cat === 'sache' ? 'Sachfahndung' : 'Zeugensuche',
      date: (w.created_at ? String(w.created_at).slice(0, 10) : new Date().toISOString().slice(0, 10)),
      title: w.title,
      location: w.location || '',
      teaser: w.teaser || w.description || '',
      description: w.description || '',
      facts: Array.isArray(w.facts) ? w.facts : [],
      icon: w.icon || 'search'
    };
  }

  async function loadWanted() {
    if (window.LPTApi) {
      try {
        const res = await window.LPTApi.getWanted();
        if (Array.isArray(res.wanted)) {
          wantedData = res.wanted.map(mapWanted);
        }
      } catch (e) { /* keep static fallback */ }
    }
    render();
  }

  function card(item) {
    return `<article class="wanted-card" id="${app.escapeHTML(item.caseNo)}" data-case="${app.escapeHTML(item.caseNo)}">
      <div class="wanted-card-visual ${item.category === 'person' ? 'is-person' : ''}">
        ${app.ICON(item.icon || 'search')}
        <span class="tag">${app.escapeHTML(item.label)}</span>
        <span class="case">${app.escapeHTML(item.caseNo)}</span>
      </div>
      <div class="wanted-card-body">
        <div class="news-meta">
          <span>${app.ICON('calendar')} ${app.formatDate(item.date)}</span>
          <span>${app.ICON('map-pin')} ${app.escapeHTML(item.location)}</span>
        </div>
        <h3>${app.escapeHTML(item.title)}</h3>
        <p>${app.escapeHTML(item.teaser)}</p>
        <ul class="wanted-facts-list">
          ${item.facts.slice(0, 3).map(([label, value]) => `<li>${app.ICON('info')}<span><strong>${app.escapeHTML(label)}:</strong> ${app.escapeHTML(value)}</span></li>`).join('')}
        </ul>
        <div class="wanted-card-actions">
          <button type="button" class="btn btn-red btn-sm" data-hint-case="${app.escapeHTML(item.caseNo)}" data-hint-title="${app.escapeHTML(item.title)}">Hinweis geben</button>
          <a class="btn btn-ghost btn-sm" href="onlinewache.html">Onlinewache</a>
        </div>
      </div>
    </article>`;
  }

  function render() {
    const q = app.normalize(term);
    const filtered = wantedData.filter((item) => {
      const catOk = category === 'alle' || item.category === category;
      const textOk = !q || app.normalize(`${item.title} ${item.teaser} ${item.description} ${item.location} ${item.caseNo}`).includes(q);
      return catOk && textOk;
    });
    if (count) count.textContent = `${filtered.length} ${filtered.length === 1 ? 'Fahndung' : 'Fahndungen'}`;
    if (!filtered.length) {
      list.innerHTML = `<div class="empty-state" style="grid-column:1/-1">${app.ICON('search')}<p><strong>Keine Fahndung gefunden.</strong><br>Versuchen Sie einen anderen Suchbegriff.</p></div>`;
      return;
    }
    list.innerHTML = filtered.map(card).join('');
    if (highlight) {
      const target = document.getElementById(highlight);
      if (target) {
        target.classList.add('is-highlighted');
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        highlight = '';
      }
    }
  }

  chips.forEach((chip) => {
    chip.addEventListener('click', () => {
      category = chip.getAttribute('data-wanted-filter');
      chips.forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
      render();
    });
  });

  if (search) {
    search.addEventListener('input', () => {
      term = search.value;
      render();
    });
  }

  loadWanted();

  /* Hinweis-Modal */
  const modal = document.getElementById('hintModal');
  const caseLabel = document.getElementById('hintCaseNumber');
  const titleLabel = document.getElementById('hintTitleText');
  const form = document.getElementById('hintForm');
  const success = document.getElementById('hintSuccess');
  const ref = document.getElementById('hintCase');
  const loginBox = document.getElementById('hintLogin');
  const loginBtn = document.getElementById('hintDiscordLogin');
  const chatLink = document.getElementById('hintChatLink');
  let activeCase = '';
  let citizenPromise = null;

  function checkCitizen() {
    if (!window.LPTApi) return Promise.resolve(false);
    if (!citizenPromise) {
      citizenPromise = window.LPTApi.citizenSession().then((res) => Boolean(res.authenticated)).catch(() => false);
    }
    return citizenPromise;
  }

  function updateLoginLink() {
    if (!loginBtn) return;
    const base = (window.LPTApi && window.LPTApi.base) ? window.LPTApi.base : '';
    const next = '/fahndung.html' + (activeCase ? '#' + activeCase : '');
    loginBtn.href = base + '/api/citizen/auth/discord?next=' + encodeURIComponent(next);
  }

  list.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-hint-case]');
    if (!btn) return;
    activeCase = btn.getAttribute('data-hint-case');
    if (caseLabel) caseLabel.textContent = activeCase;
    if (titleLabel) titleLabel.textContent = btn.getAttribute('data-hint-title');
    updateLoginLink();
    if (form) form.reset();
    if (success) success.hidden = true;
    const authed = await checkCitizen();
    if (form) form.hidden = !authed;
    if (loginBox) loginBox.hidden = authed;
    app.openModal(modal);
    window.setTimeout(() => {
      if (authed) {
        const message = document.getElementById('hintMessage');
        if (message) message.focus();
      } else if (loginBtn) {
        loginBtn.focus();
      }
    }, 60);
  });

  if (form) {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const message = document.getElementById('hintMessage').value.trim();
      const name = document.getElementById('hintName').value.trim();
      const email = document.getElementById('hintEmail').value.trim();
      let number = '';
      try {
        if (!window.LPTApi) throw new Error('Server nicht erreichbar.');
        const res = await window.LPTApi.submitApplication('hint', { caseNo: activeCase, title: titleLabel ? titleLabel.textContent : '', message, name, email }, {
          applicantName: name || null,
          applicantEmail: email || null
        });
        number = (res && res.ref) || '';
        if (chatLink && res && res.id) chatLink.href = 'meine-tickets.html?ticket=' + res.id;
        app.toast('Ihr Hinweis wurde erfasst.', { title: 'Hinweis übermittelt' });
      } catch (err) {
        app.toast(err.message || 'Hinweis konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
        if (err.data && err.data.requiresDiscord) {
          if (form) form.hidden = true;
          if (loginBox) loginBox.hidden = false;
          updateLoginLink();
        }
        return;
      }
      if (ref) ref.textContent = number;
      form.hidden = true;
      if (success) success.hidden = false;
    });
  }
})();
