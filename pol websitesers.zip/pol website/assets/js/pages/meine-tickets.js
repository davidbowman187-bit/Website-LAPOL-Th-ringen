/* Bürgerkonto: Discord-Anmeldung, Ticketliste und Chat mit der Dienststelle */
(function () {
  'use strict';

  const app = window.LPTApp;
  const api = window.LPTApi;
  if (!app || !api) return;

  const $ = app.$;
  const $$ = app.$$;
  const esc = app.escapeHTML;

  const STATUS_LABELS = {
    eingegangen: 'Eingegangen',
    in_pruefung: 'In Prüfung',
    in_bearbeitung: 'In Bearbeitung',
    abgeschlossen: 'Abgeschlossen',
    abgelehnt: 'Abgelehnt'
  };
  const STATUS_CLASSES = {
    eingegangen: 'badge-blue',
    in_pruefung: 'badge-gold',
    in_bearbeitung: 'badge-gold',
    abgeschlossen: 'badge-green',
    abgelehnt: 'badge-red'
  };
  const TYPE_LABELS = {
    report: 'Strafanzeige',
    hint: 'Hinweis',
    strafanzeige: 'Strafanzeige',
    contact: 'Kontakt'
  };

  const state = {
    citizen: null,
    tickets: [],
    activeId: null,
    activeTicket: null,
    messages: [],
    lastThreadKey: '',
    pollTimer: null,
    listTimer: null,
    wantedId: Number(new URLSearchParams(window.location.search).get('ticket') || 0)
  };

  const gate = $('#accountGate');
  const accountApp = $('#accountApp');
  const loginBtn = $('#discordLoginBtn');
  const loginNotice = $('#loginNotice');
  const loginNoticeTitle = $('#loginNoticeTitle');
  const loginNoticeText = $('#loginNoticeText');
  const list = $('#myTicketList');
  const countBadge = $('#ticketCount');
  const chatEmpty = $('#ticketChatEmpty');
  const chatContent = $('#ticketChatContent');
  const chatThread = $('#chatThread');
  const chatForm = $('#chatForm');
  const chatMessage = $('#chatMessage');
  const chatSend = $('#chatSend');
  const chatClosed = $('#chatClosed');

  function loginUrl(next) {
    const target = next || (state.wantedId
      ? '/meine-tickets.html?ticket=' + encodeURIComponent(state.wantedId)
      : '/meine-tickets.html');
    return (api.base || '') + '/api/citizen/auth/discord?next=' + encodeURIComponent(target);
  }

  function statusBadge(status) {
    const label = STATUS_LABELS[status] || status || 'Unbekannt';
    const cls = STATUS_CLASSES[status] || 'badge-blue';
    return `<span class="badge ${cls}">${esc(label)}</span>`;
  }

  function ticketArt(t) {
    return (t.payload && t.payload.art) || TYPE_LABELS[t.type] || 'Onlinewache';
  }

  function ticketSubject(t) {
    const p = t.payload || {};
    const subject = p.subject || p.topic || p.ort || p.caseNo || p.title || '';
    return subject ? String(subject).slice(0, 120) : 'Onlinewache-Anliegen';
  }

  function showNotice(title, text) {
    if (!loginNotice) return;
    loginNoticeTitle.textContent = title;
    loginNoticeText.textContent = text;
    loginNotice.hidden = false;
  }

  function showGate() {
    if (gate) gate.hidden = false;
    if (accountApp) accountApp.hidden = true;
    if (loginBtn) loginBtn.href = loginUrl();
  }

  function showAccount(me) {
    state.citizen = me.citizen;
    if (gate) gate.hidden = true;
    if (accountApp) accountApp.hidden = false;
    const avatar = $('#accountAvatar');
    if (avatar) {
      avatar.src = state.citizen.avatarUrl || 'assets/img/wappen-thueringen.svg';
      avatar.alt = 'Discord-Profilbild von ' + (state.citizen.displayName || state.citizen.username);
    }
    const name = $('#accountName');
    if (name) name.textContent = state.citizen.displayName || state.citizen.username;
    const tag = $('#accountTag');
    if (tag) tag.textContent = '@' + state.citizen.username + ' · Discord';
    const status = $('#accountStatus');
    if (status) status.textContent = (me.tickets && me.tickets.open ? me.tickets.open + ' offen' : 'Verbunden');
  }

  function renderTicketList() {
    if (!list) return;
    if (countBadge) countBadge.textContent = String(state.tickets.length);
    if (!state.tickets.length) {
      list.innerHTML = `<div class="my-ticket-empty">
        <p><strong>Noch keine Tickets.</strong><br>Erstellen Sie Ihre erste Anzeige über die Onlinewache.</p>
        <a class="btn btn-navy btn-sm" href="onlinewache.html">Onlinewache öffnen</a>
      </div>`;
      return;
    }
    list.innerHTML = state.tickets.map((t) => {
      const active = Number(t.id) === Number(state.activeId);
      const preview = t.last_message
        ? (t.last_sender === 'police' ? 'Polizei: ' : 'Sie: ') + String(t.last_message).slice(0, 90)
        : 'Noch keine Nachrichten';
      return `<button type="button" class="my-ticket-item${active ? ' is-active' : ''}" data-ticket-id="${t.id}">
        <span class="my-ticket-top">
          <span class="my-ticket-ref">${esc(t.ref)}</span>
          ${statusBadge(t.status)}
        </span>
        <strong>${esc(ticketArt(t))} · ${esc(ticketSubject(t))}</strong>
        <span class="my-ticket-preview">${esc(preview)}${t.last_message && String(t.last_message).length > 90 ? ' …' : ''}</span>
        <span class="my-ticket-meta">${esc(new Date(t.updated_at || t.created_at).toLocaleString('de-DE'))} · ${Number(t.message_count || 0)} Nachricht${Number(t.message_count || 0) === 1 ? '' : 'en'}</span>
      </button>`;
    }).join('');
  }

  async function loadTickets(options) {
    const opts = options || {};
    const res = await api.getMyTickets();
    state.tickets = res.tickets || [];
    if (state.activeId && !state.tickets.some((t) => Number(t.id) === Number(state.activeId))) {
      state.activeId = null;
      state.activeTicket = null;
      state.messages = [];
      renderChat();
    }
    renderTicketList();
    if (opts.openWanted && state.wantedId && !state.activeId) {
      const match = state.tickets.find((t) => Number(t.id) === state.wantedId);
      if (match) await loadTicket(match.id);
      state.wantedId = 0;
    }
  }

  function messageMarkup(m) {
    const mine = m.sender === 'citizen';
    const name = mine ? 'Sie' : (m.author_name || 'Landespolizei Thüringen');
    const time = m.created_at ? new Date(m.created_at).toLocaleString('de-DE') : '';
    return `<div class="chat-message ${mine ? 'is-mine' : 'is-police'}">
      <div class="chat-message-head"><strong>${esc(name)}</strong><small>${esc(time)}</small></div>
      <p>${esc(m.message)}</p>
    </div>`;
  }

  function renderChat() {
    const t = state.activeTicket;
    if (!t) {
      if (chatEmpty) chatEmpty.hidden = false;
      if (chatContent) chatContent.hidden = true;
      return;
    }
    if (chatEmpty) chatEmpty.hidden = true;
    if (chatContent) chatContent.hidden = false;
    const art = $('#chatArt');
    if (art) art.textContent = ticketArt(t);
    const ref = $('#chatRef');
    if (ref) ref.textContent = t.ref;
    const subject = $('#chatSubject');
    if (subject) subject.textContent = ticketSubject(t);
    const status = $('#chatStatus');
    if (status) {
      status.className = 'badge ' + (STATUS_CLASSES[t.status] || 'badge-blue');
      status.textContent = STATUS_LABELS[t.status] || t.status;
    }
    if (chatThread) {
      chatThread.innerHTML = state.messages.length
        ? state.messages.map(messageMarkup).join('')
        : '<p class="form-note">Noch keine Nachrichten in diesem Ticket.</p>';
    }
    const canReply = Boolean(t.canReply);
    if (chatForm) chatForm.hidden = !canReply;
    if (chatClosed) chatClosed.hidden = canReply;
    if (chatMessage) chatMessage.disabled = !canReply;
    if (chatSend) chatSend.disabled = !canReply;
  }

  function scrollThreadToBottom() {
    if (!chatThread) return;
    chatThread.scrollTop = chatThread.scrollHeight;
  }

  async function loadTicket(id, options) {
    const opts = options || {};
    const res = await api.getMyTicket(id);
    const previousKey = state.lastThreadKey;
    state.activeId = Number(id);
    state.activeTicket = res.ticket;
    state.messages = res.messages || [];
    const key = state.messages.map((m) => m.id).join(',');
    state.lastThreadKey = key;
    renderTicketList();
    renderChat();
    const changed = key !== previousKey;
    if (!opts.silent || changed || opts.forceScroll) {
      window.requestAnimationFrame(scrollThreadToBottom);
    }
    if (!opts.silent && window.history && window.history.replaceState) {
      const url = new URL(window.location.href);
      url.searchParams.set('ticket', String(id));
      window.history.replaceState({}, '', url);
    }
    return changed;
  }

  async function openTicket(id) {
    if (!id) return;
    try {
      await loadTicket(id);
    } catch (err) {
      app.toast(err.message || 'Ticket konnte nicht geladen werden.', { type: 'error', title: 'Fehler' });
    }
  }

  if (list) {
    list.addEventListener('click', (event) => {
      const btn = event.target.closest('[data-ticket-id]');
      if (btn) openTicket(Number(btn.getAttribute('data-ticket-id')));
    });
  }

  if (chatForm) {
    chatForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const text = chatMessage.value.trim();
      if (!text) {
        app.toast('Bitte geben Sie eine Nachricht ein.', { type: 'error' });
        return;
      }
      chatSend.disabled = true;
      try {
        await api.sendMyTicketMessage(state.activeId, text);
        chatMessage.value = '';
        await loadTicket(state.activeId, { silent: true, forceScroll: true });
        await loadTickets();
        app.toast('Ihre Nachricht wurde an die Dienststelle übermittelt.', { title: 'Gesendet' });
      } catch (err) {
        app.toast(err.message || 'Nachricht konnte nicht gesendet werden.', { type: 'error', title: 'Fehler' });
      } finally {
        chatSend.disabled = false;
      }
    });
  }

  const logoutBtn = $('#accountLogout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try { await api.citizenLogout(); } catch (e) { /* ignore */ }
      window.location.href = 'meine-tickets.html';
    });
  }

  function startPolling() {
    if (state.pollTimer) window.clearInterval(state.pollTimer);
    if (state.listTimer) window.clearInterval(state.listTimer);
    state.pollTimer = window.setInterval(async () => {
      if (document.hidden || !state.citizen) return;
      if (state.activeId) {
        try { await loadTicket(state.activeId, { silent: true }); } catch (e) { /* ignore */ }
      }
    }, 5000);
    state.listTimer = window.setInterval(async () => {
      if (document.hidden || !state.citizen) return;
      try { await loadTickets(); } catch (e) { /* ignore */ }
    }, 20000);
  }

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && state.citizen) {
      if (state.activeId) loadTicket(state.activeId, { silent: true }).catch(() => {});
      loadTickets().catch(() => {});
    }
  });

  async function init() {
    const loginStatus = new URLSearchParams(window.location.search).get('login');
    if (loginBtn) loginBtn.href = loginUrl();
    if (loginStatus) {
      const notice = {
        abgebrochen: ['Anmeldung abgebrochen', 'Die Discord-Anmeldung wurde abgebrochen. Sie können es jederzeit erneut versuchen.'],
        state: ['Anmeldung abgelaufen', 'Die Anmeldung hat zu lange gedauert. Bitte starten Sie sie erneut.'],
        konfiguration: ['Discord-Anmeldung nicht verfügbar', 'Die Discord-Anmeldung ist derzeit nicht eingerichtet. Bitte wenden Sie sich an die Administration.'],
        fehler: ['Anmeldung fehlgeschlagen', 'Die Discord-Anmeldung ist fehlgeschlagen. Bitte versuchen Sie es erneut.']
      }[loginStatus];
      if (notice) showNotice(notice[0], notice[1]);
    }

    // Eine bestehende Sitzung hat Vorrang vor der Discord-Konfiguration
    try {
      const me = await api.citizenSession();
      if (me.authenticated) {
        showAccount(me);
        await loadTickets({ openWanted: true });
        startPolling();
        return;
      }
    } catch (err) {
      showGate();
      showNotice('Verbindung fehlgeschlagen', err.message || 'Das Bürgerkonto konnte nicht geladen werden.');
      return;
    }

    showGate();
    try {
      const config = await api.citizenConfig();
      if (!config.discordConfigured) {
        if (loginBtn) {
          loginBtn.removeAttribute('href');
          loginBtn.setAttribute('aria-disabled', 'true');
          loginBtn.classList.add('is-disabled');
          loginBtn.textContent = 'Discord-Anmeldung nicht eingerichtet';
        }
        if (!loginStatus) showNotice('Discord-Anmeldung nicht verfügbar', 'Die Anmeldung ist auf diesem System noch nicht eingerichtet. Bitte wenden Sie sich an die Administration.');
      }
    } catch (e) { /* Die Anmeldung kann trotzdem versucht werden. */ }
  }

  init();
})();
