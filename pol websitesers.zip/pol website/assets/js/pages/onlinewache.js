/* Onlinewache: mehrstufiges Formular */
(function () {
  'use strict';
  const app = window.LPTApp;
  const $ = app.$;
  const $$ = app.$$;
  const form = document.getElementById('onlinewacheForm');
  if (!form) return;

  const panels = $$('.step-panel', form);
  const indicators = $$('.stepper-item');
  const nextButtons = $$('[data-step-next]', form);
  const backButtons = $$('[data-step-back]', form);
  const summary = document.getElementById('owSummary');
  const formCard = document.getElementById('owFormCard');
  const success = document.getElementById('owSuccess');
  const caseNumber = document.getElementById('caseNumber');
  const anonymous = document.getElementById('owAnonymous');
  const contactFields = $$('[data-contact-field]');
  const emergencyCheck = document.getElementById('owEmergency');
  const emergencyNote = document.getElementById('owEmergencyNote');
  const loginGate = document.getElementById('owLoginGate');
  const loginBtn = document.getElementById('owDiscordLogin');
  const loginNotice = document.getElementById('owLoginNotice');
  const loginNoticeTitle = document.getElementById('owLoginNoticeTitle');
  const loginNoticeText = document.getElementById('owLoginNoticeText');
  const accountBar = document.getElementById('owAccountBar');
  const incidentWhen = document.getElementById('owIncidentWhen');
  const contactDetails = document.getElementById('owContactDetails');
  const incidentWhat = document.getElementById('owIncidentWhat');
  const contactMessageWrap = document.getElementById('owContactMessageWrap');
  const owOrt = document.getElementById('owOrt');
  const owPlz = document.getElementById('owPlz');
  const owZeit = document.getElementById('owZeit');
  const owText = document.getElementById('owText');
  const owBeteiligte = document.getElementById('owBeteiligte');
  const owContactTopic = document.getElementById('owContactTopic');
  const owContactSubject = document.getElementById('owContactSubject');
  const owContactMessage = document.getElementById('owContactMessage');
  const step2Title = document.getElementById('owStep2Title');
  const step3Title = document.getElementById('owStep3Title');
  const successTitle = document.getElementById('owSuccessTitle');
  let current = 0;

  function isContactMode() {
    const selected = form.querySelector('input[name="owArt"]:checked');
    return Boolean(selected && selected.value === 'kontakt');
  }

  function syncMode() {
    const contact = isContactMode();
    if (incidentWhen) incidentWhen.hidden = contact;
    if (contactDetails) contactDetails.hidden = !contact;
    if (incidentWhat) incidentWhat.hidden = contact;
    if (contactMessageWrap) contactMessageWrap.hidden = !contact;

    [owOrt, owZeit, owText].forEach((el) => {
      if (!el) return;
      el.required = !contact;
      el.disabled = contact;
    });
    [owPlz, owBeteiligte].forEach((el) => { if (el) el.disabled = contact; });
    [owContactTopic, owContactSubject, owContactMessage].forEach((el) => {
      if (!el) return;
      el.required = contact;
      el.disabled = !contact;
    });

    if (step2Title) step2Title.textContent = contact ? 'Worum geht es?' : 'Wo und wann ist es passiert?';
    if (step3Title) step3Title.textContent = contact ? 'Ihre Nachricht' : 'Was ist passiert?';
    if (successTitle) successTitle.textContent = contact ? 'Nachricht erfolgreich übermittelt' : 'Ticket erfolgreich übermittelt';

    const hintNotice = document.getElementById('owHintNotice');
    if (hintNotice) {
      const selected = form.querySelector('input[name="owArt"]:checked');
      hintNotice.hidden = !selected || selected.value !== 'hinweis';
    }
  }

  /* Discord-Konto prüfen: Ohne Anmeldung kein Ticket erstellen */
  async function initAuth() {
    const next = '/onlinewache.html';
    if (loginBtn) {
      loginBtn.href = ((window.LPTApi && window.LPTApi.base) ? window.LPTApi.base : '') +
        '/api/citizen/auth/discord?next=' + encodeURIComponent(next);
    }
    if (!window.LPTApi) {
      if (loginGate) loginGate.hidden = false;
      if (formCard) formCard.hidden = true;
      return;
    }

    // Bestehende Sitzung hat Vorrang (auch wenn die Discord-Konfiguration später fehlt)
    try {
      const session = await window.LPTApi.citizenSession();
      if (!session.authenticated) throw new Error('Nicht angemeldet');
      const citizen = session.citizen || {};
      if (loginGate) loginGate.hidden = true;
      if (formCard) formCard.hidden = false;
      if (accountBar) accountBar.hidden = false;
      const avatar = document.getElementById('owAccountAvatar');
      if (avatar && citizen.avatarUrl) {
        avatar.src = citizen.avatarUrl;
        avatar.alt = 'Discord-Profilbild von ' + (citizen.displayName || citizen.username);
      }
      const nameLabel = document.getElementById('owAccountName');
      if (nameLabel) nameLabel.textContent = citizen.displayName || citizen.username || 'Discord-Konto';
      const tagLabel = document.getElementById('owAccountTag');
      if (tagLabel) tagLabel.textContent = citizen.username ? '@' + citizen.username + ' · Discord' : 'Discord';
      return;
    } catch (err) {
      /* Nicht angemeldet – unten wird die Discord-Konfiguration geprüft. */
    }

    try {
      const config = await window.LPTApi.citizenConfig();
      if (!config.discordConfigured) {
        if (loginGate) loginGate.hidden = false;
        if (formCard) formCard.hidden = true;
        if (loginBtn) {
          loginBtn.removeAttribute('href');
          loginBtn.setAttribute('aria-disabled', 'true');
          loginBtn.classList.add('is-disabled');
          loginBtn.textContent = 'Discord-Anmeldung nicht eingerichtet';
        }
        if (loginNotice && loginNoticeTitle && loginNoticeText) {
          loginNoticeTitle.textContent = 'Discord-Anmeldung nicht verfügbar';
          loginNoticeText.textContent = 'Die Anmeldung ist auf diesem System noch nicht eingerichtet. Bitte wenden Sie sich an die Administration.';
          loginNotice.hidden = false;
        }
        return;
      }
    } catch (e) { /* Gate trotzdem anzeigen */ }

    if (loginGate) loginGate.hidden = false;
    if (formCard) formCard.hidden = true;
    if (accountBar) accountBar.hidden = true;
  }

  function goTo(index) {
    current = Math.max(0, Math.min(index, panels.length - 1));
    panels.forEach((panel, i) => panel.classList.toggle('is-active', i === current));
    indicators.forEach((item, i) => {
      item.classList.toggle('is-active', i === current);
      item.classList.toggle('is-done', i < current);
    });
    if (current === panels.length - 1) buildSummary();
    const card = formCard;
    if (card) {
      const top = card.getBoundingClientRect().top + window.scrollY - 90;
      if (window.scrollY > top + 10) window.scrollTo({ top, behavior: 'smooth' });
    }
  }

  function validatePanel(index) {
    const panel = panels[index];
    const required = $$('input, select, textarea', panel).filter((el) => el.required && !el.disabled);
    for (const el of required) {
      if (!el.checkValidity()) {
        el.reportValidity();
        return false;
      }
    }
    if (index === 0) {
      const selected = form.querySelector('input[name="owArt"]:checked');
      if (!selected) {
        app.toast('Bitte wählen Sie die Art Ihres Anliegens aus.', { type: 'error' });
        return false;
      }
    }
    return true;
  }

  nextButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      if (validatePanel(current)) goTo(current + 1);
    });
  });

  backButtons.forEach((btn) => {
    btn.addEventListener('click', () => goTo(current - 1));
  });

  /* Anonymität steuert Kontaktfelder */
  function syncAnonymous() {
    const isAnon = anonymous.checked;
    contactFields.forEach((field) => {
      const input = $('input', field);
      if (!input) return;
      input.required = !isAnon && !input.hasAttribute('data-optional');
      field.classList.toggle('is-optional', isAnon);
    });
    const note = document.getElementById('owContactNote');
    if (note) note.hidden = !isAnon;
  }
  if (anonymous) anonymous.addEventListener('change', syncAnonymous);

  if (emergencyCheck && emergencyNote) {
    emergencyCheck.addEventListener('change', () => {
      emergencyNote.hidden = !emergencyCheck.checked;
    });
  }

  /* Vorauswahl über #hinweis */
  if (window.location.hash === '#hinweis') {
    const hint = form.querySelector('input[name="owArt"][value="hinweis"]');
    if (hint) hint.checked = true;
    const notice = document.getElementById('owHintNotice');
    if (notice) notice.hidden = false;
  }

  $$('input[name="owArt"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      syncMode();
    });
  });

  function labelFor(name) {
    const selected = form.querySelector(`input[name="${name}"]:checked`);
    if (!selected) return '–';
    const label = selected.closest('.choice');
    if (!label) return selected.value;
    const strong = $('strong', label);
    return strong ? strong.textContent.trim() : selected.value;
  }

  function buildSummary() {
    if (!summary) return;
    const name = $('#owName').value.trim();
    const email = $('#owEmail').value.trim();
    const phone = $('#owPhone').value.trim();
    const isAnon = anonymous.checked;
    const contactBits = [name, email, phone].filter(Boolean).map((value) => app.escapeHTML(value)).join(' · ');
    const contactLine = isAnon
      ? 'Anonym – keine Kontaktdaten angegeben'
      : (contactBits || 'Keine Kontaktdaten angegeben');

    if (isContactMode()) {
      const topic = owContactTopic ? owContactTopic.value : '';
      const subject = owContactSubject ? owContactSubject.value.trim() : '';
      const message = owContactMessage ? owContactMessage.value.trim() : '';
      summary.innerHTML = `
        <div class="summary-row"><dt>Anliegen</dt><dd>${app.escapeHTML(labelFor('owArt'))}</dd></div>
        <div class="summary-row"><dt>Thema</dt><dd>${app.escapeHTML(topic || '–')}</dd></div>
        <div class="summary-row"><dt>Betreff</dt><dd>${app.escapeHTML(subject || '–')}</dd></div>
        <div class="summary-row"><dt>Nachricht</dt><dd>${app.escapeHTML(message)}</dd></div>
        <div class="summary-row"><dt>Kontakt</dt><dd>${contactLine}</dd></div>
      `;
      return;
    }

    const ort = $('#owOrt').value.trim();
    const plz = $('#owPlz').value.trim();
    const zeit = $('#owZeit').value;
    const text = $('#owText').value.trim();
    const beteiligte = $('#owBeteiligte').value.trim();
    let when = '–';
    if (zeit) {
      try {
        when = new Intl.DateTimeFormat('de-DE', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(zeit));
      } catch (e) { when = zeit; }
    }
    summary.innerHTML = `
      <div class="summary-row"><dt>Anliegen</dt><dd>${app.escapeHTML(labelFor('owArt'))}</dd></div>
      <div class="summary-row"><dt>Tatort</dt><dd>${app.escapeHTML(ort)}${plz ? ', ' + app.escapeHTML(plz) : ''}</dd></div>
      <div class="summary-row"><dt>Tatzeitpunkt</dt><dd>${app.escapeHTML(when)}</dd></div>
      <div class="summary-row"><dt>Sachverhalt</dt><dd>${app.escapeHTML(text)}</dd></div>
      <div class="summary-row"><dt>Beteiligte / Fahrzeuge</dt><dd>${app.escapeHTML(beteiligte || 'Keine Angabe')}</dd></div>
      <div class="summary-row"><dt>Kontakt</dt><dd>${contactLine}</dd></div>
    `;
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!validatePanel(current)) return;
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    buildSummary();
    const contact = isContactMode();
    const artValue = (form.querySelector('input[name="owArt"]:checked') || {}).value || 'anzeige';
    const name = $('#owName').value.trim();
    const email = $('#owEmail').value.trim();
    const phone = $('#owPhone').value.trim();
    const isAnon = anonymous.checked;
    let type = artValue === 'hinweis' ? 'hint' : 'report';
    let payload;
    if (contact) {
      type = 'contact';
      payload = {
        art: labelFor('owArt'),
        topic: owContactTopic ? owContactTopic.value : '',
        subject: owContactSubject ? owContactSubject.value.trim() : '',
        message: owContactMessage ? owContactMessage.value.trim() : '',
        station: 'erfurt-zentrum',
        name: isAnon ? null : name,
        email: isAnon ? null : email,
        phone: isAnon ? null : phone,
        anonymous: isAnon
      };
    } else {
      payload = {
        art: labelFor('owArt'),
        ort: $('#owOrt').value.trim(),
        plz: $('#owPlz').value.trim(),
        zeit: $('#owZeit').value,
        text: $('#owText').value.trim(),
        beteiligte: $('#owBeteiligte').value.trim(),
        name: isAnon ? null : name,
        email: isAnon ? null : email,
        phone: isAnon ? null : phone,
        anonymous: isAnon
      };
    }
    let ref = '';
    let ticketId = null;
    try {
      if (!window.LPTApi) throw new Error('Server nicht erreichbar.');
      const res = await window.LPTApi.submitApplication(type, payload, {
        applicantName: isAnon ? null : name,
        applicantEmail: isAnon ? null : email,
        stationId: contact ? 'erfurt-zentrum' : null
      });
      ref = (res && res.ref) || '';
      ticketId = (res && res.id) || null;
      app.toast(contact ? 'Ihre Nachricht wurde als Ticket übermittelt.' : 'Ihre Anzeige wurde erfasst und als Ticket übermittelt.', { title: contact ? 'Nachricht übermittelt' : 'Anzeige übermittelt' });
    } catch (err) {
      app.toast(err.message || 'Anliegen konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
      if (err.data && err.data.requiresDiscord) {
        if (loginGate) loginGate.hidden = false;
        if (formCard) formCard.hidden = true;
      }
      return;
    }
    if (caseNumber) caseNumber.textContent = ref;
    const statusLink = document.getElementById('owStatusLink');
    if (statusLink) statusLink.href = ticketId ? 'meine-tickets.html?ticket=' + ticketId : 'meine-tickets.html';
    const publicStatusLink = document.getElementById('owPublicStatusLink');
    if (publicStatusLink && ref) publicStatusLink.href = 'service.html?ref=' + encodeURIComponent(ref) + '#status';
    if (formCard) formCard.hidden = true;
    if (success) {
      success.hidden = false;
      success.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });

  const resetBtn = document.getElementById('owReset');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      if (emergencyNote) emergencyNote.hidden = true;
      syncMode();
      syncAnonymous();
      current = 0;
      goTo(0);
      if (success) success.hidden = true;
      if (formCard) formCard.hidden = false;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  syncMode();
  syncAnonymous();
  goTo(0);
  initAuth();
})();
