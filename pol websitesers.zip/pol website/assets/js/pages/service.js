/* Service page – Führungszeugnis, Vorgangsstatus, Formularfilter und Termin */
(function () {
  'use strict';

  const app = window.LPTApp;
  if (!app) return;

  const pad = (value, length) => String(value).padStart(length, '0');

  /* ---------- Führungszeugnis ---------- */
  const fzForm = document.getElementById('fzForm');
  const fzSuccess = document.getElementById('fzSuccess');
  const fzRef = document.getElementById('fzRef');
  const fzReset = document.getElementById('fzReset');
  const fzExtraNote = document.getElementById('fzExtraNote');
  const fzDownload = document.getElementById('fzDownload');

  app.$$('input[name="fzType"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      if (fzExtraNote) fzExtraNote.hidden = radio.value !== 'erweitert';
    });
  });

  if (fzForm && fzSuccess && fzRef) {
    fzForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!fzForm.reportValidity()) return;
      if (!window.LPTApi) {
        app.toast('Der Antragsserver ist nicht erreichbar.', { type: 'error', title: 'Fehler' });
        return;
      }
      const type = (fzForm.querySelector('input[name="fzType"]:checked') || {}).value || 'privat';
      const payload = {
        type,
        first: document.getElementById('fzFirst').value.trim(),
        last: document.getElementById('fzLast').value.trim(),
        birth: document.getElementById('fzBirth').value,
        birthplace: document.getElementById('fzBirthplace').value.trim(),
        street: document.getElementById('fzStreet').value.trim(),
        zip: document.getElementById('fzZip').value.trim(),
        city: document.getElementById('fzCity').value.trim(),
        email: document.getElementById('fzEmail').value.trim()
      };
      try {
        const res = await window.LPTApi.submitApplication('leading_certificate', payload, {
          applicantName: payload.first + ' ' + payload.last,
          applicantEmail: payload.email,
          applicantBirth: payload.birth
        });
        if (fzDownload) {
          if (res && res.document && res.document.url) {
            fzDownload.href = (window.LPTApi.base || '') + res.document.url;
            fzDownload.setAttribute('download', res.document.filename || 'Fuehrungszeugnis.pdf');
            fzDownload.hidden = false;
          } else {
            fzDownload.hidden = true;
          }
        }
        fzRef.textContent = res.ref;
        fzForm.hidden = true;
        fzSuccess.hidden = false;
        fzSuccess.setAttribute('tabindex', '-1');
        fzSuccess.focus({ preventScroll: true });
        app.toast('Ihr Antrag auf ein Führungszeugnis wurde erfasst.', { title: 'Antrag übermittelt' });
      } catch (err) {
        if (fzDownload) fzDownload.hidden = true;
        app.toast(err.message || 'Antrag konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
      }
    });
  }

  if (fzReset) {
    fzReset.addEventListener('click', () => {
      if (!fzForm) return;
      fzForm.reset();
      fzForm.hidden = false;
      fzSuccess.hidden = true;
      if (fzExtraNote) fzExtraNote.hidden = true;
      if (fzDownload) { fzDownload.hidden = true; fzDownload.removeAttribute('href'); }
      const first = app.$('input, select, textarea', fzForm);
      if (first) first.focus({ preventScroll: true });
    });
  }

  /* ---------- Vorgangsstatus ---------- */
  const statusForm = document.getElementById('statusForm');
  const statusResult = document.getElementById('statusResult');
  const statusRef = document.getElementById('statusRef');
  const statusBirth = document.getElementById('statusBirth');
  const statusReset = document.getElementById('statusReset');

  function renderStatusFromApi(data) {
    const steps = ['eingegangen', 'in_pruefung', 'in_bearbeitung', 'abgeschlossen'];
    const currentIndex = Math.max(0, steps.indexOf(data.status));
    const statusLabels = {
      eingegangen: 'Eingegangen',
      in_pruefung: 'In Prüfung',
      in_bearbeitung: 'In Bearbeitung',
      abgeschlossen: 'Abgeschlossen',
      abgelehnt: 'Abgelehnt'
    };
    const labels = [
      ['Eingang bestätigt', 'Ihr Anliegen ist bei der Landespolizei eingegangen.'],
      ['Prüfung', 'Die Zuständigkeit und die Angaben wurden geprüft.'],
      ['Bearbeitung', 'Ihr Vorgang wird derzeit bearbeitet.'],
      ['Abschluss', 'Sie erhalten eine Rückmeldung, sobald der Vorgang abgeschlossen ist.']
    ];
    const messages = Array.isArray(data.messages) ? data.messages : [];
    statusResult.className = 'status-result';
    statusResult.innerHTML = `
      <div class="status-result-head">
        <span class="badge badge-green">${app.escapeHTML(statusLabels[data.status] || data.status)}</span>
        <small>Abgefragt am ${new Date().toLocaleDateString('de-DE')}</small>
      </div>
      <h3>${app.escapeHTML(data.ref)}</h3>
      <p>${app.escapeHTML(data.statusText || '')}</p>
      <ol class="status-timeline">
        ${labels.map((label, i) => {
          const state = i < currentIndex ? 'is-done' : i === currentIndex ? 'is-active' : '';
          return `<li class="${state}"><span class="status-timeline-dot"></span><div><strong>${label[0]}</strong><small>${label[1]}</small></div></li>`;
        }).join('')}
      </ol>
      ${messages.length ? `
        <div class="status-messages">
          <h4>Nachrichten der Dienststelle</h4>
          ${messages.map((m) => `<div class="status-message"><strong>${app.escapeHTML(m.author_name || 'Landespolizei Thüringen')}</strong><small>${new Date(m.created_at).toLocaleString('de-DE')}</small><p>${app.escapeHTML(m.message)}</p></div>`).join('')}
        </div>` : ''}
      <p class="status-result-note">Quelle: Intranet-Datenbank der Landespolizei Thüringen.</p>`;
    statusResult.hidden = false;
  }

  function renderStatusError(message) {
    statusResult.className = 'status-result is-error';
    statusResult.innerHTML = `
      <div class="status-result-head">
        <span class="badge badge-red">Nicht gefunden</span>
        <small>Statusabfrage</small>
      </div>
      <h3>Aktenzeichen nicht erkannt</h3>
      <p>${app.escapeHTML(message || 'Bitte prüfen Sie das Aktenzeichen und versuchen Sie es erneut.')}</p>
      <p class="status-result-note">Beispiel: FZ/2026/000001 · ST/2026/000002 · KO/2026/000003</p>`;
    statusResult.hidden = false;
  }

  async function submitStatus() {
    if (!statusForm || !statusResult) return;
    if (!statusForm.reportValidity()) return;
    const ref = statusRef.value.trim();
    const birth = statusBirth.value;
    try {
      if (!window.LPTApi) throw new Error('Der Statusserver ist nicht erreichbar.');
      const data = await window.LPTApi.getStatus(ref, birth);
      statusRef.removeAttribute('aria-invalid');
      renderStatusFromApi(data);
      app.toast('Der Vorgangsstatus wurde geladen.', { title: 'Status abgerufen' });
      statusResult.setAttribute('tabindex', '-1');
      statusResult.focus({ preventScroll: true });
    } catch (err) {
      statusRef.setAttribute('aria-invalid', 'true');
      renderStatusError(err.message || 'Bitte prüfen Sie das Aktenzeichen.');
      app.toast('Aktenzeichen nicht gefunden.', { type: 'error', title: 'Statusabfrage' });
    }
  }

  if (statusForm && statusResult) {
    statusForm.addEventListener('submit', (event) => {
      event.preventDefault();
      submitStatus();
    });
  }
  if (statusReset) {
    statusReset.addEventListener('click', () => {
      if (!statusForm) return;
      statusForm.reset();
      statusResult.hidden = true;
      statusRef.removeAttribute('aria-invalid');
      statusRef.focus();
    });
  }

  // Vorbelegung aus der Onlinewache: service.html?ref=FZ/2026/000001#status
  const initialRef = new URLSearchParams(window.location.search).get('ref');
  if (initialRef && statusRef) {
    statusRef.value = initialRef;
    if (window.location.hash === '#status') {
      setTimeout(submitStatus, 250);
    }
  }

  /* ---------- Formular-Filter ---------- */
  const formsSearch = document.getElementById('formsSearch');
  const formsCount = document.getElementById('formsCount');
  const formsEmpty = document.getElementById('formsEmpty');
  const formsReset = document.getElementById('formsReset');
  const formRows = app.$$('[data-form-row]');
  let formArea = 'alle';

  function updateForms() {
    const term = app.normalize(formsSearch ? formsSearch.value : '');
    let visible = 0;
    formRows.forEach((row) => {
      const areaMatch = formArea === 'alle' || row.getAttribute('data-area') === formArea;
      const text = app.normalize(`${row.getAttribute('data-search')} ${row.textContent}`);
      const textMatch = !term || text.includes(term);
      const show = areaMatch && textMatch;
      row.hidden = !show;
      if (show) visible += 1;
    });
    if (formsCount) formsCount.textContent = `${visible} ${visible === 1 ? 'Leistung' : 'Leistungen'}`;
    if (formsEmpty) formsEmpty.hidden = visible !== 0;
  }

  app.$$('[data-form-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      formArea = btn.getAttribute('data-form-filter');
      app.$$('[data-form-filter]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
      updateForms();
    });
  });

  if (formsSearch) formsSearch.addEventListener('input', updateForms);
  if (formsReset) {
    formsReset.addEventListener('click', () => {
      formArea = 'alle';
      if (formsSearch) formsSearch.value = '';
      app.$$('[data-form-filter]').forEach((b) => b.setAttribute('aria-pressed', String(b.getAttribute('data-form-filter') === 'alle')));
      updateForms();
    });
  }

  /* ---------- Termin ---------- */
  const apptForm = document.getElementById('apptForm');
  const apptSuccess = document.getElementById('apptSuccess');
  const apptRef = document.getElementById('apptRef');
  const apptReset = document.getElementById('apptReset');
  const apptStation = document.getElementById('apptStation');
  const apptDate = document.getElementById('apptDate');

  if (apptStation) {
    (window.LPT.stations || []).forEach((station) => {
      const option = document.createElement('option');
      option.value = station.id;
      option.textContent = `${station.name} · ${station.city}`;
      apptStation.appendChild(option);
    });
  }

  if (apptDate) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    apptDate.min = `${tomorrow.getFullYear()}-${pad(tomorrow.getMonth() + 1, 2)}-${pad(tomorrow.getDate(), 2)}`;
  }

  if (apptForm && apptSuccess && apptRef) {
    apptForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!apptForm.reportValidity()) return;
      if (!window.LPTApi) {
        app.toast('Der Terminserver ist nicht erreichbar.', { type: 'error', title: 'Fehler' });
        return;
      }
      const payload = {
        station: apptStation.value,
        topic: document.getElementById('apptTopic').value,
        date: document.getElementById('apptDate').value,
        time: document.getElementById('apptTime').value,
        name: document.getElementById('apptName').value.trim(),
        email: document.getElementById('apptMail').value.trim(),
        note: document.getElementById('apptNote').value.trim()
      };
      try {
        const res = await window.LPTApi.submitApplication('appointment', payload, {
          applicantName: payload.name,
          applicantEmail: payload.email,
          stationId: payload.station
        });
        apptRef.textContent = res.ref;
        apptForm.hidden = true;
        apptSuccess.hidden = false;
        apptSuccess.setAttribute('tabindex', '-1');
        apptSuccess.focus({ preventScroll: true });
        app.toast('Ihre Terminanfrage wurde erfasst.', { title: 'Termin angefragt' });
      } catch (err) {
        app.toast(err.message || 'Terminanfrage konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
      }
    });
  }

  if (apptReset) {
    apptReset.addEventListener('click', () => {
      if (!apptForm) return;
      apptForm.reset();
      apptForm.hidden = false;
      apptSuccess.hidden = true;
      if (apptStation) apptStation.focus({ preventScroll: true });
    });
  }
})();
