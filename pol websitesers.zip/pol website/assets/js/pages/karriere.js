/* Karriere page – Bewerbung, Phasenstatus und Dateianlagen */
(function () {
  'use strict';

  const app = window.LPTApp;
  const api = window.LPTApi;
  if (!app || !api) return;

  const modal = document.getElementById('applyModal');
  const form = document.getElementById('applyForm');
  const success = document.getElementById('applySuccess');
  const ref = document.getElementById('applyRef');
  const pathSelect = document.getElementById('applyPath');
  const resetBtn = document.getElementById('applyReset');
  const phaseBanner = document.getElementById('careerPhaseStatus');
  const phaseNotice = document.getElementById('applyPhaseNotice');
  const phaseNoticeText = document.getElementById('applyPhaseNoticeText');
  if (!modal || !form || !success || !ref) return;

  const submitBtn = form.querySelector('button[type="submit"]');
  let phases = [];

  function phaseFor(label) {
    const value = String(label || '').trim().toLowerCase();
    return phases.find((p) => String(p.label).trim().toLowerCase() === value);
  }

  function allClosed() {
    return phases.length > 0 && phases.every((p) => !p.isOpen);
  }

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('Datei konnte nicht gelesen werden.'));
      reader.readAsDataURL(file);
    });
  }

  function updatePhaseNotice() {
    if (!phaseNotice || !phaseNoticeText) return;
    const phase = phaseFor(pathSelect ? pathSelect.value : '');
    if (phase && !phase.isOpen) {
      phaseNoticeText.textContent = `Der Bereich „${phase.label}“ ist derzeit geschlossen. Bitte wähle einen offenen Bereich.`;
      phaseNotice.hidden = false;
    } else {
      phaseNotice.hidden = true;
    }
    if (submitBtn) submitBtn.disabled = Boolean(phase && !phase.isOpen) || allClosed();
  }

  async function loadPhases() {
    if (!phaseBanner) return;
    try {
      const res = await api.getRecruitmentPhases();
      phases = res.phases || [];
      if (phaseBanner) {
        phaseBanner.innerHTML = phases.map((p) => `
          <div class="recruitment-phase ${p.isOpen ? 'is-open' : 'is-closed'}">
            <span class="recruitment-dot"></span>
            <strong>${app.escapeHTML(p.label)}</strong>
            <span>${p.isOpen ? 'Bewerbungen offen' : 'Bewerbungen geschlossen'}</span>
          </div>`).join('');
      }
      app.$$('[data-phase-badge]').forEach((badge) => {
        const phase = phaseFor(badge.getAttribute('data-phase-badge'));
        if (!phase) return;
        badge.textContent = phase.isOpen ? 'Bewerbungsphase offen' : 'Bewerbungsphase geschlossen';
        badge.classList.toggle('is-open', phase.isOpen);
        badge.classList.toggle('is-closed', !phase.isOpen);
      });
      app.$$('[data-apply-path]').forEach((btn) => {
        const phase = phaseFor(btn.getAttribute('data-apply-path'));
        if (!phase) return;
        const closed = !phase.isOpen;
        btn.disabled = closed;
        btn.classList.toggle('is-closed', closed);
        if (closed) btn.textContent = 'Bewerbung geschlossen';
      });
      if (pathSelect) {
        Array.from(pathSelect.options).forEach((opt) => {
          const phase = phaseFor(opt.value);
          if (!phase) return;
          opt.textContent = `${phase.label} – ${phase.isOpen ? 'offen' : 'geschlossen'}`;
          opt.disabled = !phase.isOpen;
        });
        const selected = phaseFor(pathSelect.value);
        if (selected && !selected.isOpen) {
          const firstOpen = phases.find((p) => p.isOpen);
          pathSelect.value = firstOpen ? firstOpen.label : '';
        }
      }
      updatePhaseNotice();
    } catch (e) {
      if (phaseBanner) phaseBanner.innerHTML = '<div class="recruitment-phase is-closed"><strong>Bewerbungsstatus konnte nicht geladen werden.</strong></div>';
    }
  }

  // Preselect the career path when a path card opens the modal.
  app.$$('[data-apply-path]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const value = btn.getAttribute('data-apply-path');
      if (pathSelect && value) pathSelect.value = value;
      window.setTimeout(updatePhaseNotice, 60);
    });
  });
  if (pathSelect) pathSelect.addEventListener('change', updatePhaseNotice);

  document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-modal-open="#applyModal"]');
    if (!opener) return;
    if (allClosed()) {
      event.preventDefault();
      event.stopPropagation();
      app.toast('Die Bewerbungsphase ist derzeit für alle Bereiche geschlossen.', { type: 'error', title: 'Bewerbung geschlossen' });
      return;
    }
    window.setTimeout(updatePhaseNotice, 60);
  }, true);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const path = pathSelect ? pathSelect.value : '';
    const phase = phaseFor(path);
    if (phase && !phase.isOpen) {
      app.toast(`Der Bereich „${phase.label}“ ist geschlossen.`, { type: 'error', title: 'Bewerbung geschlossen' });
      return;
    }

    const first = document.getElementById('applyFirst').value.trim();
    const last = document.getElementById('applyLast').value.trim();
    const birth = document.getElementById('applyBirth').value;
    const email = document.getElementById('applyMail').value.trim();
    const phone = document.getElementById('applyPhone').value.trim();
    const motivation = document.getElementById('applyMotivation').value.trim();
    const cv = document.getElementById('applyCv').files[0];
    const letter = document.getElementById('applyLetter').files[0];
    if (!cv || !letter) {
      app.toast('Bitte Lebenslauf und Anschreiben hochladen.', { type: 'error', title: 'Dateien fehlen' });
      return;
    }
    const allowed = ['application/pdf', 'image/jpeg', 'image/png'];
    for (const file of [cv, letter]) {
      if (!allowed.includes(file.type)) {
        app.toast('Erlaubt sind PDF-, JPG- und PNG-Dateien.', { type: 'error', title: 'Dateityp' });
        return;
      }
      if (file.size > 4 * 1024 * 1024) {
        app.toast('Eine Datei darf höchstens 4 MB groß sein.', { type: 'error', title: 'Datei zu groß' });
        return;
      }
    }

    let files;
    try {
      files = [
        { kind: 'lebenslauf', filename: cv.name, mime: cv.type, data: await fileToBase64(cv) },
        { kind: 'anschreiben', filename: letter.name, mime: letter.type, data: await fileToBase64(letter) }
      ];
    } catch (err) {
      app.toast(err.message || 'Dateien konnten nicht gelesen werden.', { type: 'error', title: 'Fehler' });
      return;
    }

    const payload = { path, first, last, birth, email, phone, motivation };
    let refValue = '';
    try {
      const res = await api.submitApplication('career', payload, {
        applicantName: first + ' ' + last,
        applicantEmail: email,
        applicantBirth: birth,
        files
      });
      refValue = (res && res.ref) || '';
      app.toast('Deine Bewerbung inklusive Unterlagen wurde erfasst.', { title: 'Bewerbung erfasst' });
    } catch (err) {
      app.toast(err.message || 'Bewerbung konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
      return;
    }
    ref.textContent = refValue;
    form.hidden = true;
    success.hidden = false;
    success.setAttribute('tabindex', '-1');
    success.focus({ preventScroll: true });
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      form.hidden = false;
      success.hidden = true;
      if (phaseNotice) phaseNotice.hidden = true;
      if (pathSelect) {
        const firstOpen = phases.find((p) => p.isOpen);
        if (firstOpen) pathSelect.value = firstOpen.label;
      }
      updatePhaseNotice();
      const first = form.querySelector('select, input, textarea');
      if (first) first.focus({ preventScroll: true });
    });
  }

  loadPhases();
})();
