/* Kontakt page – interactive station finder and contact form */
(function () {
  'use strict';

  const app = window.LPTApp;
  if (!app) return;

  let stations = (window.LPT.stations || []).slice();

  async function loadStations() {
    if (window.LPTApi) {
      try {
        const res = await window.LPTApi.request('/api/stations');
        if (Array.isArray(res.stations) && res.stations.length) {
          stations = res.stations.map((s) => ({
            id: s.id,
            name: s.name,
            city: s.city,
            region: s.region,
            address: s.address,
            phone: s.phone,
            email: s.email,
            hours: s.hours,
            services: Array.isArray(s.services) ? s.services : (() => {
              try { return JSON.parse(s.services || '[]'); } catch (e) { return []; }
            })(),
            x: s.x,
            y: s.y
          }));
          const sel = document.getElementById('contactStation');
          if (sel) {
            sel.innerHTML = '<option value="">Keine bestimmte Dienststelle</option>';
            stations.forEach((st) => {
              const o = document.createElement('option');
              o.value = st.id;
              o.textContent = st.name;
              sel.appendChild(o);
            });
          }        }
      } catch (e) { /* static fallback */ }
    }
    render();
  }
  const list = document.getElementById('stationList');
  const pins = document.getElementById('stationPins');
  const detailBody = document.getElementById('stationDetailBody');
  const search = document.getElementById('stationSearch');
  const region = document.getElementById('stationRegion');
  const reset = document.getElementById('stationReset');
  const count = document.getElementById('stationCount');
  if (!list || !pins || !detailBody) return;

  let activeId = stations[0] ? stations[0].id : null;

  function matches(station) {
    const term = app.normalize(search ? search.value : '');
    const regionValue = region ? region.value : 'alle';
    if (regionValue !== 'alle' && station.region !== regionValue) return false;
    if (!term) return true;
    return app.normalize(`${station.name} ${station.city} ${station.region} ${station.address} ${station.services.join(' ')}`).includes(term);
  }

  function cardMarkup(station) {
    return `<a class="station-card${station.id === activeId ? ' is-active' : ''}" href="#${station.id}" data-station-id="${station.id}"${station.id === activeId ? ' aria-current="true"' : ''}>
      <h3>${app.escapeHTML(station.name)}</h3>
      <span class="station-address">${app.ICON('map-pin')}<span>${app.escapeHTML(station.address)}</span></span>
      <div class="station-tags">${station.services.map((s) => `<span>${app.escapeHTML(s)}</span>`).join('')}</div>
    </a>`;
  }

  function pinMarkup(station) {
    return `<button type="button" class="map-pin${station.id === activeId ? ' is-active' : ''}" style="left:${station.x}%;top:${station.y}%" data-station-id="${station.id}" aria-label="${app.escapeHTML(station.name)}, ${app.escapeHTML(station.city)}" title="${app.escapeHTML(station.city)}"></button>`;
  }

  function detailMarkup(station) {
    return `<h2>${app.escapeHTML(station.name)}</h2>
      <p class="station-address">${app.ICON('map-pin')} ${app.escapeHTML(station.address)}</p>
      <div class="contact-mini">
        <span>${app.ICON('clock')}<span>${app.escapeHTML(station.hours)}<small>Öffnungszeiten</small></span></span>
      </div>
      <div class="station-services">${station.services.map((s) => `<span>${app.escapeHTML(s)}</span>`).join('')}</div>
      <div class="form-actions" style="margin-top:16px">
        <a class="btn btn-navy btn-sm" href="kontakt.html#formular">Kontaktformular ${app.ICON('mail')}</a>
        <button type="button" class="btn btn-ghost btn-sm" data-station-route="${app.escapeHTML(station.id)}">Route planen ${app.ICON('map-pin')}</button>
      </div>
      <p style="margin-top:12px;color:var(--muted-light);font-size:11px">Kontaktanfragen werden über das Formular an die Dienststelle übermittelt.</p>`;
  }

  function render() {
    const visible = stations.filter(matches);
    if (!visible.some((s) => s.id === activeId) && visible.length) activeId = visible[0].id;

    list.innerHTML = visible.length
      ? visible.map(cardMarkup).join('')
      : `<div class="empty-state">${app.ICON('search')}<p><strong>Keine Dienststelle gefunden.</strong><br>Versuchen Sie einen anderen Ort oder setzen Sie die Filter zurück.</p></div>`;

    pins.innerHTML = visible.map(pinMarkup).join('');

    const active = stations.find((s) => s.id === activeId) || visible[0];
    if (active) {
      detailBody.innerHTML = detailMarkup(active);
    } else {
      detailBody.innerHTML = `<p style="color:var(--muted)">Keine Dienststelle ausgewählt.</p>`;
    }

    if (count) count.textContent = `${visible.length} ${visible.length === 1 ? 'Dienststelle' : 'Dienststellen'}`;
  }

  function selectStation(id, options = {}) {
    const station = stations.find((s) => s.id === id);
    if (!station) return;
    activeId = id;
    if (options.scroll) {
      const detail = document.getElementById('stationDetail');
      if (detail && window.innerWidth < 980) {
        detail.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
    if (options.updateHash !== false) {
      try {
        history.replaceState(null, '', `#${id}`);
      } catch (e) {
        window.location.hash = id;
      }
    }
    render();
  }

  list.addEventListener('click', (event) => {
    const card = event.target.closest('[data-station-id]');
    if (!card) return;
    event.preventDefault();
    selectStation(card.getAttribute('data-station-id'), { scroll: true });
  });

  pins.addEventListener('click', (event) => {
    const pin = event.target.closest('[data-station-id]');
    if (!pin) return;
    selectStation(pin.getAttribute('data-station-id'));
  });

  document.addEventListener('click', (event) => {
    const route = event.target.closest('[data-station-route]');
    if (!route) return;
    const station = stations.find((s) => s.id === route.getAttribute('data-station-route'));
    if (!station) return;
    const url = 'https://www.openstreetmap.org/search?query=' + encodeURIComponent(station.address);
    window.open(url, '_blank', 'noopener');
  });

  if (search) search.addEventListener('input', render);
  if (region) region.addEventListener('change', render);
  if (reset) {
    reset.addEventListener('click', () => {
      if (search) search.value = '';
      if (region) region.value = 'alle';
      render();
    });
  }

  // Initial selection from a deep link such as kontakt.html#jena
  const initial = window.location.hash ? decodeURIComponent(window.location.hash.slice(1)) : '';
  if (stations.some((s) => s.id === initial)) {
    activeId = initial;
    window.setTimeout(() => {
      const section = document.getElementById('dienststellen');
      if (section) section.scrollIntoView({ block: 'start' });
    }, 160);
  }
  loadStations();

  /* ---------- Contact form ---------- */
  const form = document.getElementById('contactForm');
  const success = document.getElementById('contactSuccess');
  const ref = document.getElementById('contactRef');
  const formReset = document.getElementById('contactReset');
  const chatLink = document.getElementById('contactChatLink');
  const loginGate = document.getElementById('contactLoginGate');
  const loginBtn = document.getElementById('contactDiscordLogin');
  const loginNotice = document.getElementById('contactLoginNotice');
  const loginNoticeTitle = document.getElementById('contactLoginNoticeTitle');
  const loginNoticeText = document.getElementById('contactLoginNoticeText');
  const accountBar = document.getElementById('contactAccountBar');

  async function initContactAuth() {
    const next = '/kontakt.html#formular';
    if (loginBtn) {
      loginBtn.href = ((window.LPTApi && window.LPTApi.base) ? window.LPTApi.base : '') +
        '/api/citizen/auth/discord?next=' + encodeURIComponent(next);
    }
    if (!window.LPTApi) {
      if (loginGate) loginGate.hidden = false;
      if (form) form.hidden = true;
      return;
    }

    try {
      const session = await window.LPTApi.citizenSession();
      if (!session.authenticated) throw new Error('Nicht angemeldet');
      const citizen = session.citizen || {};
      if (loginGate) loginGate.hidden = true;
      if (form) form.hidden = false;
      if (accountBar) accountBar.hidden = false;
      const avatar = document.getElementById('contactAccountAvatar');
      if (avatar && citizen.avatarUrl) {
        avatar.src = citizen.avatarUrl;
        avatar.alt = 'Discord-Profilbild von ' + (citizen.displayName || citizen.username);
      }
      const nameLabel = document.getElementById('contactAccountName');
      if (nameLabel) nameLabel.textContent = citizen.displayName || citizen.username || 'Discord-Konto';
      const tagLabel = document.getElementById('contactAccountTag');
      if (tagLabel) tagLabel.textContent = citizen.username ? '@' + citizen.username + ' · Discord' : 'Discord';
      return;
    } catch (err) {
      /* Nicht angemeldet – Konfiguration unten prüfen. */
    }

    try {
      const config = await window.LPTApi.citizenConfig();
      if (!config.discordConfigured) {
        if (loginGate) loginGate.hidden = false;
        if (form) form.hidden = true;
        if (loginBtn) {
          loginBtn.removeAttribute('href');
          loginBtn.setAttribute('aria-disabled', 'true');
          loginBtn.classList.add('is-disabled');
          loginBtn.textContent = 'Discord-Anmeldung nicht eingerichtet';
        }
        if (loginNotice && loginNoticeTitle && loginNoticeText) {
          loginNoticeTitle.textContent = 'Discord-Anmeldung nicht verfügbar';
          loginNoticeText.textContent = 'Die Anmeldung ist auf diesem System noch nicht eingerichtet. Bitte wenden Sie sich an die Administration.';
          loginNotice.hidden = false;
        }
        return;
      }
    } catch (e) { /* Gate trotzdem anzeigen */ }

    if (loginGate) loginGate.hidden = false;
    if (form) form.hidden = true;
    if (accountBar) accountBar.hidden = true;
  }

  if (form && success && ref) {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const topic = document.getElementById('contactTopic').value;
      const station = document.getElementById('contactStation').value;
      const name = document.getElementById('contactName').value.trim();
      const email = document.getElementById('contactMail').value.trim();
      const message = document.getElementById('contactMessage').value.trim();
      const payload = { art: 'Kontakt & Anfrage', topic, station, name, email, message };
      let refValue = '';
      let ticketId = null;
      try {
        if (!window.LPTApi) throw new Error('Server nicht erreichbar.');
        const res = await window.LPTApi.submitApplication('contact', payload, {
          applicantName: name,
          applicantEmail: email || null,
          stationId: station || null
        });
        refValue = (res && res.ref) ? res.ref : '';
        ticketId = (res && res.id) || null;
        app.toast('Ihre Nachricht wurde als Ticket gespeichert.', { title: 'Nachricht erfasst' });
      } catch (err) {
        app.toast(err.message || 'Nachricht konnte nicht übermittelt werden.', { type: 'error', title: 'Fehler' });
        if (err.data && err.data.requiresDiscord) {
          if (loginGate) loginGate.hidden = false;
          if (form) form.hidden = true;
        }
        return;
      }
      ref.textContent = refValue;
      if (chatLink) chatLink.href = ticketId ? 'meine-tickets.html?ticket=' + ticketId : 'meine-tickets.html';
      form.hidden = true;
      success.hidden = false;
      success.setAttribute('tabindex', '-1');
      success.focus({ preventScroll: true });
    });
  }

  if (formReset) {
    formReset.addEventListener('click', () => {
      if (!form) return;
      form.reset();
      form.hidden = false;
      success.hidden = true;
      const first = form.querySelector('select, input, textarea');
      if (first) first.focus({ preventScroll: true });
    });
  }

  initContactAuth();
})();
