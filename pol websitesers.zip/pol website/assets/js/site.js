/* ==========================================================================
   Landespolizei Thüringen · Roleplay Erfurt
   Shared UI behavior
   ========================================================================== */
(function () {
  'use strict';

  // Kanonischer Host ohne www – sonst landen OAuth-Cookies und die bei Discord
  // hinterlegte Callback-Adresse auf unterschiedlichen Hostnamen.
  if (window.location.hostname.indexOf('www.') === 0) {
    window.location.replace(
      window.location.protocol + '//' + window.location.hostname.slice(4) +
      window.location.pathname + window.location.search + window.location.hash
    );
    return;
  }

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const LPT = window.LPT || {};
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const ICON = (name, cls = 'icon') =>
    `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;

  const escapeHTML = (value) => String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');

  const normalize = (value) => String(value || '')
    .toLowerCase()
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .trim();

  const formatDate = (iso) => {
    try {
      return new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: 'long', year: 'numeric' }).format(new Date(iso + 'T12:00:00'));
    } catch (e) {
      return iso;
    }
  };

  const formatShortDate = (iso) => {
    try {
      return new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(iso + 'T12:00:00'));
    } catch (e) {
      return iso;
    }
  };

  /* ---------- Toasts ---------- */
  function toast(message, options = {}) {
    const stack = $('#toastStack');
    if (!stack) return;
    const type = options.type === 'error' ? 'is-error' : '';
    const iconName = options.type === 'error' ? 'alert' : 'check-circle';
    const el = document.createElement('div');
    el.className = `toast ${type}`.trim();
    el.innerHTML = `${ICON(iconName)}<div>${options.title ? `<strong>${escapeHTML(options.title)}</strong>` : ''}${escapeHTML(message)}</div>`;
    stack.appendChild(el);
    window.setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(6px)';
      el.style.transition = 'opacity .2s, transform .2s';
      window.setTimeout(() => el.remove(), 220);
    }, options.duration || 4600);
  }

  /* ---------- Modal system ---------- */
  let lastFocused = null;
  let activeModal = null;

  function openModal(target) {
    const modal = typeof target === 'string' ? $(target) : target;
    if (!modal) return;
    lastFocused = document.activeElement;
    activeModal = modal;
    modal.hidden = false;
    document.body.classList.add('no-scroll');
    const focusTarget = $('input:not([type="hidden"]), select, textarea, button, a[href]', modal) || modal;
    window.setTimeout(() => focusTarget.focus({ preventScroll: true }), 30);
  }

  function closeModal(target) {
    const modal = typeof target === 'string' ? $(target) : target || activeModal;
    if (!modal) return;
    modal.hidden = true;
    if (activeModal === modal) activeModal = null;
    if (!$$('.modal:not([hidden])').length && $('#searchOverlay').hidden) {
      document.body.classList.remove('no-scroll');
    }
    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus({ preventScroll: true });
      lastFocused = null;
    }
  }

  $$('[data-modal-open]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      openModal(btn.getAttribute('data-modal-open'));
    });
  });

  $$('[data-modal-close]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      closeModal(btn.closest('.modal'));
    });
  });

  $$('.modal').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal);
    });
  });

  /* ---------- Focus trap ---------- */
  const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  function trapFocus(container, event) {
    if (event.key !== 'Tab') return;
    const focusable = $$(FOCUSABLE, container).filter((el) => el.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      if (activeModal) {
        closeModal(activeModal);
        return;
      }
      if (!searchOverlay.hidden) {
        closeSearch();
      }
      closeMenu();
    }
    if (activeModal) trapFocus(activeModal, event);
    else if (!searchOverlay.hidden) trapFocus(searchPanel, event);
  });

  /* ---------- Roleplay strip ---------- */
  const rpStrip = $('#rpStrip');
  try {
    if (sessionStorage.getItem('lpt-rp-closed') === '1' && rpStrip) rpStrip.hidden = true;
  } catch (e) { /* ignore */ }
  $$('[data-rp-close]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (rpStrip) rpStrip.hidden = true;
      try { sessionStorage.setItem('lpt-rp-closed', '1'); } catch (e) { /* ignore */ }
    });
  });

  /* ---------- Mobile menu ---------- */
  const body = document.body;
  const menuToggle = $('[data-menu-open]');
  const backdrop = $('.nav-backdrop');
  const nav = $('#mainnav');

  function openMenu() {
    body.classList.add('nav-open', 'no-scroll');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true');
    if (backdrop) backdrop.hidden = false;
    const closeBtn = $('[data-menu-close]', nav);
    if (closeBtn) window.setTimeout(() => closeBtn.focus(), 40);
  }

  function closeMenu() {
    if (!body.classList.contains('nav-open')) return;
    body.classList.remove('nav-open');
    if (!activeModal && searchOverlay.hidden) body.classList.remove('no-scroll');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
    if (backdrop) backdrop.hidden = true;
  }

  if (menuToggle) menuToggle.addEventListener('click', openMenu);
  $$('[data-menu-close]').forEach((el) => el.addEventListener('click', closeMenu));

  $$('#mainnav a').forEach((link) => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 1080) closeMenu();
    });
  });

  /* ---------- Nav dropdowns ---------- */
  const navItems = $$('.has-dropdown');
  function setDropdown(item, isOpen) {
    item.classList.toggle('open', isOpen);
    const trigger = $('.nav-drop-toggle', item);
    if (trigger) trigger.setAttribute('aria-expanded', String(isOpen));
  }
  function closeDropdowns(except) {
    navItems.forEach((item) => {
      if (item !== except) setDropdown(item, false);
    });
  }

  navItems.forEach((item) => {
    const trigger = $('.nav-drop-toggle', item);
    if (!trigger) return;
    trigger.addEventListener('click', (event) => {
      event.stopPropagation();
      const willOpen = !item.classList.contains('open');
      closeDropdowns(item);
      setDropdown(item, willOpen);
    });
    item.addEventListener('mouseenter', () => {
      if (window.innerWidth > 1080) {
        closeDropdowns(item);
        setDropdown(item, true);
      }
    });
    item.addEventListener('mouseleave', () => {
      if (window.innerWidth > 1080) setDropdown(item, false);
    });
  });

  document.addEventListener('click', (event) => {
    if (!event.target.closest('.has-dropdown')) closeDropdowns();
  });

  document.addEventListener('focusin', (event) => {
    if (window.innerWidth > 1080 && !event.target.closest('.has-dropdown')) closeDropdowns();
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 1080) {
      closeMenu();
      closeDropdowns();
    }
  });

  /* ---------- Search overlay ---------- */
  const searchOverlay = $('#searchOverlay');
  const searchPanel = $('.search-panel', searchOverlay || document);
  const searchInput = $('#globalSearchInput');
  const searchResults = $('#searchResults');
  let searchIndex = [];
  let searchReturnFocus = null;

  function buildIndex() {
    const pages = (LPT.pages || []).map((p) => ({
      title: p.title,
      category: p.category,
      url: p.url,
      desc: p.desc,
      keywords: `${p.title} ${p.desc} ${p.keywords || ''}`,
      icon: p.icon || 'file'
    }));
    const news = (LPT.news || []).map((n) => ({
      title: n.title,
      category: `Meldung · ${n.label}`,
      url: `meldung.html?id=${n.id}`,
      desc: n.teaser,
      keywords: `${n.title} ${n.teaser} ${n.location}`,
      icon: n.icon || 'file'
    }));
    const fahndungen = (LPT.fahndungen || []).map((f) => ({
      title: f.title,
      category: `Fahndung · ${f.label}`,
      url: `fahndung.html#${f.caseNo}`,
      desc: f.teaser,
      keywords: `${f.title} ${f.teaser} ${f.location} ${f.caseNo}`,
      icon: f.icon || 'search'
    }));
    return pages.concat(news, fahndungen);
  }

  function highlight(text, query) {
    const safe = escapeHTML(text);
    if (!query) return safe;
    try {
      const terms = query.split(/\s+/).filter(Boolean).map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
      if (!terms.length) return safe;
      return safe.replace(new RegExp(`(${terms.join('|')})`, 'gi'), '<mark>$1</mark>');
    } catch (e) {
      return safe;
    }
  }

  function renderSearch(query) {
    if (!searchResults) return;
    const term = query.trim();
    if (!term) {
      searchResults.innerHTML = `
        <div class="search-group-title">Schnellzugriff</div>
        ${(LPT.pages || []).slice(0, 4).map((p) => `
          <a class="search-result" href="${p.url}">
            <span class="search-result-icon">${ICON(p.icon || 'file')}</span>
            <span><strong>${escapeHTML(p.title)}</strong><small>${escapeHTML(p.desc)}</small></span>
            ${ICON('arrow-right')}
          </a>`).join('')}`;
      return;
    }
    const n = normalize(term);
    const hits = searchIndex
      .map((item) => {
        const haystack = normalize(`${item.title} ${item.desc} ${item.keywords}`);
        let score = 0;
        if (normalize(item.title).includes(n)) score += 6;
        if (normalize(item.title).startsWith(n)) score += 4;
        if (haystack.includes(n)) score += 2;
        return { item, score };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map((x) => x.item);

    if (!hits.length) {
      searchResults.innerHTML = `
        <div class="empty-state">
          ${ICON('search')}
          <p><strong>Keine Treffer für „${escapeHTML(term)}“.</strong><br>Versuchen Sie einen allgemeineren Begriff oder nutzen Sie die Schnellzugriffe.</p>
          <p><a class="text-link" href="kontakt.html">Kontakt aufnehmen ${ICON('arrow-right')}</a></p>
        </div>`;
      return;
    }

    const groups = new Map();
    hits.forEach((hit) => {
      if (!groups.has(hit.category)) groups.set(hit.category, []);
      groups.get(hit.category).push(hit);
    });

    searchResults.innerHTML = Array.from(groups.entries()).map(([category, items]) => `
      <div class="search-group-title">${escapeHTML(category)}</div>
      ${items.map((item) => `
        <a class="search-result" href="${item.url}">
          <span class="search-result-icon">${ICON(item.icon)}</span>
          <span><strong>${highlight(item.title, term)}</strong><small>${highlight(item.desc, term)}</small></span>
          ${ICON('arrow-right')}
        </a>`).join('')}
    `).join('');
  }

  function openSearch() {
    if (!searchOverlay) return;
    searchReturnFocus = document.activeElement;
    searchOverlay.hidden = false;
    body.classList.add('no-scroll');
    renderSearch('');
    window.setTimeout(() => searchInput && searchInput.focus(), 40);
  }

  function closeSearch() {
    if (!searchOverlay || searchOverlay.hidden) return;
    searchOverlay.hidden = true;
    if (!activeModal && !body.classList.contains('nav-open')) body.classList.remove('no-scroll');
    if (searchReturnFocus && typeof searchReturnFocus.focus === 'function') {
      searchReturnFocus.focus({ preventScroll: true });
      searchReturnFocus = null;
    }
  }

  searchIndex = buildIndex();
  $$('[data-search-open]').forEach((btn) => btn.addEventListener('click', openSearch));
  $$('[data-search-close]').forEach((btn) => btn.addEventListener('click', closeSearch));
  if (searchOverlay) {
    searchOverlay.addEventListener('click', (event) => {
      if (event.target === searchOverlay) closeSearch();
    });
  }
  if (searchInput) {
    searchInput.addEventListener('input', () => renderSearch(searchInput.value));
    searchInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        const first = $('.search-result', searchResults);
        if (first) window.location.href = first.getAttribute('href');
        else renderSearch(searchInput.value);
      }
    });
  }
  const searchForm = $('#globalSearchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const first = $('.search-result', searchResults);
      if (first) window.location.href = first.getAttribute('href');
      else renderSearch(searchInput ? searchInput.value : '');
    });
  }
  $$('[data-search-term]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!searchInput) return;
      searchInput.value = btn.getAttribute('data-search-term');
      renderSearch(searchInput.value);
      searchInput.focus();
    });
  });

  document.addEventListener('keydown', (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      openSearch();
    }
  });

  /* ---------- Newsletter ---------- */
  $$('[data-newsletter-form]').forEach((form) => {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const input = form.querySelector('input[type="email"]');
      const email = input ? input.value.trim() : '';
      try {
        const base = window.LPTApi && window.LPTApi.base ? window.LPTApi.base : '';
        const response = await fetch(base + '/api/newsletter', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'Anmeldung konnte nicht gespeichert werden.');
        toast(data.message || 'Ihre E-Mail-Adresse wurde gespeichert.', { title: 'Angemeldet' });
        form.reset();
      } catch (err) {
        toast(err.message || 'Anmeldung konnte nicht gespeichert werden.', { type: 'error', title: 'Fehler' });
      }
    });
  });

  /* ---------- Cookie note ---------- */
  const cookieNote = $('#cookieNote');
  try {
    if (cookieNote && localStorage.getItem('lpt-cookie-note') !== '1') {
      window.setTimeout(() => { cookieNote.hidden = false; }, 1400);
    }
  } catch (e) { /* ignore */ }
  $$('[data-cookie-accept]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (cookieNote) cookieNote.hidden = true;
      try { localStorage.setItem('lpt-cookie-note', '1'); } catch (e) { /* ignore */ }
    });
  });

  /* ---------- Copy / share / print ---------- */
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise((resolve, reject) => {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        resolve();
      } catch (e) {
        reject(e);
      }
    });
  }

  $$('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const value = btn.getAttribute('data-copy-target')
        ? ($(btn.getAttribute('data-copy-target')) || {}).textContent
        : btn.getAttribute('data-copy');
      copyText(value || '').then(() => {
        toast('In die Zwischenablage kopiert.', { title: 'Kopiert' });
      }).catch(() => {
        toast('Kopieren war leider nicht möglich. Bitte markieren Sie den Text manuell.', { type: 'error' });
      });
    });
  });

  $$('[data-share]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const title = btn.getAttribute('data-share-title') || document.title;
      const url = btn.getAttribute('data-share') === 'native' && navigator.share
        ? null
        : window.location.href;
      if (!url && navigator.share) {
        navigator.share({ title, url: window.location.href }).catch(() => {});
        return;
      }
      copyText(window.location.href).then(() => {
        toast('Link in die Zwischenablage kopiert.', { title: 'Teilen' });
      }).catch(() => {
        toast('Link konnte nicht kopiert werden.', { type: 'error' });
      });
    });
  });

  $$('[data-print]').forEach((btn) => btn.addEventListener('click', () => window.print()));

  /* ---------- FAQ anchor open ---------- */
  if (window.location.hash) {
    const target = document.getElementById(window.location.hash.slice(1));
    if (target && target.tagName === 'DETAILS') target.open = true;
  }

  /* ---------- Reveal on scroll (progressive enhancement) ---------- */
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const revealItems = $$('.reveal');
    if (revealItems.length) {
      const io = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      }, { rootMargin: '0px 0px -40px 0px', threshold: .08 });
      revealItems.forEach((el) => {
        el.classList.add('reveal-pending');
        io.observe(el);
      });
    }
  }

  /* ---------- Export public helpers ---------- */
  window.LPTApp = {
    $, $$, ICON, escapeHTML, normalize, formatDate, formatShortDate,
    toast, openModal, closeModal, copyText,
    get news() { return LPT.news || []; },
    get fahndungen() { return LPT.fahndungen || []; },
    get stations() { return LPT.stations || []; },
    get quiz() { return LPT.quiz || []; }
  };
})();
