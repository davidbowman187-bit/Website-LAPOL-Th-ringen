/* ==========================================================================
   Landespolizei Thüringen · Roleplay Erfurt
   API-Client für das Backend
   ========================================================================== */
(function () {
  'use strict';

  // Same-Origin ist der Normalfall (Website + API laufen über Express/Cloudflare).
  // Nur bei lokalem Entwicklungsserver auf einem anderen Port wird auf 127.0.0.1:3000 verwiesen.
  const base = window.LPT_API_BASE || (() => {
    const { protocol, hostname, port } = window.location;
    if (protocol === 'file:') return 'http://127.0.0.1:3000';
    const localHost = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]';
    if (localHost && port && port !== '3000') return 'http://127.0.0.1:3000';
    return '';
  })();

  function getToken() {
    try { return localStorage.getItem('lpt-token'); } catch (e) { return null; }
  }
  function setToken(token) {
    try {
      if (token) localStorage.setItem('lpt-token', token);
      else localStorage.removeItem('lpt-token');
    } catch (e) { /* ignore */ }
  }

  async function request(path, options) {
    const opts = options || {};
    const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    const token = getToken();
    if (token) headers.Authorization = 'Bearer ' + token;
    const response = await fetch(base + path, {
      method: opts.method || 'GET',
      headers,
      credentials: 'include',
      body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    let data = null;
    const text = await response.text();
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = { raw: text }; }
    if (!response.ok) {
      const error = new Error((data && (data.error || data.message)) || `HTTP ${response.status}`);
      error.status = response.status;
      error.data = data;
      throw error;
    }
    return data;
  }

  window.LPTApi = {
    base,
    getToken,
    setToken,
    request,
    login: (username, password) => request('/api/auth/login', { method: 'POST', body: { username, password } }),
    me: () => request('/api/auth/me'),
    submitApplication: (type, payload, extra) => request('/api/applications', { method: 'POST', body: Object.assign({ type, payload }, extra || {}) }),
    getStatus: (ref, birth) => request('/api/applications/status/' + encodeURIComponent(ref) + (birth ? '?birth=' + encodeURIComponent(birth) : '')),
    getWanted: () => request('/api/wanted'),
    getNews: () => request('/api/news'),
    getApplications: (params) => request('/api/applications' + (params ? '?' + new URLSearchParams(params) : '')),
    updateApplication: (id, body) => request('/api/applications/' + id, { method: 'PATCH', body }),
    deleteApplication: (id) => request('/api/applications/' + id, { method: 'DELETE' }),
    getRanks: () => request('/api/ranks'),
    getUsers: () => request('/api/users'),
    createRank: (body) => request('/api/ranks', { method: 'POST', body }),
    updateRank: (id, body) => request('/api/ranks/' + id, { method: 'PATCH', body }),
    deleteRank: (id) => request('/api/ranks/' + id, { method: 'DELETE' }),
    createUser: (body) => request('/api/users', { method: 'POST', body }),
    updateUser: (id, body) => request('/api/users/' + id, { method: 'PATCH', body }),
    deleteUser: (id) => request('/api/users/' + id, { method: 'DELETE' }),
    createWanted: (body) => request('/api/wanted', { method: 'POST', body }),
    updateWanted: (id, body) => request('/api/wanted/' + id, { method: 'PATCH', body }),
    deleteWanted: (id) => request('/api/wanted/' + id, { method: 'DELETE' }),
    createNews: (body) => request('/api/news', { method: 'POST', body }),
    updateNews: (id, body) => request('/api/news/' + id, { method: 'PATCH', body }),
    deleteNews: (id) => request('/api/news/' + id, { method: 'DELETE' }),
    getEvidence: () => request('/api/evidence'),
    createEvidence: (body) => request('/api/evidence', { method: 'POST', body }),
    updateEvidence: (id, body) => request('/api/evidence/' + id, { method: 'PATCH', body }),
    deleteEvidence: (id) => request('/api/evidence/' + id, { method: 'DELETE' }),
    getDocuments: () => request('/api/documents'),
    createCertificate: (applicationId) => request('/api/documents/application/' + applicationId, { method: 'POST' }),
    searchCitizens: (q, birth) => request('/api/aktensystem/characters/search?' + new URLSearchParams({ q: q || '', birth: birth || '' })),
    getCitizen: (identifier) => request('/api/aktensystem/characters/' + encodeURIComponent(identifier)),
    searchVehicles: (q) => request('/api/aktensystem/vehicles/search?q=' + encodeURIComponent(q || '')),
    getVehicle: (plate) => request('/api/aktensystem/vehicles/' + encodeURIComponent(plate)),
    getWeapons: (params) => request('/api/weapons' + (params ? '?' + new URLSearchParams(params) : '')),
    createWeapon: (body) => request('/api/weapons', { method: 'POST', body }),
    updateWeapon: (id, body) => request('/api/weapons/' + id, { method: 'PATCH', body }),
    deleteWeapon: (id) => request('/api/weapons/' + id, { method: 'DELETE' }),
    getActivityReports: (params) => request('/api/activity-reports' + (params ? '?' + new URLSearchParams(params) : '')),
    createActivityReport: (body) => request('/api/activity-reports', { method: 'POST', body }),
    updateActivityReport: (id, body) => request('/api/activity-reports/' + id, { method: 'PATCH', body }),
    deleteActivityReport: (id) => request('/api/activity-reports/' + id, { method: 'DELETE' }),
    getLaws: (q) => request('/api/laws' + (q ? '?q=' + encodeURIComponent(q) : '')),
    getLaw: (code) => request('/api/laws/' + encodeURIComponent(code)),
    createLaw: (body) => request('/api/laws', { method: 'POST', body }),
    updateLaw: (code, body) => request('/api/laws/' + encodeURIComponent(code), { method: 'PATCH', body }),
    deleteLaw: (code) => request('/api/laws/' + encodeURIComponent(code), { method: 'DELETE' }),
    createLawSection: (code, body) => request('/api/laws/' + encodeURIComponent(code) + '/sections', { method: 'POST', body }),
    updateLawSection: (code, id, body) => request('/api/laws/' + encodeURIComponent(code) + '/sections/' + id, { method: 'PATCH', body }),
    deleteLawSection: (code, id) => request('/api/laws/' + encodeURIComponent(code) + '/sections/' + id, { method: 'DELETE' }),
    getTickets: (params) => request('/api/tickets' + (params ? '?' + new URLSearchParams(params) : '')),
    getTicket: (id) => request('/api/tickets/' + id),
    replyTicket: (id, body) => request('/api/tickets/' + id + '/messages', { method: 'POST', body }),
    takeTicket: (id) => request('/api/tickets/' + id + '/take', { method: 'POST' }),
    releaseTicket: (id) => request('/api/tickets/' + id + '/release', { method: 'POST' }),
    archiveTicket: (id) => request('/api/tickets/' + id + '/archive', { method: 'POST' }),
    unarchiveTicket: (id) => request('/api/tickets/' + id + '/unarchive', { method: 'POST' }),
    citizenConfig: () => request('/api/citizen/config'),
    citizenSession: () => request('/api/citizen/session'),
    citizenMe: () => request('/api/citizen/me'),
    citizenLogout: () => request('/api/citizen/auth/logout', { method: 'POST' }),
    getRecruitmentPhases: () => request('/api/recruitment'),
    updateRecruitmentPhase: (key, body) => request('/api/recruitment/' + encodeURIComponent(key), { method: 'PATCH', body }),
    getTrainings: () => request('/api/training/trainings'),
    createTraining: (body) => request('/api/training/trainings', { method: 'POST', body }),
    getTraining: (id) => request('/api/training/trainings/' + id),
    updateTraining: (id, body) => request('/api/training/trainings/' + id, { method: 'PATCH', body }),
    deleteTraining: (id) => request('/api/training/trainings/' + id, { method: 'DELETE' }),
    uploadTrainingDocument: (id, body) => request('/api/training/trainings/' + id + '/documents', { method: 'POST', body }),
    deleteTrainingDocument: (id, docId) => request('/api/training/trainings/' + id + '/documents/' + docId, { method: 'DELETE' }),
    getTrainingTests: () => request('/api/training/tests'),
    getTrainingResults: () => request('/api/training/results'),
    getTrainingTest: (id) => request('/api/training/tests/' + id),
    createTrainingTest: (body) => request('/api/training/tests', { method: 'POST', body }),
    updateTrainingTest: (id, body) => request('/api/training/tests/' + id, { method: 'PATCH', body }),
    deleteTrainingTest: (id) => request('/api/training/tests/' + id, { method: 'DELETE' }),
    getPublicTest: (code) => request('/api/training/public/' + encodeURIComponent(code)),
    submitPublicTest: (code, body) => request('/api/training/public/' + encodeURIComponent(code) + '/submit', { method: 'POST', body }),
    getHrApplications: (q) => request('/api/hr/applications' + (q ? '?q=' + encodeURIComponent(q) : '')),
    getLeadershipSummary: () => request('/api/leadership/summary'),
    getLeadershipNotes: () => request('/api/leadership/notes'),
    createLeadershipNote: (body) => request('/api/leadership/notes', { method: 'POST', body }),
    updateLeadershipNote: (id, body) => request('/api/leadership/notes/' + id, { method: 'PATCH', body }),
    deleteLeadershipNote: (id) => request('/api/leadership/notes/' + id, { method: 'DELETE' }),
    getMyTickets: () => request('/api/citizen/tickets'),
    getMyTicket: (id) => request('/api/citizen/tickets/' + id),
    sendMyTicketMessage: (id, message) => request('/api/citizen/tickets/' + id + '/messages', { method: 'POST', body: { message } }),
    downloadDocument: async (id, ref) => {
      const headers = {};
      const token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
      const url = base + '/api/documents/' + id + '/download' + (ref ? '?ref=' + encodeURIComponent(ref) : '');
      const response = await fetch(url, { headers });
      if (!response.ok) {
        let msg = 'Dokument konnte nicht geladen werden.';
        try { const d = await response.json(); msg = d.error || msg; } catch (e) { /* ignore */ }
        throw new Error(msg);
      }
      return response.blob();
    },
    downloadUpload: async (applicationId, uploadId) => {
      const headers = {};
      const token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
      const response = await fetch(base + '/api/applications/' + applicationId + '/uploads/' + uploadId + '/download', { headers });
      if (!response.ok) {
        let msg = 'Datei konnte nicht geladen werden.';
        try { const d = await response.json(); msg = d.error || msg; } catch (e) { /* ignore */ }
        throw new Error(msg);
      }
      return response.blob();
    },
    downloadTrainingDocument: async (trainingId, documentId) => {
      const headers = {};
      const token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
      const response = await fetch(base + '/api/training/trainings/' + trainingId + '/documents/' + documentId + '/download', { headers });
      if (!response.ok) {
        let msg = 'Dokument konnte nicht geladen werden.';
        try { const d = await response.json(); msg = d.error || msg; } catch (e) { /* ignore */ }
        throw new Error(msg);
      }
      return response.blob();
    }
  };
})();
