@echo off
title Landespolizei Thüringen - Intranet starten

echo ============================================
echo   Starte Intranet und Backend...
echo ============================================
echo.

cd /d "C:\Users\Papa\Dropbox\Mein PC (David-PC)\Desktop\pol website\backend"
start "LPT Backend" /min cmd /c "node server.js"

timeout /t 3 >nul

echo Backend: http://127.0.0.1:3000
echo Intranet: http://127.0.0.1:3000/intranet.html
echo.
echo Login: admin / Admin123!
echo Hinweis: Für Bürgerkonten müssen DISCORD_CLIENT_ID und DISCORD_CLIENT_SECRET in backend\.env hinterlegt sein.
start "" "http://127.0.0.1:3000/intranet.html"

echo.
echo Fertig. Das Backend läuft in einem minimierten Fenster.
echo Zum Beenden: stop_intranet.bat ausführen.
pause
