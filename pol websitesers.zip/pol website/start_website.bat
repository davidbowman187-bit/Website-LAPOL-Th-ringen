@echo off
title Landespolizei Thüringen - Website starten

echo ============================================
echo   Starte Website und Backend...
echo ============================================
echo.

cd /d "C:\Users\Papa\Dropbox\Mein PC (David-PC)\Desktop\pol website\backend"
start "LPT Backend" /min cmd /c "node server.js"

timeout /t 3 >nul

echo Backend: http://127.0.0.1:3000
echo Website: http://127.0.0.1:3000/index.html
echo.
echo Bürgerkonto: http://127.0.0.1:3000/meine-tickets.html
echo Hinweis: Für die Discord-Anmeldung müssen DISCORD_CLIENT_ID und DISCORD_CLIENT_SECRET in backend\.env hinterlegt sein.
start "" "http://127.0.0.1:3000/index.html"

echo.
echo Fertig. Das Backend läuft in einem minimierten Fenster.
echo Zum Beenden: stop_website.bat ausführen.
pause
