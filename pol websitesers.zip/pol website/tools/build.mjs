import { readFile, writeFile, readdir, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distDir = path.join(root, 'dist');

// Die fertigen Seiten liegen im Projektroot und werden 1:1 nach dist/ gespiegelt.
const EXCLUDE = new Set(['wappen_preview.html']);

async function build() {
  try {
    await mkdir(distDir, { recursive: true });
    const entries = await readdir(root);
    let count = 0;

    for (const page of entries) {
      if (!page.endsWith('.html')) continue;
      if (EXCLUDE.has(page) || page.startsWith('Startseite ')) continue;

      const content = await readFile(path.join(root, page), 'utf-8');
      await writeFile(path.join(distDir, page), content, 'utf-8');
      console.log(`Build: ${page} → ${path.join(distDir, page)}`);
      count += 1;
    }

    console.log(`Build erfolgreich - ${count} Seiten`);
  } catch (err) {
    console.error('Build Fehler:', err);
    process.exitCode = 1;
  }
}

build();
