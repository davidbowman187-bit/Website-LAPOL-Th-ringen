# Landespolizei Thüringen · Roleplay Erfurt

Fiktive, statische Website eines Roleplay-Projekts. **Keine echte Behörde.** Im echten Notfall: **110**.

## Projektübersicht

- **Öffentliche Website** (18 Seiten): Startseite, Onlinewache, Fahndung, Karriere, **Bewerbertest**, Service, Prävention, Presse, Über uns, Kontakt/Dienststelle Erfurt, **Meine Tickets**, Meldung, Leichte Sprache, Barrierefreiheit, Impressum, Datenschutz, 404.
- **Intranet** (`intranet.html`): Modernes Fullscreen-Design mit Dark/White-Mode und animiertem Farbverlauf. Übersicht (KPIs), Vorgänge, **Tickets mit Chat und Bearbeiterzuweisung**, **Archiv**, Fahndungen, Meldungen, Asservaten, **Aktensystem** (Bürgerregister mit Fahndungs-/Ticketabgleich, Fahrzeugregister, Waffenregister, Tätigkeitsberichte, **bearbeitbares Gesetzbuch**), **Personal & Ausbildung** (Bewerbungen, Ausbildungen, Unterlagen, Bewerbertests), **Leitungsbereich** (Kennzahlen und Notizen), **Bewerbungsphasen**, PDF-Dokumente, Benutzer und Ränge – vollständig API-gesteuert.
- **Bewerbung**: Die Bereiche **Ausbildung mittlerer Dienst** und **Sachbearbeiter** können von Administrator und Leitungsebene geöffnet bzw. geschlossen werden. Der Status ist auf Startseite, Karriereseite und in der Bereichsauswahl sichtbar. Lebenslauf und Anschreiben sind Pflicht-Uploads und werden in der Datenbank gespeichert.
- **Personal & Ausbildung**: Personal mit der Berechtigung `training.manage` legt Ausbildungsgänge, Ausbildungsunterlagen und Bewerbertests an. Tests werden über einen öffentlichen Testcode plus Bewerbungs-Aktenzeichen in `bewerber-test.html` absolviert; Ergebnis und Zuordnung landen automatisch in der Personalabteilung. Der Leitungsbereich zeigt Kennzahlen und verwaltbare Notizen und ist nur mit `leadership.view` erreichbar.
- **Tickets**: Bürgerantworten zeigen den Namen des bearbeitenden Beamten. Abgeschlossene Tickets können ins Archiv verschoben und wiederhergestellt werden.
- **Onlinewache & Tickets**: Jede Anzeige, jeder Hinweis und jede Kontaktanfrage erzeugt ein Ticket mit Aktenzeichen. Bürger melden sich per **Discord** an, sehen ihre Tickets in `meine-tickets.html` und chatten dort direkt mit der Sachbearbeitung. Beamte antworten im Intranet; alle Nachrichten und Statusänderungen bleiben in der Datenbank erhalten.
- **Aktensystem**: Bürger- und Fahrzeugdaten kommen live aus der **ESX-/FiveM-Datenbank** (`SERVER_DB_*`), Waffenregister, Tätigkeitsberichte und Gesetzbuch liegen in der Website-Datenbank.
- **Backend** (Node.js + Express + MySQL): REST-API unter `/api` inkl. Auth (JWT), Anträgen, Tickets, Fahndungen, News, Asservaten, PDF-Dokumenten, Newsletter, Rängen, Benutzern, Statistiken und Aktenverwaltung.

Alle Inhalte sind fiktiv und dienen ausschließlich dem Rollplay.

## Frontend lokal starten

```bash
node tools/build.mjs
python -m http.server 8765 --bind 127.0.0.1
```

Dann im Browser öffnen: `http://127.0.0.1:8765/index.html`

## Backend starten

```bash
cd backend
cp .env.example .env   # DB-Zugänge und JWT-Secret eintragen
npm install
mysql -u USER -p < database.sql
npm start
```

Backend: `http://127.0.0.1:3000` (API unter `/api`, das Frontend wird ebenfalls ausgeliefert).

## Öffentlich über Cloudflare Tunnel bereitstellen

Website und Intranet laufen über denselben Express-Server. Für den Zugriff von außen reicht es, den Tunnel auf `http://localhost:3000` zu richten. Wichtig sind die öffentliche Basis-URL und die Discord-Callback-Adresse.

1. Backend starten (`start_website.bat` oder `cd backend && node server.js`).
2. Cloudflare Tunnel starten, z. B. `cloudflared tunnel run <tunnel-name>` oder `cloudflared tunnel --url http://localhost:3000`.
3. In `backend/.env` die öffentliche Adresse eintragen:

```env
PUBLIC_BASE_URL=https://polizei-erfurtrp.de
CORS_ORIGIN=https://polizei-erfurtrp.de,http://127.0.0.1:3000,http://localhost:3000
DISCORD_REDIRECT_URI=
COOKIE_SECURE=false
```

`COOKIE_SECURE=false` ist korrekt: Hinter dem Tunnel erkennt der Server HTTPS automatisch und setzt die Cookies dann mit `Secure`. `DISCORD_REDIRECT_URI` bleibt leer, damit die Adresse aus `PUBLIC_BASE_URL` verwendet wird.

4. Im [Discord Developer Portal](https://discord.com/developers/applications) unter **OAuth2 → Redirects** müssen diese URIs stehen:

```text
https://polizei-erfurtrp.de/api/citizen/auth/discord/callback
http://127.0.0.1:3000/api/citizen/auth/discord/callback
http://localhost:3000/api/citizen/auth/discord/callback
```

5. DNS in Cloudflare: Sowohl `polizei-erfurtrp.de` als auch `www.polizei-erfurtrp.de` dürfen auf den Tunnel zeigen. `www` wird automatisch auf die Adresse ohne `www` umgeleitet, damit OAuth-Cookies und Callback zusammenpassen.
6. Backend nach Änderungen an `.env` neu starten.

Wichtig: Die Website muss über die öffentliche Domain (oder `http://127.0.0.1:3000`) aufgerufen werden, nicht über `file://` oder einen separaten Port. Der API-Client nutzt standardmäßig dieselbe Origin wie die Seite; nur bei einem lokalen Entwicklungsserver auf einem anderen Port wird automatisch `http://127.0.0.1:3000` verwendet.

Intranet-Zugänge sind unabhängig vom Discord-Konto. Der einzige vorhandene Zugang ist aktuell `admin`; weitere Bedienstete werden im Intranet unter **Benutzer** angelegt.

## Discord-Anmeldung einrichten

Die Bürgerkonten für **Meine Tickets**, die **Onlinewache**, das **Kontaktformular** und Fahndungshinweise laufen über Discord OAuth2.

1. Im [Discord Developer Portal](https://discord.com/developers/applications) eine neue Application anlegen.
2. Unter **OAuth2 → Redirects** diese URIs eintragen (öffentlich und lokal):
   - `https://polizei-erfurtrp.de/api/citizen/auth/discord/callback`
   - `http://127.0.0.1:3000/api/citizen/auth/discord/callback`
   - `http://localhost:3000/api/citizen/auth/discord/callback`
3. Unter **OAuth2** die **Client ID** und das **Client Secret** kopieren und in `backend/.env` eintragen:

```env
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
DISCORD_REDIRECT_URI=
CITIZEN_SESSION_DAYS=30
COOKIE_SECURE=false
```

   `DISCORD_REDIRECT_URI` kann leer bleiben: Dann wird automatisch `PUBLIC_BASE_URL` verwendet (öffentlich) bzw. der aktuelle Host (lokal). Für eine feste Callback-Adresse kannst du sie explizit setzen.

4. Backend neu starten (`start_website.bat` oder `cd backend && node server.js`). Danach erscheint auf `onlinewache.html` und `meine-tickets.html` der Login-Button.

Die Discord-Anmeldung fordert nur den Scope `identify` an. Gespeichert werden Discord-ID, Benutzername, Anzeigename und Profilbild – kein Passwort und keine Discord-Nachrichten. Bei einer öffentlichen HTTPS-Domain muss `COOKIE_SECURE=true` gesetzt und die Redirect-URI entsprechend angepasst werden.

### Bürgerkonto-Daten

- `citizen_accounts` – Discord-Profil und letzter Login
- `citizen_sessions` – serverseitige Sitzungen (Token nur gehasht gespeichert)
- `citizen_events` – Login-/Logout- und Ticket-Ereignisse
- `applications.citizen_id` – Verknüpfung des Tickets mit dem Bürgerkonto
- `ticket_messages.citizen_id` – Zuordnung jeder Chat-Nachricht

## Datenbank-Setup (komplett)

Die Datei **`backend/database.sql`** enthält das komplette Schema inklusive Startdaten:

```bash
mysql -u root -p < backend/database.sql
```

Enthalten sind:

- Ränge, Berechtigungen und Zuordnungen
- Benutzer (`admin` / `Admin123!`)
- Vorgänge/Anträge, Tickets inkl. Chat-Nachrichten, **Discord-Bürgerkonten**, Fahndungen, Meldungen, Dienststelle Erfurt
- **Bewerbungs-Uploads** (Lebenslauf/Anschreiben als LONGBLOB), **Bewerbungsphasen**, **Archivstatus** für Tickets
- **Ausbildungen** (`trainings`), **Ausbildungsunterlagen** (`training_documents`, LONGBLOB), **Bewerbertests** inkl. Fragen und Ergebnissen (`training_tests`, `training_test_questions`, `training_test_results`), **Leitungsnotizen** (`leadership_notes`)
- Asservaten, Waffenregister, Tätigkeitsberichte, Gesetzbuch, Newsletter-Abonnenten
- **PDF-Dokumente** (LONGBLOB) und Audit-Log
- Rang **Personal & Ausbildung** (ID 5) mit `training.*` und `hr.*`; Leitung erhält zusätzlich Einblick in Ausbildung, Personal und Leitung; der Administrator besitzt sämtliche Rechte.

Beim Serverstart werden fehlende Tabellen (`documents`, `evidence`, `weapons`, `activity_reports`, `laws`, `law_sections`, `ticket_messages`, `citizen_accounts`, `citizen_sessions`, `citizen_events`, `application_uploads`, `recruitment_phases`, `trainings`, `training_documents`, `training_tests`, `training_test_questions`, `training_test_results`, `leadership_notes`, `newsletter_subscribers`) zusätzlich automatisch angelegt.

## Aktensystem & ESX-Integration

- **Bürgerregister**: liest `users` (+ `jobs`, `user_licenses`, `licenses`) aus der ESX-Datenbank. Suche nach Name, Geburtsdatum (ISO oder `MM/DD/YYYY`) und Identifier.
- **Fahrzeugregister**: liest `owned_vehicles`, verknüpft den Halter mit `users` und wertet das `vehicle`-JSON aus (Modell, Kennzeichen, Status, Kilometerstand).
- **Waffenregister**: eigene Tabelle `weapons` in der Website-Datenbank (Halter, Typ, Modell, Seriennummer, WBK, Status).
- **Tätigkeitsberichte**: eigene Tabelle `activity_reports` mit automatischer Referenz `TB/2026/00001` (Streife, Verkehrskontrolle, Durchsuchung, Einsatz, Vernehmung, Sonstiges).
- **Namensvorschläge**: Beim Tippen von Namen (Halter, Bürger, Personensuche) erscheinen Vorschläge aus der ESX-Datenbank. Der ESX-Identifier wird dabei automatisch übernommen – keine manuelle Eingabe nötig.
- **Gesetzbuch**: `laws` + `law_sections`, vorbefüllt mit StVO, StVZO, StGB, StPO, OWiG, WaffG, BtMG, SprengG, VersG und LuftVG inkl. Beispielparagraphen.

Die ESX-Verbindung wird über `SERVER_DB_HOST`, `SERVER_DB_USER`, `SERVER_DB_PASSWORD` und `SERVER_DB_NAME` in `backend/.env` konfiguriert.

## PDF-Führungszeugnis

Beim Absenden des Führungszeugnisses auf `service.html` wird serverseitig ein PDF erzeugt und in der Tabelle `documents` gespeichert. Der Antrag liefert direkt einen Download-Link zurück, sodass das Dokument sofort heruntergeladen werden kann. Im Intranet lassen sich alle erzeugten PDFs erneut herunterladen.

### Backend-Endpunkte (Auswahl)

| Bereich | Endpunkte |
|---|---|
| Auth | `POST /api/auth/login`, `GET /api/auth/me` |
| Anträge | `GET /api/applications`, `GET /api/applications/:id`, `POST /api/applications`, `PATCH /api/applications/:id`, `POST /api/applications/:id/status` |
| Fahndungen | `GET /api/wanted`, `GET /api/wanted/:caseNo`, `POST /api/wanted`, `PATCH /api/wanted/:id`, `DELETE /api/wanted/:id`, `GET /api/wanted/admin/all` |
| News | `GET /api/news`, `GET /api/news/admin/all`, `POST /api/news`, `PATCH /api/news/:id`, `DELETE /api/news/:id` |
| Asservate | `GET /api/evidence`, `POST /api/evidence`, `PATCH /api/evidence/:id`, `DELETE /api/evidence/:id` |
| Dokumente / PDF | `GET /api/documents`, `GET /api/documents/:id/download`, `POST /api/documents/application/:applicationId` |
| Aktensystem (ESX) | `GET /api/aktensystem/health`, `GET /api/aktensystem/characters/search?q=&birth=`, `GET /api/aktensystem/characters/:identifier`, `GET /api/aktensystem/vehicles/search?q=`, `GET /api/aktensystem/vehicles/:plate` |
| Waffenregister | `GET /api/weapons`, `POST /api/weapons`, `PATCH /api/weapons/:id`, `DELETE /api/weapons/:id` |
| Tätigkeitsberichte | `GET /api/activity-reports`, `POST /api/activity-reports`, `PATCH /api/activity-reports/:id`, `DELETE /api/activity-reports/:id` |
| Gesetzbuch | `GET /api/laws`, `GET /api/laws/:code`, `POST /api/laws`, `PATCH /api/laws/:code`, `DELETE /api/laws/:code`, `POST/PATCH/DELETE /api/laws/:code/sections/...` |
| Tickets | `GET /api/tickets`, `GET /api/tickets/:id`, `POST /api/tickets/:id/messages`, `POST /api/tickets/:id/take`, `POST /api/tickets/:id/release`, `POST /api/tickets/:id/archive`, `POST /api/tickets/:id/unarchive` |
| Bewerbungsphasen | `GET /api/recruitment`, `PATCH /api/recruitment/:key` |
| Bewerbungs-Uploads | `GET /api/applications/:id` (inkl. Upload-Metadaten), `GET /api/applications/:id/uploads/:uploadId/download` |
| Ausbildung / Tests | `GET/POST /api/training/trainings`, `GET/PATCH/DELETE /api/training/trainings/:id`, `POST /api/training/trainings/:id/documents`, `GET .../documents/:docId/download`, `GET/POST /api/training/tests`, `GET/PATCH/DELETE /api/training/tests/:id`, `GET /api/training/results` |
| Öffentlicher Bewerbertest | `GET /api/training/public/:code`, `POST /api/training/public/:code/submit` (Testcode + Aktenzeichen) |
| Personalabteilung | `GET /api/hr/applications` (Unterlagen-, Test- und Bearbeitungsstatus) |
| Leitungsbereich | `GET /api/leadership/summary`, `GET/POST /api/leadership/notes`, `PATCH/DELETE /api/leadership/notes/:id` |
| Bürgerkonto (Discord) | `GET /api/citizen/config`, `GET /api/citizen/session`, `GET /api/citizen/auth/discord`, `GET /api/citizen/auth/discord/callback`, `POST /api/citizen/auth/logout` |
| Bürger-Tickets | `GET /api/citizen/tickets`, `GET /api/citizen/tickets/:id`, `POST /api/citizen/tickets/:id/messages` |
| Newsletter | `POST /api/newsletter` |
| Akten / Charaktere | `GET /api/aktensystem/health`, `/tables`, `/cases`, `/characters/search`, `/vehicles/search` |
| Stats / Ranks / User / Stations | siehe `backend/routes/` |

## Struktur

- `src/pages/` – Seitenfragmente mit META-Block
- `tools/build.mjs` – erzeugt die finalen HTML-Seiten im `dist/`-Ordner
- `assets/css/style.css` – Designsystem der öffentlichen Website
- `assets/css/intranet.css` – eigenständiges Intranet-Design (Fullscreen, Blau)
- `assets/js/data.js` – fiktive Inhalte (Meldungen, Fahndungen, Dienststellen, Quiz)
- `assets/js/site.js` – gemeinsame UI-Funktionen
- `assets/js/api.js` – API-Client (`window.LPTApi`)
- `assets/js/pages/` – seiten-spezifische Logik (inkl. `intranet.js`, `onlinewache.js`, `meine-tickets.js`)
- `assets/img/` – SVG-Grafiken (u. a. das Thüringer Landeswappen als `wappen-thueringen.svg`, Quelle: Wikimedia Commons, gemeinfrei)
- `backend/database.sql` – vollständiges Datenbank-Schema inkl. Startdaten
- `backend/src/pdf.js` – PDF-Generator für Führungszeugnisse (ohne externe Abhängigkeit)
- `backend/` – Express-API, DB-Zugriff, Auth, Routen

## Hinweise

- Die Website läuft als statisches Projekt (HTML/CSS/JS) – ohne Build-Abhängigkeiten neben Node.js.
- Alle Formulare (Onlinewache, Führungszeugnis, Karriere, Fahndung, etc.) senden über die REST-API an das Backend.
- Das Intranet authentifiziert über das Backend (JWT); Benutzer und Rollen werden dort verwaltet.
- Rechtliches: Im realen Notfall wählen Bürger die **110** (Notruf) – im Rollplay dient das Intranet der fiktiven Einsatzpraxis.
